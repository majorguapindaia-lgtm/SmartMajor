# Smart Major

Aplicação administrativa escolar em **Python + Streamlit + SQLite**. Este projeto foi
**construído do zero** nesta sessão, seguindo o Prompt Mestre fornecido — não havia uma
aplicação Smart Major real preexistente para inspecionar/preservar. A pasta `modulos/`
foi criada vazia (com README) para receber, no futuro, os robôs reais do diário
eletrônico sem alterações no restante da arquitetura.

## Estrutura

```
smart_major/
├── app.py                 # navegação principal, bootstrap, login
├── autenticacao_ui.py      # tela de Cadastro de Funcionários (usa autenticacao/)
├── administracao_ui.py     # tela de Administração (usa administracao/)
├── modulos/                 # reservado para robôs legados do diário eletrônico
├── autenticacao/             # pessoas, vínculos, contas, login, sessões, bootstrap do Master
├── administracao/             # catálogo de módulos, permissões, auditoria
├── arquivo_passivo/            # espelho digital do arquivo físico (Anexo A)
├── folha_ponto/                 # motor de 7 modelos, calendário versionado, emissão
├── almoxarifado/                  # base inicial: cadastrar + consultar/editar
├── common/                         # paths e timezone compartilhados
├── dados_privados/                  # bancos, backups, artefatos (NUNCA versionado)
└── requirements.txt
```

## Instalação (Mac/Linux)

```bash
cd /caminho/para/smart_major
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pytest -q
python -m streamlit run app.py
```

## Instalação (Windows PowerShell)

```powershell
cd C:\caminho\para\smart_major
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pytest -q
python -m streamlit run app.py
```

## Primeiro acesso: bootstrap do Master

Antes do primeiro login, crie o usuário Master (uma única vez; uma segunda tentativa
é recusada pelo próprio banco):

```bash
SMART_MAJOR_BOOTSTRAP_SENHA="defina-uma-senha-forte-local" \
  python -m autenticacao.bootstrap_master --nome "Seu Nome" --login "seu.login"
```

No Windows PowerShell:

```powershell
$env:SMART_MAJOR_BOOTSTRAP_SENHA = "defina-uma-senha-forte-local"
python -m autenticacao.bootstrap_master --nome "Seu Nome" --login "seu.login"
```

Depois do bootstrap, acesse `app.py` pelo navegador e faça login com o login/senha
definidos. A partir daí, use a tela **Administração** para conceder permissões aos
demais módulos para outras contas.

## Configuração de e-mail (SMTP) para redefinição de senha

Defina estas variáveis de ambiente antes de iniciar o Streamlit (um arquivo `.env`
local e não versionado é uma opção, com `python-dotenv` se desejar):

```
SMTP_HOST=smtp.exemplo.org
SMTP_PORT=587
SMTP_USER=usuario@exemplo.org
SMTP_PASSWORD=************
SMTP_FROM=naoresponda@exemplo.org
```

**Se essas variáveis não estiverem definidas, o sistema informa um erro explícito ao
administrador — nunca finge que o e-mail de redefinição foi enviado.**

## ngrok

O ngrok é apenas o túnel de rede. **Não é mecanismo de autenticação.** Não publique a
aplicação via ngrok antes de validar login/permissões em ambiente controlado, e nunca
exponha `dados_privados/` pela internet.

## Segredo de sessão

As sessões usam tokens aleatórios (`secrets.token_urlsafe`) com digest armazenado no
banco — não há segredo de assinatura HMAC externo a configurar nesta versão.

## Testes

```bash
python -m pytest -q
```

Resultado real nesta sessão: **63 testes, 63 aprovados, 0 falharam, 0 pulados.**
Cobertura: autenticação (10), administração (8), Arquivo Passivo — os 24 cenários do
capítulo 15 do Anexo A + 1 extra (25), Folha de Ponto (10), Almoxarifado (10).

## Pendências explícitas (não implementadas ou não validadas)

1. **Fidelidade visual dos 7 modelos de Folha de Ponto** — os layouts atuais são
   protótipos estruturais rotulados "NÃO OFICIAL". Depende do recebimento das
   planilhas-modelo institucionais reais (Reeducandos, Amigos Voluntários,
   Administrativo 6h/8h, Diretor, Federais/SIAPE, Professores frente/verso).
2. **MFA (TOTP) do Master** — `pyotp` está instalado, mas o enrolamento/validação
   não foi implementado nesta etapa. Não considerar MFA ativo em produção.
3. **Envio real de e-mail SMTP** — implementado e testado quanto ao fluxo de token,
   mas o envio real depende de um servidor SMTP institucional configurado; não foi
   testado contra um servidor real nesta sessão.
4. **Pasta `modulos/`** — vazia; não há robôs legados reais para integrar/testar
   nesta sessão, porque o aplicativo Smart Major real não existia neste ambiente.
5. **Integração com ngrok** — não configurada/testada nesta sessão (ferramenta
   externa ao código Python).
6. **Interface Streamlit** — exercitada manualmente apenas via verificação de que o
   servidor inicia e responde (HTTP 200) e que o bootstrap do Master funciona de
   ponta a ponta contra o banco real; não há testes automatizados de interação de UI
   (cliques, formulários) nesta entrega — apenas testes de unidade/integração dos
   serviços por trás da UI.

## O que foi efetivamente testado e aprovado nesta sessão

- `python -m pip check` — sem conflitos de dependências.
- `python -m pytest -q` — 63/63 aprovados (ver lista de módulos acima).
- `python -m streamlit run app.py` — iniciado com sucesso, respondeu HTTP 200.
- `python -m autenticacao.bootstrap_master` — executado de ponta a ponta contra um
  banco SQLite real; conta Master persistida e confirmada via consulta SQL direta;
  segunda tentativa de bootstrap corretamente recusada.
