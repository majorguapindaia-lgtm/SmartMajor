# Administração

Master, catálogo dinâmico de módulos/ações, permissões granulares e auditoria
transversal — tudo em `dados_privados/core.db` (compartilhado com `autenticacao/`).

## Regra inegociável

Somente o Master concede/revoga/edita permissões (`permissoes.conceder_permissao` e
`revogar_permissao` verificam isso e lançam `ErroPermissao` caso contrário). Cargo não
concede privilégio automaticamente. `administracao.permissoes` é restrita ao Master
mesmo que, por engano, seja atribuída a outra conta.

## Catálogo — deny by default

`registro_modulos.registrar_modulo_acao` insere a ação no catálogo, mas **nenhuma
conta recebe acesso automaticamente**. `semear_catalogo_inicial()` registra as ações
previstas nesta primeira versão (Arquivo Passivo, Folha de Ponto, Funcionários,
Almoxarifado, Relatórios).

## Auditoria

`auditoria_eventos.registrar_evento` grava eventos com encadeamento de hash
(`hash_anterior` + payload → `hash_evento`). `verificar_integridade_cadeia()`
recalcula a cadeia para detectar adulteração feita pela própria aplicação.
**Isso não impede adulteração por quem tem acesso root ao disco/SO** — documentado
explicitamente, sem prometer imutabilidade absoluta. Senhas/tokens/segredos nunca
são gravados nos eventos (`CAMPOS_PROIBIDOS` em `auditoria_eventos.py`).

## Testes

`pytest administracao` — catálogo semeado, somente Master concede, novo módulo nasce
negado, `administracao.permissoes` restrita ao Master mesmo com tentativa de concessão
indevida, revogação, integridade da cadeia de auditoria, sanitização de segredos,
busca por módulo/resultado.
