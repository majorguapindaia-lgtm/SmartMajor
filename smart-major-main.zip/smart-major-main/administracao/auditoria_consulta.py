"""Busca de eventos de auditoria por usuário, módulo, período, ação, resultado e registro.

Correção de segurança (2ª etapa): a consulta de auditoria é restrita ao Master
(permissão `administracao.permissoes`), verificada dentro do próprio serviço."""
from administracao.contexto import ContextoAutorizacao, exigir
from administracao.database import conectar


def buscar_eventos(
    contexto: ContextoAutorizacao,
    conta_id: int | None = None,
    modulo: str | None = None,
    acao: str | None = None,
    resultado: str | None = None,
    entidade_id: str | None = None,
    desde: str | None = None,
    ate: str | None = None,
    limite: int = 500,
) -> list[dict]:
    exigir(contexto, "administracao.permissoes")
    conn = conectar()
    try:
        sql = "SELECT * FROM auditoria_eventos WHERE 1=1"
        params: list = []
        if conta_id is not None:
            sql += " AND conta_id = ?"
            params.append(conta_id)
        if modulo:
            sql += " AND modulo = ?"
            params.append(modulo)
        if acao:
            sql += " AND acao = ?"
            params.append(acao)
        if resultado:
            sql += " AND resultado = ?"
            params.append(resultado)
        if entidade_id:
            sql += " AND entidade_id = ?"
            params.append(entidade_id)
        if desde:
            sql += " AND momento_utc >= ?"
            params.append(desde)
        if ate:
            sql += " AND momento_utc <= ?"
            params.append(ate)
        sql += " ORDER BY event_id DESC LIMIT ?"
        params.append(limite)
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()
