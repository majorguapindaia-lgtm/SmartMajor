"""Registro de eventos de auditoria com encadeamento de hash (tipo blockchain simples).

Não garante imutabilidade absoluta contra alguém com acesso root ao disco — isso é
documentado explicitamente. O encadeamento permite detectar adulteração dos eventos
pela própria aplicação (qualquer alteração de um evento quebra o hash dos seguintes).
"""
import hashlib
import json

from administracao.database import conectar
from common.tempo import agora_utc

CAMPOS_PROIBIDOS = {"password_hash", "senha", "token", "token_digest", "mfa_secret"}


def _sanitizar_campos_alterados(campos: dict | None) -> str | None:
    if not campos:
        return None
    limpo = {k: v for k, v in campos.items() if k.lower() not in CAMPOS_PROIBIDOS}
    return json.dumps(limpo, ensure_ascii=False, default=str) if limpo else None


def _hash_evento(hash_anterior: str | None, payload: dict) -> str:
    base = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str)
    conteudo = (hash_anterior or "") + base
    return hashlib.sha256(conteudo.encode("utf-8")).hexdigest()


def registrar_evento(
    modulo: str,
    acao: str,
    resultado: str,
    conta_id: int | None = None,
    pessoa_id: int | None = None,
    sessao_ref: str | None = None,
    tipo_entidade: str | None = None,
    entidade_id: str | None = None,
    descricao: str | None = None,
    campos_alterados: dict | None = None,
    origem_tecnica: str | None = None,
) -> int:
    if resultado not in ("sucesso", "negado", "erro"):
        raise ValueError("resultado deve ser 'sucesso', 'negado' ou 'erro'")

    momento = agora_utc().isoformat()
    conn = conectar()
    try:
        ultimo = conn.execute(
            "SELECT hash_evento FROM auditoria_eventos ORDER BY event_id DESC LIMIT 1"
        ).fetchone()
        hash_anterior = ultimo["hash_evento"] if ultimo else None

        campos_json = _sanitizar_campos_alterados(campos_alterados)
        payload = {
            "momento_utc": momento, "conta_id": conta_id, "pessoa_id": pessoa_id,
            "modulo": modulo, "acao": acao, "tipo_entidade": tipo_entidade,
            "entidade_id": entidade_id, "resultado": resultado, "descricao": descricao,
            "campos_alterados": campos_json,
        }
        hash_evento = _hash_evento(hash_anterior, payload)

        cur = conn.execute(
            """INSERT INTO auditoria_eventos
               (momento_utc, conta_id, pessoa_id, sessao_ref, modulo, acao, tipo_entidade,
                entidade_id, resultado, descricao, campos_alterados, origem_tecnica,
                hash_anterior, hash_evento)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (momento, conta_id, pessoa_id, sessao_ref, modulo, acao, tipo_entidade,
             entidade_id, resultado, descricao, campos_json, origem_tecnica,
             hash_anterior, hash_evento),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def verificar_integridade_cadeia() -> bool:
    """Recalcula a cadeia de hashes e confirma que nenhum evento foi adulterado pela aplicação."""
    conn = conectar()
    try:
        linhas = conn.execute("SELECT * FROM auditoria_eventos ORDER BY event_id ASC").fetchall()
        hash_anterior = None
        for linha in linhas:
            payload = {
                "momento_utc": linha["momento_utc"], "conta_id": linha["conta_id"],
                "pessoa_id": linha["pessoa_id"], "modulo": linha["modulo"], "acao": linha["acao"],
                "tipo_entidade": linha["tipo_entidade"], "entidade_id": linha["entidade_id"],
                "resultado": linha["resultado"], "descricao": linha["descricao"],
                "campos_alterados": linha["campos_alterados"],
            }
            esperado = _hash_evento(hash_anterior, payload)
            if esperado != linha["hash_evento"]:
                return False
            hash_anterior = linha["hash_evento"]
        return True
    finally:
        conn.close()
