"""Exportação administrativa de relatórios de auditoria (CSV), sob autorização."""
import csv
import io

from administracao.contexto import ContextoAutorizacao
from administracao.auditoria_consulta import buscar_eventos


def exportar_csv(contexto: ContextoAutorizacao, **filtros) -> bytes:
    eventos = buscar_eventos(contexto, **filtros)
    buffer = io.StringIO()
    campos = [
        "event_id", "momento_utc", "conta_id", "pessoa_id", "modulo", "acao",
        "tipo_entidade", "entidade_id", "resultado", "descricao",
    ]
    escritor = csv.DictWriter(buffer, fieldnames=campos, extrasaction="ignore")
    escritor.writeheader()
    for evento in eventos:
        escritor.writerow(evento)
    return buffer.getvalue().encode("utf-8")
