"""Backup/restauração do banco central core.db (pessoas, vínculos, contas, sessões,
permissões e catálogo — compartilhado entre autenticacao/ e administracao/).

Correção de segurança (2ª etapa): esta era a lacuna mais crítica de backup, pois
core.db contém as próprias credenciais/permissões do sistema."""
from pathlib import Path

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import conta_eh_master, ErroPermissao
from autenticacao.database import caminho_core_db
from common.backup import (
    criar_backup_generico, verificar_integridade_generico, restaurar_em_caminho_separado_generico,
)


def _exigir_master(contexto: ContextoAutorizacao) -> None:
    if contexto is None or not isinstance(contexto, ContextoAutorizacao):
        raise ErroPermissao("Backup exige um contexto de autorização válido.")
    if not conta_eh_master(contexto.conta_id):
        raise ErroPermissao("Somente o Master pode executar backup/restauração.")


def criar_backup(contexto: ContextoAutorizacao) -> Path:
    _exigir_master(contexto)
    return criar_backup_generico(caminho_core_db(), "core")


def verificar_integridade(caminho_backup: Path) -> bool:
    return verificar_integridade_generico(caminho_backup)


def restaurar_em_caminho_separado(caminho_backup: Path, caminho_destino: Path,
                                   contexto: ContextoAutorizacao) -> None:
    _exigir_master(contexto)
    restaurar_em_caminho_separado_generico(caminho_backup, caminho_destino)
