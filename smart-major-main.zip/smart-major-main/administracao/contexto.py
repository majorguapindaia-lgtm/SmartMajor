"""Contexto de autorização validado: a ÚNICA forma de obter uma identidade confiável
para autorizar operações nos serviços.

Correção da falha crítica encontrada no diagnóstico: os serviços não podem mais
confiar em um `autor_id: int` fornecido livremente pelo chamador. Toda operação que
modifica dados ou é sensível exige um `ContextoAutorizacao`, que só pode ser
construído validando um token de sessão real (`autenticacao.sessoes.validar_sessao`).
Um inteiro arbitrário não constrói um contexto válido.
"""
from dataclasses import dataclass

from administracao.permissoes import exigir_permissao, ErroPermissao
from autenticacao.sessoes import validar_sessao

__all__ = ["ContextoAutorizacao", "ErroContextoInvalido", "obter_contexto", "exigir"]


class ErroContextoInvalido(ErroPermissao):
    """Levantado quando não há sessão autenticada válida — bloqueio por padrão."""


@dataclass(frozen=True)
class ContextoAutorizacao:
    """Identidade de quem está executando a operação, já validada contra uma sessão
    real. `conta_id` nunca deve ser extraído de um parâmetro externo não verificado."""
    conta_id: int


def obter_contexto(token_sessao: str | None) -> ContextoAutorizacao:
    """Valida o token de sessão e retorna um contexto confiável.

    Bloqueio por padrão: ausência de token, token expirado, conta bloqueada ou
    inexistente resultam em ErroContextoInvalido — nunca em um contexto "anônimo"
    com permissões implícitas.
    """
    conta_id = validar_sessao(token_sessao)
    if conta_id is None:
        raise ErroContextoInvalido("Sessão inválida, expirada ou inexistente. Acesso negado.")
    return ContextoAutorizacao(conta_id=conta_id)


def exigir(contexto: ContextoAutorizacao | None, permissao_completa: str) -> ContextoAutorizacao:
    """Verifica a permissão granular do contexto. Lança ErroPermissao se ausente ou
    sem a permissão exigida; o evento negado é registrado em auditoria por
    administracao.permissoes.exigir_permissao. Retorna o próprio contexto para uso
    encadeado (ex.: `contexto = exigir(contexto, "...")`)."""
    if contexto is None or not isinstance(contexto, ContextoAutorizacao):
        raise ErroContextoInvalido("Operação exige um contexto de autorização válido.")
    exigir_permissao(contexto.conta_id, permissao_completa)
    return contexto
