"""Conexão com o banco central (core.db), compartilhado com autenticacao/."""
from pathlib import Path

from autenticacao.database import conectar  # mesmo core.db

_SCHEMA_ADMINISTRACAO = Path(__file__).resolve().parent / "schema.sql"

__all__ = ["conectar", "inicializar"]


def inicializar() -> None:
    conn = conectar()
    try:
        conn.executescript(_SCHEMA_ADMINISTRACAO.read_text(encoding="utf-8"))
        conn.commit()
    finally:
        conn.close()
