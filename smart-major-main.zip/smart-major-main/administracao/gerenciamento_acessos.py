"""Gerenciamento de contas administrativas: habilitar/bloquear, iniciar reset de senha.

Master não lê senha alheia — apenas inicia reset (gera token) e bloqueia/desbloqueia.

Correção de segurança (2ª etapa): todas as funções exigem ContextoAutorizacao e
verificam Master dentro do próprio serviço — incluindo `listar_contas`, que antes
não tinha nenhuma verificação."""
from administracao.auditoria_eventos import registrar_evento
from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import ErroPermissao, conta_eh_master
from autenticacao.login import bloquear_conta, desbloquear_conta
from autenticacao.recuperacao import gerar_token_reset, enviar_email_reset, ErroSMTPNaoConfigurado
from autenticacao.database import conectar as conectar_core


def _exigir_master(contexto: ContextoAutorizacao, mensagem: str) -> None:
    if contexto is None or not isinstance(contexto, ContextoAutorizacao) or not conta_eh_master(contexto.conta_id):
        raise ErroPermissao(mensagem)


def listar_contas(contexto: ContextoAutorizacao) -> list[dict]:
    _exigir_master(contexto, "Somente o Master pode listar contas administrativas.")
    conn = conectar_core()
    try:
        return [dict(r) for r in conn.execute(
            """SELECT c.id, c.login_unico, c.ativa, c.master, c.bloqueada_at, p.nome
               FROM contas c JOIN pessoas p ON p.id = c.pessoa_id ORDER BY p.nome"""
        ).fetchall()]
    finally:
        conn.close()


def master_bloquear_conta(conta_alvo_id: int, contexto: ContextoAutorizacao) -> None:
    _exigir_master(contexto, "Somente o Master pode bloquear contas.")
    bloquear_conta(conta_alvo_id)
    registrar_evento(modulo="administracao", acao="bloquear_conta", resultado="sucesso",
                      conta_id=contexto.conta_id, tipo_entidade="conta", entidade_id=str(conta_alvo_id))


def master_desbloquear_conta(conta_alvo_id: int, contexto: ContextoAutorizacao) -> None:
    _exigir_master(contexto, "Somente o Master pode desbloquear contas.")
    desbloquear_conta(conta_alvo_id)
    registrar_evento(modulo="administracao", acao="desbloquear_conta", resultado="sucesso",
                      conta_id=contexto.conta_id, tipo_entidade="conta", entidade_id=str(conta_alvo_id))


def master_iniciar_reset(conta_alvo_id: int, email_destino: str, contexto: ContextoAutorizacao) -> str:
    """Gera o token de reset e tenta enviar por e-mail. Retorna o token para exibição
    administrativa controlada SOMENTE se o e-mail não puder ser enviado (nunca em log)."""
    _exigir_master(contexto, "Somente o Master pode iniciar redefinição de senha de terceiros.")
    token = gerar_token_reset(conta_alvo_id)
    registrar_evento(modulo="administracao", acao="iniciar_reset_senha", resultado="sucesso",
                      conta_id=contexto.conta_id, tipo_entidade="conta", entidade_id=str(conta_alvo_id))
    try:
        enviar_email_reset(email_destino, token)
        return ""
    except ErroSMTPNaoConfigurado:
        registrar_evento(modulo="administracao", acao="envio_email_reset", resultado="erro",
                          conta_id=contexto.conta_id, descricao="SMTP não configurado.")
        raise
