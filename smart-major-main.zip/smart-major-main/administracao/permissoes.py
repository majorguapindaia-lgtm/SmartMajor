"""Concessão, revogação e verificação de permissões granulares.

Regra inegociável: somente o Master concede/revoga/edita permissões.
Deny by default — nenhuma permissão nova é herdada automaticamente.
A verificação deve ocorrer no SERVIÇO que executa a ação, não apenas no menu.
"""
from administracao.database import conectar
from administracao.auditoria_eventos import registrar_evento
from common.tempo import agora_utc


class ErroPermissao(Exception):
    pass


def _eh_master(conn, conta_id: int) -> bool:
    linha = conn.execute("SELECT master FROM contas WHERE id = ?", (conta_id,)).fetchone()
    return bool(linha and linha["master"])


def conta_eh_master(conta_id: int) -> bool:
    from autenticacao.database import conectar as conectar_core
    conn = conectar_core()
    try:
        return _eh_master(conn, conta_id)
    finally:
        conn.close()


def _resolver_conta_id(executor) -> int | None:
    """Aceita um ContextoAutorizacao (preferível) ou, por compatibilidade, um int
    já validado pelo chamador. Import adiado evita ciclo com administracao.contexto,
    que importa deste módulo."""
    return getattr(executor, "conta_id", executor)


def conceder_permissao(conta_id: int, permissao_completa: str, concedida_por) -> None:
    concedida_por = _resolver_conta_id(concedida_por)
    if not conta_eh_master(concedida_por):
        raise ErroPermissao("Somente o Master pode conceder permissões.")
    conn = conectar()
    try:
        catalogo = conn.execute(
            "SELECT 1 FROM catalogo_modulos WHERE permissao_completa = ? AND ativo = 1",
            (permissao_completa,),
        ).fetchone()
        if catalogo is None:
            raise ErroPermissao(f"Permissão desconhecida no catálogo: {permissao_completa}")

        ja_tem = conn.execute(
            """SELECT 1 FROM permissoes_concedidas
               WHERE conta_id = ? AND permissao_completa = ? AND revogada_em IS NULL""",
            (conta_id, permissao_completa),
        ).fetchone()
        if ja_tem:
            return  # evita duplicidade

        conn.execute(
            """INSERT INTO permissoes_concedidas
               (conta_id, permissao_completa, concedida_em, concedida_por)
               VALUES (?, ?, ?, ?)""",
            (conta_id, permissao_completa, agora_utc().isoformat(), concedida_por),
        )
        conn.commit()
    finally:
        conn.close()
    registrar_evento(
        modulo="administracao", acao="conceder_permissao", resultado="sucesso",
        conta_id=concedida_por, tipo_entidade="permissao", entidade_id=permissao_completa,
        descricao=f"Permissão concedida à conta {conta_id}",
    )


def revogar_permissao(conta_id: int, permissao_completa: str, revogada_por) -> None:
    revogada_por = _resolver_conta_id(revogada_por)
    if not conta_eh_master(revogada_por):
        raise ErroPermissao("Somente o Master pode revogar permissões.")
    conn = conectar()
    try:
        conn.execute(
            """UPDATE permissoes_concedidas SET revogada_em = ?, revogada_por = ?
               WHERE conta_id = ? AND permissao_completa = ? AND revogada_em IS NULL""",
            (agora_utc().isoformat(), revogada_por, conta_id, permissao_completa),
        )
        conn.commit()
    finally:
        conn.close()
    registrar_evento(
        modulo="administracao", acao="revogar_permissao", resultado="sucesso",
        conta_id=revogada_por, tipo_entidade="permissao", entidade_id=permissao_completa,
        descricao=f"Permissão revogada da conta {conta_id}",
    )


def listar_permissoes_da_conta(conta_id: int) -> list[str]:
    conn = conectar()
    try:
        linhas = conn.execute(
            "SELECT permissao_completa FROM permissoes_concedidas WHERE conta_id = ? AND revogada_em IS NULL",
            (conta_id,),
        ).fetchall()
        return [r["permissao_completa"] for r in linhas]
    finally:
        conn.close()


def possui_permissao(conta_id: int, permissao_completa: str) -> bool:
    """Verificação central: chamar no SERVIÇO de cada ação sensível, não só no menu.
    Permissão 'administracao.permissoes' é restrita ao Master, mesmo que concedida por engano."""
    if permissao_completa == "administracao.permissoes":
        return conta_eh_master(conta_id)
    if conta_eh_master(conta_id):
        return True  # Master tem acesso irrestrito aos módulos operacionais
    return permissao_completa in listar_permissoes_da_conta(conta_id)


def exigir_permissao(conta_id: int | None, permissao_completa: str) -> None:
    """Lança ErroPermissao (negação) se a conta não tiver a permissão. Usar nos serviços."""
    if conta_id is None or not possui_permissao(conta_id, permissao_completa):
        registrar_evento(
            modulo=permissao_completa.split(".")[0], acao=permissao_completa.split(".")[-1],
            resultado="negado", conta_id=conta_id, descricao="Acesso negado: permissão ausente.",
        )
        raise ErroPermissao(f"Acesso negado: permissão '{permissao_completa}' é necessária.")
