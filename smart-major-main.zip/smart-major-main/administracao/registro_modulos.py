"""Catálogo dinâmico de módulos e ações. Toda ação nova nasce negada por padrão
(deny by default) — nenhum módulo/permissão é herdada automaticamente."""
from administracao.database import conectar
from common.tempo import agora_utc

CATALOGO_INICIAL = [
    ("arquivo_passivo", "consultar", "Arquivo Passivo — Consultar e pesquisar"),
    ("arquivo_passivo", "cadastrar", "Arquivo Passivo — Cadastrar pastas"),
    ("arquivo_passivo", "editar", "Arquivo Passivo — Editar cadastros"),
    ("arquivo_passivo", "movimentar", "Arquivo Passivo — Movimentar pastas/caixas"),
    ("arquivo_passivo", "ocorrencia", "Arquivo Passivo — Registrar ocorrências"),
    ("folha_ponto", "consultar", "Folha de Ponto — Consultar"),
    ("folha_ponto", "emitir", "Folha de Ponto — Emitir"),
    ("folha_ponto", "reimprimir", "Folha de Ponto — Reimprimir"),
    ("folha_ponto", "nova_versao", "Folha de Ponto — Gerar nova versão"),
    ("folha_ponto", "alterar_calendario", "Folha de Ponto — Alterar calendário"),
    ("folha_ponto", "exportar", "Folha de Ponto — Exportar"),
    ("funcionarios", "consultar", "Cadastro de Funcionários — Consultar"),
    ("funcionarios", "cadastrar", "Cadastro de Funcionários — Cadastrar"),
    ("funcionarios", "editar", "Cadastro de Funcionários — Editar"),
    ("almoxarifado", "consultar", "Almoxarifado — Consultar"),
    ("almoxarifado", "cadastrar", "Almoxarifado — Cadastrar item"),
    ("almoxarifado", "editar", "Almoxarifado — Editar item"),
    ("relatorios", "consultar", "Relatórios do Diário Eletrônico — Consultar"),
    ("relatorios", "exportar", "Relatórios do Diário Eletrônico — Exportar"),
    ("administracao", "permissoes", "Administração — Gerenciar permissões (exclusivo do Master)"),
]


def registrar_modulo_acao(chave_modulo: str, chave_acao: str, rotulo: str) -> None:
    """Idempotente: registra a ação no catálogo caso ainda não exista. Fica inativa
    até que o Master conceda explicitamente a quem deve usá-la — não há herança."""
    permissao_completa = f"{chave_modulo}.{chave_acao}"
    conn = conectar()
    try:
        conn.execute(
            """INSERT OR IGNORE INTO catalogo_modulos
               (chave_modulo, chave_acao, permissao_completa, rotulo, ativo, registrado_em)
               VALUES (?, ?, ?, ?, 1, ?)""",
            (chave_modulo, chave_acao, permissao_completa, rotulo, agora_utc().isoformat()),
        )
        conn.commit()
    finally:
        conn.close()


def semear_catalogo_inicial() -> None:
    for chave_modulo, chave_acao, rotulo in CATALOGO_INICIAL:
        registrar_modulo_acao(chave_modulo, chave_acao, rotulo)


def listar_catalogo(apenas_ativos: bool = True) -> list[dict]:
    conn = conectar()
    try:
        sql = "SELECT * FROM catalogo_modulos"
        if apenas_ativos:
            sql += " WHERE ativo = 1"
        sql += " ORDER BY chave_modulo, chave_acao"
        return [dict(r) for r in conn.execute(sql).fetchall()]
    finally:
        conn.close()
