-- Schema de administração: catálogo de módulos/ações, permissões concedidas e auditoria.
-- Compartilha o mesmo banco central (core.db) que autenticacao/, documentado nos
-- READMEs de ambos os módulos.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS catalogo_modulos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chave_modulo TEXT NOT NULL,          -- ex.: 'arquivo_passivo'
    chave_acao TEXT NOT NULL,            -- ex.: 'consultar'
    permissao_completa TEXT NOT NULL UNIQUE,  -- ex.: 'arquivo_passivo.consultar'
    rotulo TEXT NOT NULL,                -- ex.: 'Arquivo Passivo — Consultar e pesquisar'
    ativo INTEGER NOT NULL DEFAULT 1,
    registrado_em TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS permissoes_concedidas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conta_id INTEGER NOT NULL,
    permissao_completa TEXT NOT NULL,
    concedida_em TEXT NOT NULL,
    concedida_por INTEGER NOT NULL,
    revogada_em TEXT,
    revogada_por INTEGER,
    UNIQUE (conta_id, permissao_completa, revogada_em)
);
CREATE INDEX IF NOT EXISTS idx_permissoes_conta ON permissoes_concedidas(conta_id);

CREATE TABLE IF NOT EXISTS auditoria_eventos (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    momento_utc TEXT NOT NULL,
    conta_id INTEGER,                    -- NULL = anonymous (tentativa negada sem login)
    pessoa_id INTEGER,
    sessao_ref TEXT,
    modulo TEXT NOT NULL,
    acao TEXT NOT NULL,
    tipo_entidade TEXT,
    entidade_id TEXT,
    resultado TEXT NOT NULL CHECK (resultado IN ('sucesso', 'negado', 'erro')),
    descricao TEXT,
    campos_alterados TEXT,               -- JSON, somente quando apropriado/protegido
    origem_tecnica TEXT,
    hash_anterior TEXT,
    hash_evento TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_auditoria_conta ON auditoria_eventos(conta_id);
CREATE INDEX IF NOT EXISTS idx_auditoria_modulo ON auditoria_eventos(modulo);
CREATE INDEX IF NOT EXISTS idx_auditoria_momento ON auditoria_eventos(momento_utc);
