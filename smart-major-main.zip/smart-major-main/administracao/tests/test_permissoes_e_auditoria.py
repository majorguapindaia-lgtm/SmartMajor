import pytest

from administracao.contexto import ContextoAutorizacao
from autenticacao.database import inicializar as inicializar_core
from administracao.database import inicializar as inicializar_admin
from administracao.registro_modulos import semear_catalogo_inicial, registrar_modulo_acao, listar_catalogo
from administracao.permissoes import (
    conceder_permissao, revogar_permissao, possui_permissao, exigir_permissao, ErroPermissao,
)
from administracao.gerenciamento_acessos import listar_contas
from administracao.auditoria_eventos import registrar_evento, verificar_integridade_cadeia
from administracao.auditoria_consulta import buscar_eventos
from autenticacao.bootstrap_master import bootstrap_primeiro_master
from autenticacao.recuperacao import criar_conta, gerar_token_reset, consumir_token_e_redefinir
from autenticacao.usuarios_cadastro import DadosPessoa, DadosVinculo, cadastrar_pessoa


def _contexto_para(conta_id: int) -> ContextoAutorizacao:
    return ContextoAutorizacao(conta_id=conta_id)


@pytest.fixture(autouse=True)
def banco():
    inicializar_core()
    inicializar_admin()
    semear_catalogo_inicial()


def _criar_conta_comum(login: str) -> int:
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome=f"Pessoa {login}"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    conta_id = criar_conta(pessoa_id, login, autor_id=None)
    token = gerar_token_reset(conta_id)
    consumir_token_e_redefinir(token, "SenhaComum123")
    return conta_id


def test_catalogo_inicial_semeado():
    catalogo = listar_catalogo()
    permissoes = {c["permissao_completa"] for c in catalogo}
    assert "arquivo_passivo.consultar" in permissoes
    assert "folha_ponto.emitir" in permissoes
    assert "administracao.permissoes" in permissoes


def test_somente_master_concede_permissao():
    master_id = bootstrap_primeiro_master("Master", "master1", "SenhaMasterForte1")
    from autenticacao.database import conectar
    conn = conectar()
    conta_master = conn.execute("SELECT id FROM contas WHERE pessoa_id = ?", (master_id,)).fetchone()["id"]
    conn.close()

    conta_comum = _criar_conta_comum("secretaria1")
    conta_destino = _criar_conta_comum("destino1")

    with pytest.raises(ErroPermissao):
        conceder_permissao(conta_destino, "arquivo_passivo.consultar", concedida_por=conta_comum)

    conceder_permissao(conta_destino, "arquivo_passivo.consultar", concedida_por=conta_master)
    assert possui_permissao(conta_destino, "arquivo_passivo.consultar")


def test_permissao_negada_por_padrao_e_novo_modulo_comeca_negado():
    conta_comum = _criar_conta_comum("usuario_sem_permissao")
    assert not possui_permissao(conta_comum, "arquivo_passivo.consultar")

    registrar_modulo_acao("modulo_novo", "fazer_algo", "Módulo Novo — Fazer algo")
    assert not possui_permissao(conta_comum, "modulo_novo.fazer_algo")

    with pytest.raises(ErroPermissao):
        exigir_permissao(conta_comum, "modulo_novo.fazer_algo")


def test_cargo_nao_concede_permissao_administracao_mesmo_se_atribuida_por_engano():
    """administracao.permissoes é restrita ao Master mesmo que alguém tente conceder a outra conta."""
    master_id = bootstrap_primeiro_master("Master2", "master2", "SenhaMasterForte2")
    from autenticacao.database import conectar
    conn = conectar()
    conta_master = conn.execute("SELECT id FROM contas WHERE pessoa_id = ?", (master_id,)).fetchone()["id"]
    conn.close()

    diretor_id = _criar_conta_comum("diretor1")
    conceder_permissao(diretor_id, "arquivo_passivo.consultar", concedida_por=conta_master)
    assert possui_permissao(diretor_id, "arquivo_passivo.consultar")
    assert not possui_permissao(diretor_id, "administracao.permissoes")


def test_revogacao_de_permissao():
    master_id = bootstrap_primeiro_master("Master3", "master3", "SenhaMasterForte3")
    from autenticacao.database import conectar
    conn = conectar()
    conta_master = conn.execute("SELECT id FROM contas WHERE pessoa_id = ?", (master_id,)).fetchone()["id"]
    conn.close()

    conta_destino = _criar_conta_comum("destino2")
    conceder_permissao(conta_destino, "almoxarifado.consultar", concedida_por=conta_master)
    assert possui_permissao(conta_destino, "almoxarifado.consultar")
    revogar_permissao(conta_destino, "almoxarifado.consultar", revogada_por=conta_master)
    assert not possui_permissao(conta_destino, "almoxarifado.consultar")


def test_auditoria_encadeada_detecta_integridade():
    registrar_evento(modulo="arquivo_passivo", acao="consultar", resultado="sucesso", conta_id=1)
    registrar_evento(modulo="arquivo_passivo", acao="cadastrar", resultado="sucesso", conta_id=1)
    assert verificar_integridade_cadeia()


def _contexto_master(login: str) -> ContextoAutorizacao:
    master_id = bootstrap_primeiro_master(f"Master {login}", login, "SenhaMasterForte1")
    from autenticacao.database import conectar
    conn = conectar()
    conta_master = conn.execute("SELECT id FROM contas WHERE pessoa_id = ?", (master_id,)).fetchone()["id"]
    conn.close()
    return _contexto_para(conta_master)


def test_auditoria_nao_registra_senha_ou_token():
    ctx_master = _contexto_master("master.audit1")
    registrar_evento(
        modulo="autenticacao", acao="reset_senha", resultado="sucesso", conta_id=1,
        campos_alterados={"password_hash": "segredo", "nome": "Fulano"},
    )
    eventos = buscar_eventos(ctx_master, conta_id=1, acao="reset_senha")
    assert len(eventos) == 1
    assert "segredo" not in (eventos[0]["campos_alterados"] or "")
    assert "Fulano" in (eventos[0]["campos_alterados"] or "")


def test_busca_auditoria_por_modulo_e_resultado():
    ctx_master = _contexto_master("master.audit2")
    registrar_evento(modulo="folha_ponto", acao="emitir", resultado="sucesso", conta_id=2)
    registrar_evento(modulo="folha_ponto", acao="emitir", resultado="negado", conta_id=3)
    sucessos = buscar_eventos(ctx_master, modulo="folha_ponto", resultado="sucesso")
    negados = buscar_eventos(ctx_master, modulo="folha_ponto", resultado="negado")
    assert len(sucessos) == 1 and sucessos[0]["conta_id"] == 2
    assert len(negados) == 1 and negados[0]["conta_id"] == 3


def test_auditoria_bloqueia_consulta_sem_ser_master():
    """Correção do diagnóstico: buscar_eventos agora exige Master dentro do serviço."""
    ctx_master = _contexto_master("master.audit3")
    conta_comum = _criar_conta_comum("comum.audit3")
    with pytest.raises(ErroPermissao):
        buscar_eventos(_contexto_para(conta_comum))


def test_listar_contas_exige_master():
    """Correção do diagnóstico: listar_contas não tinha NENHUMA verificação antes."""
    ctx_master = _contexto_master("master.listacontas")
    conta_comum = _criar_conta_comum("comum.listacontas")

    with pytest.raises(ErroPermissao):
        listar_contas(_contexto_para(conta_comum))

    contas = listar_contas(ctx_master)
    assert any(c["login_unico"] == "comum.listacontas" for c in contas)
