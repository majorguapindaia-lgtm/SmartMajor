"""UI de Administração: contas, permissões (lista compacta, não matriz de checkboxes),
catálogo de módulos e auditoria.

Correção de segurança (2ª etapa): esta tela antes só era protegida pelo filtro de
menu em app.py. Agora cada função também verifica `administracao.permissoes`
(Master) explicitamente aqui E dentro dos serviços chamados (defesa em profundidade).
"""
import streamlit as st

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import (
    conceder_permissao, revogar_permissao, listar_permissoes_da_conta, exigir_permissao, ErroPermissao,
)
from administracao.registro_modulos import listar_catalogo
from administracao.gerenciamento_acessos import (
    listar_contas, master_bloquear_conta, master_desbloquear_conta, master_iniciar_reset,
)
from administracao.auditoria_consulta import buscar_eventos
from autenticacao.recuperacao import ErroSMTPNaoConfigurado


def renderizar_administracao(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "administracao.permissoes")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    st.header("Administração")
    aba = st.radio("Tela", ["Contas e Permissões", "Auditoria", "Backups"], horizontal=True)
    if aba == "Contas e Permissões":
        _tela_contas_permissoes(contexto)
    elif aba == "Auditoria":
        _tela_auditoria(contexto)
    else:
        _tela_backups(contexto)


def _tela_contas_permissoes(contexto: ContextoAutorizacao):
    try:
        contas = listar_contas(contexto)
    except ErroPermissao as exc:
        st.error(str(exc))
        return
    if not contas:
        st.info("Nenhuma conta cadastrada.")
        return

    rotulos = {f"{c['nome']} ({c['login_unico']})": c for c in contas}
    escolhido = st.selectbox("Conta", list(rotulos.keys()))
    conta = rotulos[escolhido]

    col1, col2 = st.columns(2)
    with col1:
        if conta["ativa"] and not conta["bloqueada_at"]:
            if st.button("Bloquear conta"):
                try:
                    master_bloquear_conta(conta["id"], contexto)
                    st.success("Conta bloqueada.")
                except ErroPermissao as exc:
                    st.error(str(exc))
        else:
            if st.button("Desbloquear conta"):
                try:
                    master_desbloquear_conta(conta["id"], contexto)
                    st.success("Conta desbloqueada.")
                except ErroPermissao as exc:
                    st.error(str(exc))
    with col2:
        email_destino = st.text_input("E-mail para enviar redefinição de senha")
        if st.button("Iniciar redefinição de senha"):
            try:
                master_iniciar_reset(conta["id"], email_destino, contexto)
                st.success("E-mail de redefinição enviado.")
            except ErroSMTPNaoConfigurado as exc:
                st.error(str(exc))
            except ErroPermissao as exc:
                st.error(str(exc))

    st.divider()
    st.markdown("### Este usuário está autorizado a:")
    permissoes_atuais = listar_permissoes_da_conta(conta["id"])
    if not permissoes_atuais:
        st.caption("Nenhuma permissão concedida ainda.")
    catalogo = {c["permissao_completa"]: c["rotulo"] for c in listar_catalogo()}
    for permissao in permissoes_atuais:
        col_rotulo, col_editar, col_remover = st.columns([6, 1, 1])
        with col_rotulo:
            st.write(f"`{permissao}` — {catalogo.get(permissao, permissao)}")
        with col_remover:
            if st.button("Remover", key=f"remover_{permissao}"):
                try:
                    revogar_permissao(conta["id"], permissao, contexto)
                    st.rerun()
                except ErroPermissao as exc:
                    st.error(str(exc))

    with st.expander("+ Adicionar permissão"):
        opcoes_disponiveis = [p for p in catalogo if p not in permissoes_atuais]
        nova_permissao = st.selectbox("Módulo/Ação", opcoes_disponiveis,
                                       format_func=lambda p: catalogo.get(p, p))
        if st.button("Confirmar e salvar"):
            try:
                conceder_permissao(conta["id"], nova_permissao, contexto)
                st.success("Permissão concedida.")
                st.rerun()
            except ErroPermissao as exc:
                st.error(str(exc))


def _tela_auditoria(contexto: ContextoAutorizacao):
    st.subheader("Auditoria")
    col1, col2, col3 = st.columns(3)
    with col1:
        modulo = st.text_input("Módulo (opcional)")
    with col2:
        acao = st.text_input("Ação (opcional)")
    with col3:
        resultado = st.selectbox("Resultado", ["", "sucesso", "negado", "erro"])

    try:
        eventos = buscar_eventos(contexto, modulo=modulo or None, acao=acao or None, resultado=resultado or None)
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    import pandas as pd
    if eventos:
        st.dataframe(pd.DataFrame(eventos))
    else:
        st.info("Nenhum evento encontrado para os filtros informados.")


def _tela_backups(contexto: ContextoAutorizacao):
    st.subheader("Backups (somente Master)")
    st.caption(
        "Cria uma cópia consistente do banco com sqlite3.Connection.backup(), com "
        "data/hora no nome, em dados_privados/backups/. O banco original nunca é alterado."
    )

    opcoes = [
        ("core.db (pessoas, contas, permissões, auditoria)", "core"),
        ("arquivo_passivo.db", "arquivo_passivo"),
        ("folha_ponto.db", "folha_ponto"),
        ("almoxarifado.db", "almoxarifado"),
    ]
    rotulo_escolhido = st.selectbox("Banco", [r for r, _ in opcoes])
    chave = next(c for r, c in opcoes if r == rotulo_escolhido)

    if st.button("Criar backup agora"):
        try:
            if chave == "core":
                from administracao.backup import criar_backup
            elif chave == "arquivo_passivo":
                from arquivo_passivo.backup import criar_backup
            elif chave == "folha_ponto":
                from folha_ponto.backup import criar_backup
            else:
                from almoxarifado.backup import criar_backup
            caminho = criar_backup(contexto)
            st.success(f"Backup criado em: {caminho}")
        except ErroPermissao as exc:
            st.error(str(exc))
