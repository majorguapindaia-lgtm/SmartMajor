# Almoxarifado — Base Inicial

Apenas duas telas, conforme escopo aprovado: **Cadastrar Item** e **Consultar/Editar**.

**Fora de escopo nesta etapa (não implementado de propósito):** entrada/saída,
almoxarife, compras, empréstimos, inventário físico, conciliação contábil, alertas
complexos, reservas e gestão de patrimônio completa. Qualquer necessidade futura
deve voltar como requisito aprovado explicitamente — não implementar por conta própria.

Distingue material com quantidade de bem individual com tombamento (tombamento
opcional, único quando informado). Inativação no lugar de exclusão.
