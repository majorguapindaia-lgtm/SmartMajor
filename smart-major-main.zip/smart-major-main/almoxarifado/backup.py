"""Backup/restauração do banco SQLite do Almoxarifado (almoxarifado.db).

Correção de segurança (2ª etapa): mesma lacuna do folha_ponto.db — agora coberta."""
from pathlib import Path

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import conta_eh_master, ErroPermissao
from almoxarifado.database import caminho_db
from common.backup import (
    criar_backup_generico, verificar_integridade_generico, restaurar_em_caminho_separado_generico,
)


def _exigir_master(contexto: ContextoAutorizacao) -> None:
    if contexto is None or not isinstance(contexto, ContextoAutorizacao):
        raise ErroPermissao("Backup exige um contexto de autorização válido.")
    if not conta_eh_master(contexto.conta_id):
        raise ErroPermissao("Somente o Master pode executar backup/restauração.")


def criar_backup(contexto: ContextoAutorizacao) -> Path:
    _exigir_master(contexto)
    return criar_backup_generico(caminho_db(), "almoxarifado")


def verificar_integridade(caminho_backup: Path) -> bool:
    return verificar_integridade_generico(caminho_backup)


def restaurar_em_caminho_separado(caminho_backup: Path, caminho_destino: Path,
                                   contexto: ContextoAutorizacao) -> None:
    _exigir_master(contexto)
    restaurar_em_caminho_separado_generico(caminho_backup, caminho_destino)
