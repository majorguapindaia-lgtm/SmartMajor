"""Tela 1 — Cadastrar item."""
import streamlit as st

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import exigir_permissao, ErroPermissao
from almoxarifado.models import ErroValidacaoItem
from almoxarifado.services import cadastrar_item


def renderizar(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "almoxarifado.cadastrar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    st.subheader("Cadastrar Item")
    with st.form("form_cadastro_item", clear_on_submit=True):
        nome = st.text_input("Nome/descrição *")
        quantidade = st.number_input("Quantidade *", min_value=0.0, step=1.0)
        unidade = st.text_input("Unidade (opcional)")
        categoria = st.text_input("Categoria (opcional)")
        localizacao = st.text_input("Localização física (opcional)")
        numero_registro = st.text_input("Número de registro (opcional)")
        tombamento = st.text_input("Tombamento patrimonial (opcional, somente para bens individuais)")
        observacoes = st.text_area("Observações (opcional)")
        enviado = st.form_submit_button("Salvar")

    if enviado:
        try:
            item_id = cadastrar_item(
                nome, quantidade, contexto, unidade or None, categoria or None,
                localizacao or None, numero_registro or None, tombamento or None, observacoes or None,
            )
            st.success(f"Item cadastrado com sucesso (ID {item_id}).")
        except ErroValidacaoItem as exc:
            st.error(str(exc))
