"""Tela 2 — Consultar e editar itens."""
import streamlit as st

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import exigir_permissao, possui_permissao, ErroPermissao
from almoxarifado.models import ErroValidacaoItem
from almoxarifado.services import buscar_itens, editar_item, inativar_item


def renderizar(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "almoxarifado.consultar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    st.subheader("Consultar/Editar Itens")
    termo = st.text_input("Buscar por nome, categoria, localização, registro ou tombamento")
    itens = buscar_itens(contexto, termo=termo or None)

    if not itens:
        st.info("Nenhum item encontrado.")
        return

    rotulos = {f"{i['nome_descricao']} (ID {i['id']})": i for i in itens}
    escolhido = st.selectbox("Selecione um item", list(rotulos.keys()))
    item = rotulos[escolhido]
    st.json({k: v for k, v in item.items() if k not in ("criado_por", "atualizado_por")})

    pode_editar = possui_permissao(contexto.conta_id, "almoxarifado.editar")
    if not pode_editar:
        st.caption("Você não possui permissão para editar — apenas consulta.")
        return

    with st.form("form_editar_item"):
        quantidade = st.number_input("Quantidade", min_value=0.0, value=float(item["quantidade"]), step=1.0)
        localizacao = st.text_input("Localização física", value=item["localizacao_fisica"] or "")
        observacoes = st.text_area("Observações", value=item["observacoes"] or "")
        enviado = st.form_submit_button("Salvar alterações")

    if enviado:
        try:
            editar_item(item["id"], {
                "quantidade": quantidade, "localizacao_fisica": localizacao or None,
                "observacoes": observacoes or None,
            }, contexto)
            st.success("Item atualizado.")
        except ErroValidacaoItem as exc:
            st.error(str(exc))

    if st.button("Inativar item (saiu de uso)"):
        inativar_item(item["id"], contexto)
        st.success("Item inativado.")
