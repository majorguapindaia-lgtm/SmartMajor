"""Banco SQLite independente do Almoxarifado."""
import sqlite3
from pathlib import Path

from common.paths import caminho_banco

_SCHEMA = Path(__file__).resolve().parent / "schema.sql"


def caminho_db() -> Path:
    return caminho_banco("almoxarifado.db")


def conectar() -> sqlite3.Connection:
    conn = sqlite3.connect(caminho_db(), timeout=30)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


def inicializar() -> None:
    conn = conectar()
    try:
        conn.executescript(_SCHEMA.read_text(encoding="utf-8"))
        conn.commit()
    finally:
        conn.close()
