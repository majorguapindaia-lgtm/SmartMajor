"""Validações mínimas do Almoxarifado: distinguir material com quantidade de bem
individual com tombamento, sem avançar para gestão de patrimônio completa."""


class ErroValidacaoItem(Exception):
    pass


def validar_item(nome_descricao: str, quantidade, tombamento_patrimonial: str | None) -> None:
    if not nome_descricao or not nome_descricao.strip():
        raise ErroValidacaoItem("Nome/descrição é obrigatório.")
    if quantidade is None:
        raise ErroValidacaoItem("Quantidade é obrigatória.")
    try:
        valor = float(quantidade)
    except (TypeError, ValueError):
        raise ErroValidacaoItem("Quantidade deve ser numérica.")
    if valor < 0:
        raise ErroValidacaoItem("Quantidade não pode ser negativa.")
    # Tombamento é opcional (bens não patrimoniais não o exigem); quando informado,
    # a unicidade é verificada no serviço (escopo do próprio banco do almoxarifado).
