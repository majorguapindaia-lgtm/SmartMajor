"""Navegação interna do Almoxarifado: somente as duas telas aprovadas nesta etapa."""
import streamlit as st

from almoxarifado.database import inicializar
from almoxarifado import cadastro, consulta_edicao


def renderizar(contexto):
    inicializar()
    st.header("Almoxarifado")
    aba = st.radio("Tela", ["Cadastrar Item", "Consultar/Editar"], horizontal=True)
    if aba == "Cadastrar Item":
        cadastro.renderizar(contexto)
    else:
        consulta_edicao.renderizar(contexto)
