-- Banco SQLite independente do Almoxarifado (almoxarifado.db). Base inicial mínima:
-- apenas cadastro e consulta/edição. Sem entrada/saída, compras, empréstimos ou
-- inventário avançado (fora de escopo nesta etapa).

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_version (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    versao INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS itens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_descricao TEXT NOT NULL,
    quantidade REAL NOT NULL CHECK (quantidade >= 0),
    unidade TEXT,
    categoria TEXT,
    localizacao_fisica TEXT,
    numero_registro TEXT,
    tombamento_patrimonial TEXT,
    status TEXT NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo')),
    observacoes TEXT,
    criado_em TEXT NOT NULL,
    criado_por INTEGER,
    atualizado_em TEXT NOT NULL,
    atualizado_por INTEGER
);
CREATE INDEX IF NOT EXISTS idx_itens_nome ON itens(nome_descricao);
CREATE INDEX IF NOT EXISTS idx_itens_categoria ON itens(categoria);
CREATE UNIQUE INDEX IF NOT EXISTS idx_itens_tombamento_unico
    ON itens(tombamento_patrimonial) WHERE tombamento_patrimonial IS NOT NULL;

INSERT OR IGNORE INTO schema_version (id, versao) VALUES (1, 1);
