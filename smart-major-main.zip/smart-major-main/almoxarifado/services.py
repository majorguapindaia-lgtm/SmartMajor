"""Cadastro e consulta/edição de itens do Almoxarifado (base mínima, sem movimento
de estoque, empréstimo ou inventário avançado).

Correção de segurança: toda operação exige um ContextoAutorizacao validado e
verifica sua permissão granular dentro do próprio serviço."""
from administracao.contexto import ContextoAutorizacao, exigir
from almoxarifado.database import conectar
from almoxarifado.models import validar_item, ErroValidacaoItem
from common.tempo import agora_utc


def cadastrar_item(
    nome_descricao: str, quantidade, contexto: ContextoAutorizacao, unidade: str | None = None,
    categoria: str | None = None, localizacao_fisica: str | None = None,
    numero_registro: str | None = None, tombamento_patrimonial: str | None = None,
    observacoes: str | None = None,
) -> int:
    exigir(contexto, "almoxarifado.cadastrar")
    validar_item(nome_descricao, quantidade, tombamento_patrimonial)
    agora = agora_utc().isoformat()
    conn = conectar()
    try:
        if tombamento_patrimonial:
            existente = conn.execute(
                "SELECT 1 FROM itens WHERE tombamento_patrimonial = ?", (tombamento_patrimonial,)
            ).fetchone()
            if existente:
                raise ErroValidacaoItem(f"Tombamento '{tombamento_patrimonial}' já cadastrado.")

        cur = conn.execute(
            """INSERT INTO itens (nome_descricao, quantidade, unidade, categoria, localizacao_fisica,
                                   numero_registro, tombamento_patrimonial, status, observacoes,
                                   criado_em, criado_por, atualizado_em, atualizado_por)
               VALUES (?, ?, ?, ?, ?, ?, ?, 'ativo', ?, ?, ?, ?, ?)""",
            (nome_descricao.strip(), float(quantidade), unidade, categoria, localizacao_fisica,
             numero_registro, tombamento_patrimonial, observacoes, agora, contexto.conta_id, agora,
             contexto.conta_id),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def buscar_itens(contexto: ContextoAutorizacao, termo: str | None = None, categoria: str | None = None,
                  localizacao_fisica: str | None = None, numero_registro: str | None = None,
                  tombamento_patrimonial: str | None = None, apenas_ativos: bool = True) -> list[dict]:
    exigir(contexto, "almoxarifado.consultar")
    conn = conectar()
    try:
        sql = "SELECT * FROM itens WHERE 1=1"
        params: list = []
        if apenas_ativos:
            sql += " AND status = 'ativo'"
        if termo:
            sql += " AND nome_descricao LIKE ?"
            params.append(f"%{termo}%")
        if categoria:
            sql += " AND categoria = ?"
            params.append(categoria)
        if localizacao_fisica:
            sql += " AND localizacao_fisica LIKE ?"
            params.append(f"%{localizacao_fisica}%")
        if numero_registro:
            sql += " AND numero_registro = ?"
            params.append(numero_registro)
        if tombamento_patrimonial:
            sql += " AND tombamento_patrimonial = ?"
            params.append(tombamento_patrimonial)
        sql += " ORDER BY nome_descricao"
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()


def editar_item(item_id: int, campos: dict, contexto: ContextoAutorizacao) -> None:
    exigir(contexto, "almoxarifado.editar")
    permitidos = {
        "nome_descricao", "quantidade", "unidade", "categoria", "localizacao_fisica",
        "numero_registro", "tombamento_patrimonial", "status", "observacoes",
    }
    campos_validos = {k: v for k, v in campos.items() if k in permitidos}
    if not campos_validos:
        return

    conn = conectar()
    try:
        item = conn.execute("SELECT * FROM itens WHERE id = ?", (item_id,)).fetchone()
        if item is None:
            raise ErroValidacaoItem("Item não encontrado.")

        if "quantidade" in campos_validos:
            validar_item(
                campos_validos.get("nome_descricao", item["nome_descricao"]),
                campos_validos["quantidade"],
                campos_validos.get("tombamento_patrimonial", item["tombamento_patrimonial"]),
            )

        novo_tombamento = campos_validos.get("tombamento_patrimonial")
        if novo_tombamento and novo_tombamento != item["tombamento_patrimonial"]:
            existente = conn.execute(
                "SELECT 1 FROM itens WHERE tombamento_patrimonial = ? AND id != ?",
                (novo_tombamento, item_id),
            ).fetchone()
            if existente:
                raise ErroValidacaoItem(f"Tombamento '{novo_tombamento}' já cadastrado em outro item.")

        set_sql = ", ".join(f"{k} = ?" for k in campos_validos)
        valores = list(campos_validos.values()) + [agora_utc().isoformat(), contexto.conta_id, item_id]
        conn.execute(
            f"UPDATE itens SET {set_sql}, atualizado_em = ?, atualizado_por = ? WHERE id = ?",
            valores,
        )
        conn.commit()
    finally:
        conn.close()


def inativar_item(item_id: int, contexto: ContextoAutorizacao) -> None:
    """Item que saiu de uso é inativado, nunca apagado."""
    editar_item(item_id, {"status": "inativo"}, contexto)
