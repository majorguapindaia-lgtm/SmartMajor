import pytest

from administracao.contexto import ContextoAutorizacao
from administracao.database import inicializar as inicializar_admin
from autenticacao.database import inicializar as inicializar_core
from autenticacao.bootstrap_master import bootstrap_primeiro_master

from almoxarifado.database import inicializar, conectar
from almoxarifado.models import ErroValidacaoItem
from almoxarifado.services import cadastrar_item, buscar_itens, editar_item, inativar_item


@pytest.fixture
def ctx() -> ContextoAutorizacao:
    inicializar()
    inicializar_core()
    inicializar_admin()
    pessoa_id = bootstrap_primeiro_master("Master Almox", "master.almox.teste", "SenhaMasterForte1")
    from autenticacao.database import conectar as conectar_core
    conn = conectar_core()
    conta_id = conn.execute("SELECT id FROM contas WHERE pessoa_id = ?", (pessoa_id,)).fetchone()["id"]
    conn.close()
    return ContextoAutorizacao(conta_id=conta_id)


def test_cadastrar_item_material_com_quantidade(ctx):
    item_id = cadastrar_item("Caixa de papel A4", 50, ctx, unidade="pacotes", categoria="material")
    assert item_id is not None


def test_cadastrar_bem_individual_com_tombamento(ctx):
    item_id = cadastrar_item("Notebook Dell", 1, ctx, categoria="equipamento", tombamento_patrimonial="PAT-001")
    conn = conectar()
    item = conn.execute("SELECT * FROM itens WHERE id = ?", (item_id,)).fetchone()
    conn.close()
    assert item["tombamento_patrimonial"] == "PAT-001"


def test_tombamento_nao_exigido_para_item_nao_patrimonial(ctx):
    item_id = cadastrar_item("Resma de papel", 10, ctx)
    assert item_id is not None


def test_rejeita_quantidade_negativa(ctx):
    with pytest.raises(ErroValidacaoItem):
        cadastrar_item("Item Inválido", -5, ctx)


def test_rejeita_nome_vazio(ctx):
    with pytest.raises(ErroValidacaoItem):
        cadastrar_item("", 10, ctx)


def test_tombamento_unico(ctx):
    cadastrar_item("Equipamento 1", 1, ctx, tombamento_patrimonial="PAT-100")
    with pytest.raises(ErroValidacaoItem):
        cadastrar_item("Equipamento 2", 1, ctx, tombamento_patrimonial="PAT-100")


def test_consulta_por_nome_categoria_localizacao(ctx):
    cadastrar_item("Cadeira Escolar", 30, ctx, categoria="mobiliario", localizacao_fisica="Deposito A")
    resultados = buscar_itens(ctx, termo="Cadeira")
    assert len(resultados) == 1
    assert buscar_itens(ctx, categoria="mobiliario")
    assert buscar_itens(ctx, localizacao_fisica="Deposito")


def test_edicao_com_trilha_de_auditoria_basica(ctx):
    item_id = cadastrar_item("Item Editável", 5, ctx)
    editar_item(item_id, {"quantidade": 8, "observacoes": "Reposição"}, ctx)
    conn = conectar()
    item = conn.execute("SELECT * FROM itens WHERE id = ?", (item_id,)).fetchone()
    conn.close()
    assert item["quantidade"] == 8
    assert item["atualizado_por"] == ctx.conta_id


def test_inativacao_nao_apaga_registro(ctx):
    item_id = cadastrar_item("Item Fora de Uso", 2, ctx)
    inativar_item(item_id, ctx)
    conn = conectar()
    item = conn.execute("SELECT * FROM itens WHERE id = ?", (item_id,)).fetchone()
    conn.close()
    assert item is not None
    assert item["status"] == "inativo"
    assert item_id not in [i["id"] for i in buscar_itens(ctx, apenas_ativos=True)]


def test_nenhuma_tabela_de_movimentacao_estoque_foi_criada(ctx):
    """Confirma que o escopo avançado (entrada/saída/empréstimo) não foi implementado."""
    conn = conectar()
    tabelas = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    conn.close()
    assert tabelas == {"schema_version", "itens", "sqlite_sequence"} or tabelas == {"schema_version", "itens"}
