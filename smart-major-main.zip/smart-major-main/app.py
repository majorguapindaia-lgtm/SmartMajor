"""Smart Major — ponto de entrada do Streamlit.

Responsável apenas por bootstrap, autenticação e navegação. A verificação de
permissão também ocorre no ponto que executa cada ação (não só aqui no menu):
nos Relatórios do Diário Eletrônico, todo robô do SDE passa por
relatorios_sde_ui._executar_robo, que revalida a permissão antes de rodar.
"""
import sys
from pathlib import Path

import streamlit as st

# Precisa ser o primeiro comando Streamlit da execução.
st.set_page_config(page_title="Smart Major", page_icon="🏫", layout="wide")

DIRETORIO_RAIZ = Path(__file__).parent.resolve()
if str(DIRETORIO_RAIZ) not in sys.path:
    sys.path.append(str(DIRETORIO_RAIZ))

from autenticacao.database import inicializar as inicializar_autenticacao  # noqa: E402
from administracao.database import inicializar as inicializar_administracao  # noqa: E402
from administracao.registro_modulos import semear_catalogo_inicial  # noqa: E402
from administracao.permissoes import possui_permissao  # noqa: E402
from administracao.contexto import obter_contexto, ErroContextoInvalido  # noqa: E402
from autenticacao.login import autenticar  # noqa: E402
from autenticacao.sessoes import revogar_sessao  # noqa: E402

CAMINHO_LOGO = DIRETORIO_RAIZ / "logo_major.png"
LOGO_RESERVA = "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"

MODULOS_DISPONIVEIS = [
    ("Arquivo Passivo", "arquivo_passivo.consultar"),
    ("Folha de Ponto", "folha_ponto.consultar"),
    ("Cadastro de Funcionários", "funcionarios.consultar"),
    ("Almoxarifado", "almoxarifado.consultar"),
    ("Relatórios do Diário Eletrônico", "relatorios.consultar"),
    ("Administração", "administracao.permissoes"),
]


def _bootstrap_banco() -> None:
    inicializar_autenticacao()
    inicializar_administracao()
    semear_catalogo_inicial()


def _limpar_sessao() -> None:
    """Apaga a sessão inteira: token, credenciais do SDE e resultados com dados de alunos."""
    for chave in list(st.session_state.keys()):
        del st.session_state[chave]


def _sair() -> None:
    # Callback do botão "Sair": roda antes do rerun, quando ainda é permitido
    # apagar chaves de widgets (credenciais do SDE). Fora de callback, o
    # Streamlit recusa alterar um widget que já foi desenhado.
    token = st.session_state.get("token_sessao")
    try:
        if token:
            revogar_sessao(token)
    finally:
        _limpar_sessao()


def _exibir_logo() -> None:
    if CAMINHO_LOGO.exists():
        st.sidebar.image(str(CAMINHO_LOGO), use_container_width=True)
    else:
        st.sidebar.image(LOGO_RESERVA, width=90)


def _tela_login() -> None:
    st.title("Smart Major")
    st.caption("Acesso restrito. Faça login para continuar.")
    with st.form("form_login"):
        login_unico = st.text_input("Login")
        senha = st.text_input("Senha", type="password")
        enviado = st.form_submit_button("Entrar")
    if enviado:
        resultado = autenticar(login_unico, senha)
        if resultado.sucesso:
            st.session_state["token_sessao"] = resultado.token_sessao
            st.rerun()
        else:
            st.error(resultado.mensagem)


def _tela_principal(contexto) -> None:
    _exibir_logo()
    st.sidebar.title("Smart Major")
    st.sidebar.caption("Automações da Secretaria Escolar")
    st.sidebar.button("Sair", on_click=_sair)

    itens_permitidos = [
        nome for nome, permissao in MODULOS_DISPONIVEIS if possui_permissao(contexto.conta_id, permissao)
    ]
    if not itens_permitidos:
        st.warning(
            "Sua conta não possui nenhuma permissão concedida ainda. "
            "Contate o Master para solicitar acesso."
        )
        return

    escolha = st.sidebar.radio("Módulos", itens_permitidos)

    if escolha == "Arquivo Passivo":
        from arquivo_passivo.modulo import renderizar
        renderizar(contexto)
    elif escolha == "Folha de Ponto":
        from folha_ponto.modulo import renderizar
        renderizar(contexto)
    elif escolha == "Cadastro de Funcionários":
        from autenticacao_ui import renderizar_cadastro_funcionarios
        renderizar_cadastro_funcionarios(contexto)
    elif escolha == "Almoxarifado":
        from almoxarifado.modulo import renderizar
        renderizar(contexto)
    elif escolha == "Relatórios do Diário Eletrônico":
        from relatorios_sde_ui import renderizar_relatorios_sde
        renderizar_relatorios_sde(contexto)
    elif escolha == "Administração":
        from administracao_ui import renderizar_administracao
        renderizar_administracao(contexto)


def main() -> None:
    _bootstrap_banco()
    token = st.session_state.get("token_sessao")
    try:
        contexto = obter_contexto(token)
    except ErroContextoInvalido:
        if token:
            # Sessão expirada ou revogada: não deixa credenciais do SDE nem
            # dados de alunos para trás na memória da sessão.
            _limpar_sessao()
        _tela_login()
        return
    _tela_principal(contexto)


if __name__ == "__main__":
    main()