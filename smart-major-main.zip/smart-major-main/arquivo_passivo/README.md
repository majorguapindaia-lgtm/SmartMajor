# Arquivo Passivo

Espelho digital da organização física real das pastas de alunos. **Não digitaliza
documentos** — armazena apenas dados cadastrais, localização física e histórico.

## Regra inegociável

O número da caixa e a posição são **informados pelo operador**, nunca calculados,
corrigidos ou renumerados pelo sistema. A letra da caixa é só uma orientação.

## Arquivos

- `database.py` — conexão/inicialização de `dados_privados/arquivo_passivo.db` (independente dos demais módulos).
- `models.py` — decomposição/validação de nomes, normalização e chave fonética simplificada.
- `services.py` — cadastro, edição, movimentação e ocorrências.
- `pesquisa.py` — busca aproximada (RapidFuzz) por token, com limiar permissivo calibrado em testes.
- `importacao.py` — importação de planilha Excel com prévia e gravação transacional.
- `backup.py` — backup/restauração via `sqlite3.Connection.backup()`.
- `modulo.py` — as três telas Streamlit (Cadastro / Pesquisa e Estante Virtual / Edição e Gerenciamento).

## Testes

`pytest arquivo_passivo` executa os 24 cenários do capítulo 15 do Anexo A, mais 1 teste
adicional confirmando que nenhuma caixa é criada automaticamente por sugestão algorítmica.

## Integração com o app.py

Chamar `arquivo_passivo.modulo.renderizar(conta_id)` a partir da navegação existente,
após obter `conta_id` válido via `autenticacao` e confirmar
`administracao.permissoes.possui_permissao(conta_id, "arquivo_passivo.consultar")`
(ou a ação equivalente) para decidir se o item aparece no menu.
