"""Backup/restauração do banco SQLite do Arquivo Passivo.

Correção de segurança: backup/restauração é ação administrativa — exige contexto
autorizado e conta Master. Reutiliza o mecanismo genérico de common/backup.py
(sqlite3.Connection.backup()), preservando a interface pública original deste
módulo (mesmos nomes/assinaturas usados pelos testes do capítulo 15 do Anexo A)."""
from pathlib import Path

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import conta_eh_master, ErroPermissao
from arquivo_passivo.database import caminho_db
from common.backup import (
    criar_backup_generico, verificar_integridade_generico, restaurar_em_caminho_separado_generico,
)


def _exigir_master(contexto: ContextoAutorizacao) -> None:
    if contexto is None or not isinstance(contexto, ContextoAutorizacao):
        raise ErroPermissao("Backup exige um contexto de autorização válido.")
    if not conta_eh_master(contexto.conta_id):
        raise ErroPermissao("Somente o Master pode executar backup/restauração.")


def criar_backup(contexto: ContextoAutorizacao) -> Path:
    _exigir_master(contexto)
    return criar_backup_generico(caminho_db(), "arquivo_passivo")


def verificar_integridade(caminho_backup: Path) -> bool:
    return verificar_integridade_generico(caminho_backup)


def restaurar_em_caminho_separado(caminho_backup: Path, caminho_destino: Path,
                                   contexto: ContextoAutorizacao) -> None:
    _exigir_master(contexto)
    restaurar_em_caminho_separado_generico(caminho_backup, caminho_destino)
