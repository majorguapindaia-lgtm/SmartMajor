"""Importação de planilha Excel existente: prévia, validação e gravação transacional.

Não inventa caixas/posições que não estejam na planilha ou confirmadas pelo operador.
"""
from dataclasses import dataclass, field

import pandas as pd

from administracao.contexto import ContextoAutorizacao, exigir
from arquivo_passivo.database import conectar
from arquivo_passivo.models import decompor_nome, normalizar_para_busca, ErroValidacaoPasta
from arquivo_passivo.services import _cadastrar_caixa_na_conexao, _posicao_ocupada
from common.tempo import agora_utc

COLUNAS_OBRIGATORIAS = {"nome", "formato_informado", "ano_referencia", "concluinte", "caixa", "posicao"}


@dataclass
class LinhaPreview:
    indice: int
    dados: dict
    valida: bool
    erro: str | None = None
    possivel_duplicidade: bool = False


@dataclass
class ResultadoPreview:
    linhas: list[LinhaPreview] = field(default_factory=list)

    @property
    def validas(self) -> list[LinhaPreview]:
        return [l for l in self.linhas if l.valida]

    @property
    def invalidas(self) -> list[LinhaPreview]:
        return [l for l in self.linhas if not l.valida]


def gerar_preview(caminho_excel_ou_df, contexto: ContextoAutorizacao) -> ResultadoPreview:
    exigir(contexto, "arquivo_passivo.cadastrar")
    df = caminho_excel_ou_df if isinstance(caminho_excel_ou_df, pd.DataFrame) else pd.read_excel(caminho_excel_ou_df)
    colunas_presentes = {c.strip().lower() for c in df.columns}
    faltantes = COLUNAS_OBRIGATORIAS - colunas_presentes
    if faltantes:
        raise ValueError(f"Colunas obrigatórias ausentes na planilha: {sorted(faltantes)}")

    df.columns = [c.strip().lower() for c in df.columns]

    conn = conectar()
    try:
        nomes_existentes = {
            r["nome_normalizado"] for r in conn.execute("SELECT nome_normalizado FROM pastas").fetchall()
        }
    finally:
        conn.close()

    resultado = ResultadoPreview()
    vistos_nesta_importacao: set[str] = set()

    for indice, linha in df.iterrows():
        dados = {k: linha[k] for k in df.columns}
        try:
            nome = str(dados.get("nome", "")).strip()
            formato = str(dados.get("formato_informado", "")).strip().lower()
            decomposto = decompor_nome(nome, formato)
            nome_norm = normalizar_para_busca(decomposto.nome_ordem_convencional)
            duplicado = nome_norm in nomes_existentes or nome_norm in vistos_nesta_importacao
            vistos_nesta_importacao.add(nome_norm)

            if pd.isna(dados.get("ano_referencia")):
                raise ErroValidacaoPasta("Ano de referência ausente.")
            if str(dados.get("concluinte", "")).strip() not in ("Sim", "Nao"):
                raise ErroValidacaoPasta("Concluinte deve ser 'Sim' ou 'Nao'.")
            if pd.isna(dados.get("caixa")) or pd.isna(dados.get("posicao")):
                raise ErroValidacaoPasta("Caixa e posição são obrigatórias.")

            resultado.linhas.append(LinhaPreview(
                indice=int(indice), dados=dados, valida=True, possivel_duplicidade=duplicado,
            ))
        except Exception as exc:
            resultado.linhas.append(LinhaPreview(indice=int(indice), dados=dados, valida=False, erro=str(exc)))

    return resultado


def importar_linhas_confirmadas(linhas: list[LinhaPreview], contexto: ContextoAutorizacao) -> int:
    """Importa somente as linhas explicitamente confirmadas pelo operador, em transação única.
    Caixas novas são criadas NA MESMA transação/conexão das pastas — nada fica órfão
    se qualquer linha falhar."""
    exigir(contexto, "arquivo_passivo.cadastrar")
    conn = conectar()
    try:
        total_importado = 0
        for linha in linhas:
            if not linha.valida:
                continue
            dados = linha.dados
            nome = str(dados["nome"]).strip()
            formato = str(dados["formato_informado"]).strip().lower()
            decomposto = decompor_nome(nome, formato)

            letra_informada, numero_str = str(dados["caixa"]).strip().split("-") \
                if "-" in str(dados["caixa"]) else (str(dados["caixa"])[0], str(dados["caixa"])[1:] or "1")
            caixa_id = _cadastrar_caixa_na_conexao(
                conn, letra_informada, int(numero_str), contexto.conta_id, None, commit=False,
            )

            posicao = int(dados["posicao"])
            if _posicao_ocupada(conn, caixa_id, posicao):
                raise ErroValidacaoPasta(f"Posição {posicao} já ocupada na caixa {dados['caixa']}.")

            agora = agora_utc().isoformat()
            conn.execute(
                """INSERT INTO pastas (
                    nome_original, formato_informado, nome_normalizado, nome_padrao_arquivo,
                    nome_ordem_convencional, primeiro_nome, demais_nomes, ultimo_sobrenome,
                    letra_classificacao, ano_referencia, concluinte, caixa_id, posicao,
                    situacao_fisica, situacao_academica, observacoes, criado_em, criado_por,
                    atualizado_em, atualizado_por
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Disponivel', ?, ?, ?, ?, ?, ?)""",
                (
                    nome, formato, normalizar_para_busca(decomposto.nome_ordem_convencional),
                    decomposto.nome_padrao_arquivo, decomposto.nome_ordem_convencional,
                    decomposto.primeiro_nome, decomposto.demais_nomes, decomposto.ultimo_sobrenome,
                    decomposto.letra_classificacao, int(dados["ano_referencia"]), str(dados["concluinte"]).strip(),
                    caixa_id, posicao, dados.get("situacao_academica"), dados.get("observacoes"),
                    agora, contexto.conta_id, agora, contexto.conta_id,
                ),
            )
            total_importado += 1
        conn.commit()
        return total_importado
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
