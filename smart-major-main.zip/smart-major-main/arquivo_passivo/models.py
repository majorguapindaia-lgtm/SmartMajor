"""Regras de nome, classificação e validação dos registros do Arquivo Passivo."""
import unicodedata
from dataclasses import dataclass

SITUACOES_FISICAS = {"Disponivel", "Desaparecida", "Danificada", "Destruida", "Outra"}
SITUACOES_QUE_GERAM_OCORRENCIA = {"Desaparecida", "Danificada", "Destruida"}


class ErroValidacaoPasta(Exception):
    pass


def remover_acentos(texto: str) -> str:
    nfkd = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def normalizar_para_busca(texto: str) -> str:
    """Minúsculas, sem acento, espaços colapsados — base para a busca aproximada."""
    sem_acento = remover_acentos(texto or "")
    minusculo = sem_acento.lower()
    colapsado = " ".join(minusculo.split())
    return colapsado.strip()


def chave_fonetica(texto: str) -> str:
    """Normaliza equivalências fonéticas comuns (I/E/Y, O/U) para ampliar a recuperação."""
    base = normalizar_para_busca(texto)
    base = base.replace("y", "i").replace("e", "i")
    base = base.replace("u", "o")
    return base


@dataclass
class NomeDecomposto:
    nome_ordem_convencional: str
    nome_padrao_arquivo: str
    primeiro_nome: str
    demais_nomes: str
    ultimo_sobrenome: str
    letra_classificacao: str


def decompor_nome(nome_original: str, formato_informado: str) -> NomeDecomposto:
    """Converte entre os dois formatos aceitos e extrai último sobrenome/letra.

    Regra simples e deliberada (conforme Anexo A): na ordem convencional, a ÚLTIMA
    PALAVRA do nome é o último sobrenome — sem tratamento especial de partículas
    (da, dos, de) e sem lógica de sobrenomes compostos.
    """
    nome_original = (nome_original or "").strip()
    if not nome_original:
        raise ErroValidacaoPasta("Nome é obrigatório.")

    if formato_informado == "arquivo":
        if "," not in nome_original:
            raise ErroValidacaoPasta(
                "Nome no padrão do arquivo deve seguir 'Sobrenome, Resto do nome'."
            )
        sobrenome_informado, resto = nome_original.split(",", 1)
        sobrenome_informado = sobrenome_informado.strip()
        resto = resto.strip()
        nome_convencional = f"{resto} {sobrenome_informado}".strip()
        nome_padrao_arquivo = f"{sobrenome_informado}, {resto}"
    elif formato_informado == "convencional":
        nome_convencional = nome_original
        palavras = nome_convencional.split()
        if len(palavras) < 2:
            raise ErroValidacaoPasta("Informe nome e ao menos um sobrenome.")
        sobrenome_informado = palavras[-1]
        resto = " ".join(palavras[:-1])
        nome_padrao_arquivo = f"{sobrenome_informado}, {resto}"
    else:
        raise ErroValidacaoPasta(f"Formato de nome inválido: {formato_informado}")

    palavras_convencional = nome_convencional.split()
    if len(palavras_convencional) < 2:
        raise ErroValidacaoPasta("Informe nome e ao menos um sobrenome.")

    primeiro_nome = palavras_convencional[0]
    ultimo_sobrenome = palavras_convencional[-1]
    demais_nomes = " ".join(palavras_convencional[1:-1])
    letra_classificacao = remover_acentos(ultimo_sobrenome[0]).upper()

    return NomeDecomposto(
        nome_ordem_convencional=nome_convencional,
        nome_padrao_arquivo=nome_padrao_arquivo,
        primeiro_nome=primeiro_nome,
        demais_nomes=demais_nomes,
        ultimo_sobrenome=ultimo_sobrenome,
        letra_classificacao=letra_classificacao,
    )


def validar_dados_pasta(
    nome: str, formato_informado: str, ano_referencia, concluinte: str,
    caixa_id, posicao, situacao_fisica: str,
) -> None:
    if not nome or not nome.strip():
        raise ErroValidacaoPasta("Nome completo é obrigatório.")
    if formato_informado not in ("convencional", "arquivo"):
        raise ErroValidacaoPasta("Formato do nome é obrigatório (convencional ou arquivo).")
    if not ano_referencia:
        raise ErroValidacaoPasta("Ano de referência é obrigatório.")
    if concluinte not in ("Sim", "Nao"):
        raise ErroValidacaoPasta("Concluinte deve ser 'Sim' ou 'Nao'.")
    if not caixa_id:
        raise ErroValidacaoPasta("Caixa física é obrigatória.")
    if posicao is None or int(posicao) < 1:
        raise ErroValidacaoPasta("Posição física é obrigatória e deve ser positiva.")
    if situacao_fisica not in SITUACOES_FISICAS:
        raise ErroValidacaoPasta(f"Situação física inválida: {situacao_fisica}")
