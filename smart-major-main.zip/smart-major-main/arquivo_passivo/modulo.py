"""Interface Streamlit do Arquivo Passivo: as três telas do Anexo A.

1. Cadastro de Pastas
2. Pesquisa e Estante Virtual
3. Edição e Gerenciamento

Correção de segurança: a permissão é verificada tanto aqui (para esconder o módulo)
quanto DENTRO de cada serviço chamado (administracao.contexto.exigir), de modo que
um acesso direto não autorizado seja negado mesmo contornando esta tela inteiramente.
"""
import streamlit as st

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import exigir_permissao, ErroPermissao
from arquivo_passivo.database import inicializar
from arquivo_passivo.models import ErroValidacaoPasta, SITUACOES_FISICAS
from arquivo_passivo import services, pesquisa, backup


def renderizar(contexto: ContextoAutorizacao):
    inicializar()
    st.header("Arquivo Passivo")
    aba = st.radio("Tela", ["1. Cadastro", "2. Pesquisa e Estante Virtual", "3. Edição e Gerenciamento"],
                    horizontal=True)
    if aba == "1. Cadastro":
        _tela_cadastro(contexto)
    elif aba == "2. Pesquisa e Estante Virtual":
        _tela_pesquisa(contexto)
    else:
        _tela_edicao(contexto)


def _tela_cadastro(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "arquivo_passivo.cadastrar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    st.subheader("Cadastro de Pastas")
    caixas = services.listar_caixas(contexto)
    opcoes_caixa = {c["codigo"]: c["id"] for c in caixas}

    with st.form("form_cadastro_pasta", clear_on_submit=True):
        nome = st.text_input("Nome completo *")
        formato = st.radio("Formato do nome informado *",
                            ["convencional", "arquivo"],
                            format_func=lambda v: "Convencional (Rafael João Cardoso)" if v == "convencional"
                            else "Padrão do arquivo (Cardoso, Rafael João)")
        ano = st.number_input("Ano de referência *", min_value=1900, max_value=2100, step=1)
        concluinte = st.radio("Concluinte *", ["Sim", "Nao"])

        col1, col2 = st.columns(2)
        with col1:
            codigo_caixa = st.selectbox("Caixa física *", options=list(opcoes_caixa.keys()) + ["+ Nova caixa"])
        with col2:
            posicao = st.number_input("Posição física *", min_value=1, step=1)

        nova_letra, novo_numero = None, None
        if codigo_caixa == "+ Nova caixa":
            nova_letra = st.text_input("Letra da nova caixa")
            novo_numero = st.number_input("Número da nova caixa", min_value=1, step=1)

        situacao_fisica = st.selectbox("Situação física *", sorted(SITUACOES_FISICAS))
        situacao_academica = st.text_input("Situação acadêmica adicional (opcional)")
        observacoes = st.text_area("Observações (opcional)")

        enviado = st.form_submit_button("Salvar cadastro")

    if enviado:
        try:
            # cadastrar_pasta cria a caixa nova (se houver) na MESMA transação da
            # pasta — se a validação falhar, nenhuma caixa órfã é persistida.
            pasta_id = services.cadastrar_pasta(
                nome, formato, int(ano), concluinte, int(posicao), situacao_fisica, contexto,
                caixa_id=(None if codigo_caixa == "+ Nova caixa" else opcoes_caixa[codigo_caixa]),
                nova_caixa_letra=nova_letra, nova_caixa_numero=(int(novo_numero) if novo_numero else None),
                situacao_academica=situacao_academica or None, observacoes=observacoes or None,
            )
            st.success(f"Pasta cadastrada com sucesso (ID {pasta_id}).")
        except ErroValidacaoPasta as exc:
            st.error(str(exc))


def _tela_pesquisa(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "arquivo_passivo.consultar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    st.subheader("Pesquisa")
    col1, col2, col3 = st.columns(3)
    with col1:
        termo = st.text_input("Nome, parte do nome ou sobrenome")
    with col2:
        ano = st.text_input("Ano (opcional)")
    with col3:
        codigo_caixa_filtro = st.text_input("Código da caixa (opcional)")

    ha_filtro = bool(termo or ano or codigo_caixa_filtro)
    resultados = pesquisa.pesquisar_pastas(
        contexto, termo=termo or None, ano=int(ano) if ano else None,
        codigo_caixa=codigo_caixa_filtro or None,
    )

    st.subheader("Estante Virtual")
    caixas = services.listar_caixas(contexto)

    if not caixas:
        # Correção do diagnóstico: banco vazio é um caso DIFERENTE de busca sem
        # resultado — a mensagem anterior confundia os dois.
        st.info("Nenhuma caixa cadastrada ainda. Use a tela de Cadastro para registrar a primeira caixa.")
        return

    caixas_filtradas = (
        [c for c in caixas if c["id"] in pesquisa.caixas_com_resultados(resultados)]
        if ha_filtro else caixas
    )

    if not caixas_filtradas:
        st.info("Nenhuma caixa corresponde aos critérios de pesquisa informados.")
        return

    colunas = st.columns(4)
    for indice, caixa in enumerate(caixas_filtradas):
        pastas_caixa = services.pastas_da_caixa(caixa["id"], contexto)
        disponiveis = [p for p in pastas_caixa if p["situacao_fisica"] == "Disponivel"]
        with colunas[indice % 4]:
            with st.container(border=True):
                st.markdown(f"**{caixa['codigo']}**")
                st.caption(f"{len(pastas_caixa)} pastas · {len(disponiveis)} disponíveis")
                if st.button("Abrir", key=f"abrir_{caixa['id']}"):
                    st.session_state["caixa_aberta"] = caixa["id"]

    caixa_aberta_id = st.session_state.get("caixa_aberta")
    if caixa_aberta_id:
        st.divider()
        caixa_info = next((c for c in caixas if c["id"] == caixa_aberta_id), None)
        if caixa_info:
            st.markdown(f"### Caixa {caixa_info['codigo']}")
            for pasta in services.pastas_da_caixa(caixa_aberta_id, contexto):
                st.write(
                    f"Posição {pasta['posicao']} — {pasta['nome_ordem_convencional']} "
                    f"({pasta['ano_referencia']}, concluinte: {pasta['concluinte']}) — "
                    f"{pasta['situacao_fisica']}"
                )

    if termo and resultados:
        st.divider()
        st.markdown("### Resultados da pesquisa")
        for r in resultados:
            st.write(
                f"{r['similaridade']:.0f}% — {r['nome_ordem_convencional']} — "
                f"{r['codigo_caixa']}, posição {r['posicao']} — {r['situacao_fisica']}"
            )


def _tela_edicao(contexto: ContextoAutorizacao):
    st.subheader("Edição e Gerenciamento")
    try:
        exigir_permissao(contexto.conta_id, "arquivo_passivo.editar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    termo_edicao = st.text_input("Buscar pasta para editar")
    if not termo_edicao:
        st.info("Digite um nome, ano ou código de caixa para localizar o registro.")
        return

    candidatos = pesquisa.pesquisar_pastas(contexto, termo=termo_edicao)
    if not candidatos:
        st.warning("Nenhum registro encontrado.")
        return

    rotulos = {f"{c['nome_ordem_convencional']} — {c['codigo_caixa']}/{c['posicao']}": c["id"] for c in candidatos}
    escolhido = st.selectbox("Selecione o registro", list(rotulos.keys()))
    pasta_id = rotulos[escolhido]

    st.markdown("#### Movimentar pasta")
    caixas = services.listar_caixas(contexto)
    opcoes_caixa = {c["codigo"]: c["id"] for c in caixas}
    nova_caixa = st.selectbox("Nova caixa", list(opcoes_caixa.keys()), key="mov_caixa")
    nova_posicao = st.number_input("Nova posição", min_value=1, step=1, key="mov_pos")
    motivo = st.text_input("Motivo da movimentação")
    if st.button("Registrar movimentação"):
        try:
            try:
                exigir_permissao(contexto.conta_id, "arquivo_passivo.movimentar")
            except ErroPermissao as exc:
                st.error(str(exc))
                return
            services.mover_pasta(pasta_id, opcoes_caixa[nova_caixa], int(nova_posicao), motivo, contexto)
            st.success("Movimentação registrada.")
        except ErroValidacaoPasta as exc:
            st.error(str(exc))

    st.markdown("#### Ocorrência")
    tipo_ocorrencia = st.selectbox("Tipo", ["Desaparecida", "Danificada", "Destruida",
                                             "Encontrada apos desaparecimento", "Outra"])
    descricao_ocorrencia = st.text_area("Descrição da ocorrência")
    if st.button("Registrar ocorrência"):
        try:
            exigir_permissao(contexto.conta_id, "arquivo_passivo.ocorrencia")
        except ErroPermissao as exc:
            st.error(str(exc))
            return
        services.registrar_ocorrencia(pasta_id, None, tipo_ocorrencia, contexto, descricao_ocorrencia)
        st.success("Ocorrência registrada.")

    st.markdown("#### Histórico")
    for m in services.historico_movimentacoes(pasta_id, contexto):
        st.caption(f"{m['data_hora']} — caixa {m['caixa_origem_id']} → {m['caixa_destino_id']}, "
                   f"posição {m['posicao_origem']} → {m['posicao_destino']} — {m['motivo']}")
    for o in services.ocorrencias_da_pasta(pasta_id, contexto):
        st.caption(f"{o['data_hora']} — {o['tipo']} — {o['descricao']}")

    st.markdown("#### Backup manual do banco (somente Master)")
    if st.button("Criar backup agora"):
        try:
            caminho = backup.criar_backup(contexto)
            st.success(f"Backup criado em: {caminho}")
        except ErroPermissao as exc:
            st.error(str(exc))
