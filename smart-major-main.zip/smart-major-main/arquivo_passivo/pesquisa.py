"""Pesquisa aproximada e fonética de pastas. Favorece recuperação de candidatos
(não usa um limiar único rígido) — o objetivo é localizar uma pasta em arquivo físico."""
from rapidfuzz import fuzz

from administracao.contexto import ContextoAutorizacao, exigir
from arquivo_passivo.database import conectar
from arquivo_passivo.models import normalizar_para_busca, chave_fonetica

LIMIAR_MINIMO_EXIBICAO = 60  # permissivo o bastante para variações de grafia,
# mas calibrado para não confundir nomes totalmente distintos (ver testes).


def _pontuacao_por_token(termo_norm: str, nome_norm: str) -> float:
    """Compara cada palavra do termo contra a melhor correspondência nas palavras do
    nome. Evita falsos positivos de comparações por string inteira em nomes compostos."""
    termos = termo_norm.split()
    palavras_nome = nome_norm.split()
    if not termos or not palavras_nome:
        return 0.0
    pontuacoes = [max(fuzz.ratio(t, p) for p in palavras_nome) for t in termos]
    return sum(pontuacoes) / len(pontuacoes)


def pesquisar_pastas(
    contexto: ContextoAutorizacao, termo: str | None = None, ano: int | None = None,
    codigo_caixa: str | None = None, posicao: int | None = None, limite: int = 100,
) -> list[dict]:
    exigir(contexto, "arquivo_passivo.consultar")
    conn = conectar()
    try:
        sql = "SELECT p.*, c.codigo AS codigo_caixa FROM pastas p JOIN caixas c ON c.id = p.caixa_id WHERE 1=1"
        params: list = []
        if ano:
            sql += " AND p.ano_referencia = ?"
            params.append(ano)
        if codigo_caixa:
            sql += " AND c.codigo = ?"
            params.append(codigo_caixa.upper())
        if posicao is not None:
            sql += " AND p.posicao = ?"
            params.append(posicao)
        candidatos = [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()

    if not termo:
        return sorted(candidatos, key=lambda r: (r["codigo_caixa"], r["posicao"]))

    termo_norm = normalizar_para_busca(termo)
    termo_fonetico = chave_fonetica(termo)

    resultados = []
    for registro in candidatos:
        nome_norm = registro["nome_normalizado"]
        nome_fonetico = chave_fonetica(registro["nome_ordem_convencional"])

        pontuacao_textual = max(
            fuzz.token_sort_ratio(termo_norm, nome_norm),
            _pontuacao_por_token(termo_norm, nome_norm),
        )
        pontuacao_fonetica = _pontuacao_por_token(termo_fonetico, nome_fonetico)
        pontuacao_final = max(pontuacao_textual, pontuacao_fonetica)

        if pontuacao_final >= LIMIAR_MINIMO_EXIBICAO:
            registro_com_score = dict(registro)
            registro_com_score["similaridade"] = round(pontuacao_final, 1)
            resultados.append(registro_com_score)

    resultados.sort(key=lambda r: r["similaridade"], reverse=True)
    return resultados[:limite]


def caixas_com_resultados(resultados: list[dict]) -> set[int]:
    return {r["caixa_id"] for r in resultados}
