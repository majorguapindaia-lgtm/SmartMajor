-- Banco SQLite independente do Arquivo Passivo (arquivo_passivo.db).
-- Espelho digital da organização física real: nunca calcula, corrige ou renumera
-- caixas/posições automaticamente.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_version (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    versao INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS caixas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    letra TEXT NOT NULL,
    numero INTEGER NOT NULL,
    codigo TEXT NOT NULL UNIQUE,         -- ex.: 'C-01'
    situacao TEXT NOT NULL DEFAULT 'disponivel',
    observacoes TEXT,
    criado_em TEXT NOT NULL,
    criado_por INTEGER
);
CREATE INDEX IF NOT EXISTS idx_caixas_letra ON caixas(letra);

CREATE TABLE IF NOT EXISTS pastas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_original TEXT NOT NULL,
    formato_informado TEXT NOT NULL CHECK (formato_informado IN ('convencional', 'arquivo')),
    nome_normalizado TEXT NOT NULL,
    nome_padrao_arquivo TEXT NOT NULL,   -- "Sobrenome, Resto"
    nome_ordem_convencional TEXT NOT NULL,
    primeiro_nome TEXT,
    demais_nomes TEXT,
    ultimo_sobrenome TEXT NOT NULL,
    letra_classificacao TEXT NOT NULL,
    ano_referencia INTEGER NOT NULL,
    concluinte TEXT NOT NULL CHECK (concluinte IN ('Sim', 'Nao')),
    caixa_id INTEGER NOT NULL REFERENCES caixas(id),
    posicao INTEGER NOT NULL,
    situacao_fisica TEXT NOT NULL CHECK (
        situacao_fisica IN ('Disponivel', 'Desaparecida', 'Danificada', 'Destruida', 'Outra')
    ),
    situacao_academica TEXT,
    observacoes TEXT,
    criado_em TEXT NOT NULL,
    criado_por INTEGER,
    atualizado_em TEXT NOT NULL,
    atualizado_por INTEGER
);
CREATE INDEX IF NOT EXISTS idx_pastas_nome_norm ON pastas(nome_normalizado);
CREATE INDEX IF NOT EXISTS idx_pastas_ano ON pastas(ano_referencia);
CREATE INDEX IF NOT EXISTS idx_pastas_caixa ON pastas(caixa_id);
CREATE INDEX IF NOT EXISTS idx_pastas_sobrenome ON pastas(ultimo_sobrenome);

CREATE TABLE IF NOT EXISTS movimentacoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pasta_id INTEGER NOT NULL REFERENCES pastas(id),
    caixa_origem_id INTEGER REFERENCES caixas(id),
    posicao_origem INTEGER,
    caixa_destino_id INTEGER NOT NULL REFERENCES caixas(id),
    posicao_destino INTEGER NOT NULL,
    data_hora TEXT NOT NULL,
    responsavel_conta_id INTEGER,
    motivo TEXT,
    observacao TEXT
);
CREATE INDEX IF NOT EXISTS idx_mov_pasta ON movimentacoes(pasta_id);

CREATE TABLE IF NOT EXISTS ocorrencias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pasta_id INTEGER REFERENCES pastas(id),
    caixa_id INTEGER REFERENCES caixas(id),
    tipo TEXT NOT NULL,
    data_hora TEXT NOT NULL,
    responsavel_conta_id INTEGER,
    ultima_localizacao_conhecida TEXT,
    descricao TEXT,
    providencias TEXT
);
CREATE INDEX IF NOT EXISTS idx_ocorrencias_pasta ON ocorrencias(pasta_id);

INSERT OR IGNORE INTO schema_version (id, versao) VALUES (1, 1);
