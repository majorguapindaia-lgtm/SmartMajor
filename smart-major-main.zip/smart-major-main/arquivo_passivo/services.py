"""Cadastro, edição, movimentação e ocorrências de pastas e caixas físicas.

Regra inegociável: o programa NUNCA calcula, corrige ou renumera caixa/posição.
O operador informa a localização física real; o sistema apenas valida conflitos
de posição e preserva histórico.

Correção de segurança (diagnóstico da 2ª etapa): toda operação exige um
`administracao.contexto.ContextoAutorizacao` validado contra uma sessão real, e a
permissão granular correspondente é verificada AQUI, dentro do serviço — não apenas
na tela Streamlit. Chamar estas funções sem um contexto autorizado sempre falha.
"""
from administracao.contexto import ContextoAutorizacao, exigir
from arquivo_passivo.database import conectar
from arquivo_passivo.models import (
    ErroValidacaoPasta, decompor_nome, normalizar_para_busca, validar_dados_pasta,
    SITUACOES_QUE_GERAM_OCORRENCIA,
)
from common.tempo import agora_utc


def cadastrar_caixa(letra: str, numero: int, contexto: ContextoAutorizacao,
                     observacoes: str | None = None) -> int:
    exigir(contexto, "arquivo_passivo.cadastrar")
    conn = conectar()
    try:
        return _cadastrar_caixa_na_conexao(conn, letra, numero, contexto.conta_id, observacoes, commit=True)
    finally:
        conn.close()


def _cadastrar_caixa_na_conexao(conn, letra: str, numero: int, conta_id: int,
                                 observacoes: str | None, commit: bool) -> int:
    """Idêntico a cadastrar_caixa, mas reutiliza uma conexão/transação já aberta
    (usado por cadastrar_pasta para criar caixa nova sem deixar registro órfão)."""
    letra = letra.strip().upper()
    codigo = f"{letra}-{numero:02d}"
    existente = conn.execute("SELECT id FROM caixas WHERE codigo = ?", (codigo,)).fetchone()
    if existente:
        return existente["id"]
    cur = conn.execute(
        "INSERT INTO caixas (letra, numero, codigo, situacao, observacoes, criado_em, criado_por) "
        "VALUES (?, ?, ?, 'disponivel', ?, ?, ?)",
        (letra, numero, codigo, observacoes, agora_utc().isoformat(), conta_id),
    )
    if commit:
        conn.commit()
    return cur.lastrowid


def listar_caixas(contexto: ContextoAutorizacao) -> list[dict]:
    exigir(contexto, "arquivo_passivo.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute("SELECT * FROM caixas ORDER BY letra, numero").fetchall()]
    finally:
        conn.close()


def _posicao_ocupada(conn, caixa_id: int, posicao: int, excluir_pasta_id: int | None = None) -> bool:
    sql = (
        "SELECT 1 FROM pastas WHERE caixa_id = ? AND posicao = ? "
        "AND situacao_fisica = 'Disponivel'"
    )
    params = [caixa_id, posicao]
    if excluir_pasta_id is not None:
        sql += " AND id != ?"
        params.append(excluir_pasta_id)
    return conn.execute(sql, params).fetchone() is not None


def cadastrar_pasta(
    nome: str, formato_informado: str, ano_referencia: int, concluinte: str,
    posicao: int, situacao_fisica: str, contexto: ContextoAutorizacao,
    caixa_id: int | None = None, nova_caixa_letra: str | None = None,
    nova_caixa_numero: int | None = None,
    situacao_academica: str | None = None, observacoes: str | None = None,
) -> int:
    """Cadastra a pasta. Se `caixa_id` não for informado, cria a caixa nova
    (`nova_caixa_letra`/`nova_caixa_numero`) NA MESMA TRANSAÇÃO — se a validação da
    pasta falhar depois, a caixa nova também não é persistida (correção do bug de
    caixa órfã identificado no diagnóstico)."""
    exigir(contexto, "arquivo_passivo.cadastrar")

    conn = conectar()
    try:
        if caixa_id is None:
            if not nova_caixa_letra or not nova_caixa_numero:
                raise ErroValidacaoPasta("Informe uma caixa existente ou os dados da nova caixa.")
            caixa_id = _cadastrar_caixa_na_conexao(
                conn, nova_caixa_letra, int(nova_caixa_numero), contexto.conta_id, None, commit=False,
            )

        validar_dados_pasta(nome, formato_informado, ano_referencia, concluinte,
                             caixa_id, posicao, situacao_fisica)
        decomposto = decompor_nome(nome, formato_informado)

        if situacao_fisica == "Disponivel" and _posicao_ocupada(conn, caixa_id, posicao):
            ocupante = conn.execute(
                "SELECT nome_ordem_convencional FROM pastas WHERE caixa_id = ? AND posicao = ? "
                "AND situacao_fisica = 'Disponivel'", (caixa_id, posicao),
            ).fetchone()
            raise ErroValidacaoPasta(
                f"Posição {posicao} já ocupada por '{ocupante['nome_ordem_convencional']}'."
            )

        agora = agora_utc().isoformat()
        cur = conn.execute(
            """INSERT INTO pastas (
                nome_original, formato_informado, nome_normalizado, nome_padrao_arquivo,
                nome_ordem_convencional, primeiro_nome, demais_nomes, ultimo_sobrenome,
                letra_classificacao, ano_referencia, concluinte, caixa_id, posicao,
                situacao_fisica, situacao_academica, observacoes, criado_em, criado_por,
                atualizado_em, atualizado_por
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                nome, formato_informado, normalizar_para_busca(decomposto.nome_ordem_convencional),
                decomposto.nome_padrao_arquivo, decomposto.nome_ordem_convencional,
                decomposto.primeiro_nome, decomposto.demais_nomes, decomposto.ultimo_sobrenome,
                decomposto.letra_classificacao, ano_referencia, concluinte, caixa_id, posicao,
                situacao_fisica, situacao_academica, observacoes, agora, contexto.conta_id, agora,
                contexto.conta_id,
            ),
        )
        pasta_id = cur.lastrowid

        if situacao_fisica in SITUACOES_QUE_GERAM_OCORRENCIA:
            conn.execute(
                "INSERT INTO ocorrencias (pasta_id, tipo, data_hora, responsavel_conta_id, "
                "ultima_localizacao_conhecida, descricao) VALUES (?, ?, ?, ?, ?, ?)",
                (pasta_id, situacao_fisica, agora, contexto.conta_id,
                 f"Caixa {caixa_id}, posição {posicao}", "Registrado no cadastro inicial."),
            )
        conn.commit()
        return pasta_id
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def editar_pasta(pasta_id: int, campos: dict, contexto: ContextoAutorizacao) -> None:
    exigir(contexto, "arquivo_passivo.editar")
    permitidos = {
        "ano_referencia", "concluinte", "situacao_academica", "observacoes", "situacao_fisica",
    }
    campos_validos = {k: v for k, v in campos.items() if k in permitidos}

    conn = conectar()
    try:
        pasta = conn.execute("SELECT * FROM pastas WHERE id = ?", (pasta_id,)).fetchone()
        if pasta is None:
            raise ErroValidacaoPasta("Pasta não encontrada.")

        if "nome" in campos or "formato_informado" in campos:
            novo_nome = campos.get("nome", pasta["nome_original"])
            novo_formato = campos.get("formato_informado", pasta["formato_informado"])
            decomposto = decompor_nome(novo_nome, novo_formato)
            campos_validos.update({
                "nome_original": novo_nome, "formato_informado": novo_formato,
                "nome_normalizado": normalizar_para_busca(decomposto.nome_ordem_convencional),
                "nome_padrao_arquivo": decomposto.nome_padrao_arquivo,
                "nome_ordem_convencional": decomposto.nome_ordem_convencional,
                "primeiro_nome": decomposto.primeiro_nome,
                "demais_nomes": decomposto.demais_nomes,
                "ultimo_sobrenome": decomposto.ultimo_sobrenome,
                "letra_classificacao": decomposto.letra_classificacao,
            })

        if not campos_validos:
            return

        if campos_validos.get("situacao_fisica") in SITUACOES_QUE_GERAM_OCORRENCIA:
            conn.execute(
                "INSERT INTO ocorrencias (pasta_id, caixa_id, tipo, data_hora, responsavel_conta_id, "
                "ultima_localizacao_conhecida, descricao) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (pasta_id, pasta["caixa_id"], campos_validos["situacao_fisica"], agora_utc().isoformat(),
                 contexto.conta_id, f"Caixa {pasta['caixa_id']}, posição {pasta['posicao']}",
                 campos.get("descricao_ocorrencia", "Situação atualizada na edição.")),
            )
        elif campos_validos.get("situacao_fisica") == "Disponivel" and pasta["situacao_fisica"] != "Disponivel":
            conn.execute(
                "INSERT INTO ocorrencias (pasta_id, caixa_id, tipo, data_hora, responsavel_conta_id, "
                "descricao) VALUES (?, ?, ?, ?, ?, ?)",
                (pasta_id, pasta["caixa_id"], "Encontrada apos desaparecimento", agora_utc().isoformat(),
                 contexto.conta_id, campos.get("descricao_ocorrencia", "Pasta localizada novamente.")),
            )

        set_sql = ", ".join(f"{k} = ?" for k in campos_validos)
        valores = list(campos_validos.values()) + [agora_utc().isoformat(), contexto.conta_id, pasta_id]
        conn.execute(
            f"UPDATE pastas SET {set_sql}, atualizado_em = ?, atualizado_por = ? WHERE id = ?",
            valores,
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def mover_pasta(
    pasta_id: int, caixa_destino_id: int, posicao_destino: int,
    motivo: str, contexto: ContextoAutorizacao, observacao: str | None = None,
) -> None:
    """Movimentação física real: preserva origem/destino no histórico, nunca sobrescreve."""
    exigir(contexto, "arquivo_passivo.movimentar")
    conn = conectar()
    try:
        pasta = conn.execute("SELECT * FROM pastas WHERE id = ?", (pasta_id,)).fetchone()
        if pasta is None:
            raise ErroValidacaoPasta("Pasta não encontrada.")

        if _posicao_ocupada(conn, caixa_destino_id, posicao_destino, excluir_pasta_id=pasta_id):
            raise ErroValidacaoPasta(f"Posição {posicao_destino} já ocupada na caixa de destino.")

        agora = agora_utc().isoformat()
        conn.execute(
            """INSERT INTO movimentacoes (pasta_id, caixa_origem_id, posicao_origem,
                caixa_destino_id, posicao_destino, data_hora, responsavel_conta_id, motivo, observacao)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (pasta_id, pasta["caixa_id"], pasta["posicao"], caixa_destino_id, posicao_destino,
             agora, contexto.conta_id, motivo, observacao),
        )
        conn.execute(
            "UPDATE pastas SET caixa_id = ?, posicao = ?, atualizado_em = ?, atualizado_por = ? WHERE id = ?",
            (caixa_destino_id, posicao_destino, agora, contexto.conta_id, pasta_id),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def historico_movimentacoes(pasta_id: int, contexto: ContextoAutorizacao) -> list[dict]:
    exigir(contexto, "arquivo_passivo.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM movimentacoes WHERE pasta_id = ? ORDER BY data_hora", (pasta_id,)
        ).fetchall()]
    finally:
        conn.close()


def registrar_ocorrencia(
    pasta_id: int | None, caixa_id: int | None, tipo: str, contexto: ContextoAutorizacao,
    descricao: str | None = None, ultima_localizacao_conhecida: str | None = None,
    providencias: str | None = None,
) -> int:
    exigir(contexto, "arquivo_passivo.ocorrencia")
    conn = conectar()
    try:
        cur = conn.execute(
            """INSERT INTO ocorrencias (pasta_id, caixa_id, tipo, data_hora, responsavel_conta_id,
                ultima_localizacao_conhecida, descricao, providencias)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (pasta_id, caixa_id, tipo, agora_utc().isoformat(), contexto.conta_id,
             ultima_localizacao_conhecida, descricao, providencias),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def ocorrencias_da_pasta(pasta_id: int, contexto: ContextoAutorizacao) -> list[dict]:
    exigir(contexto, "arquivo_passivo.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM ocorrencias WHERE pasta_id = ? ORDER BY data_hora", (pasta_id,)
        ).fetchall()]
    finally:
        conn.close()


def pastas_da_caixa(caixa_id: int, contexto: ContextoAutorizacao) -> list[dict]:
    exigir(contexto, "arquivo_passivo.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM pastas WHERE caixa_id = ? ORDER BY posicao", (caixa_id,)
        ).fetchall()]
    finally:
        conn.close()
