"""Cobre os 24 cenários do capítulo 15 do Anexo A (Arquivo Passivo).

Desde a correção de segurança da 2ª etapa, todo serviço exige um
ContextoAutorizacao validado — por isso cada teste usa uma conta Master real,
criada por bootstrap, em vez de um `autor_id` solto."""
import sqlite3

import pandas as pd
import pytest

from administracao.contexto import ContextoAutorizacao
from administracao.database import inicializar as inicializar_admin
from autenticacao.database import inicializar as inicializar_core
from autenticacao.bootstrap_master import bootstrap_primeiro_master
from arquivo_passivo.database import inicializar, conectar, caminho_db
from arquivo_passivo.models import ErroValidacaoPasta, decompor_nome
from arquivo_passivo.services import (
    cadastrar_caixa, cadastrar_pasta, editar_pasta, mover_pasta, registrar_ocorrencia,
    historico_movimentacoes, listar_caixas, pastas_da_caixa,
)
from arquivo_passivo.pesquisa import pesquisar_pastas, caixas_com_resultados
from arquivo_passivo.importacao import gerar_preview, importar_linhas_confirmadas
from arquivo_passivo.backup import criar_backup, verificar_integridade, restaurar_em_caminho_separado


@pytest.fixture
def ctx() -> ContextoAutorizacao:
    """Contexto de uma conta Master real (bootstrap), usada nos testes de regra de
    negócio do Arquivo Passivo. Testes de autorização propriamente ditos estão em
    tests_seguranca/test_bypass_direto.py."""
    inicializar()
    inicializar_core()
    inicializar_admin()
    pessoa_id = bootstrap_primeiro_master("Master Teste AP", "master.ap.teste", "SenhaMasterForte1")
    from autenticacao.database import conectar as conectar_core
    conn = conectar_core()
    conta_id = conn.execute("SELECT id FROM contas WHERE pessoa_id = ?", (pessoa_id,)).fetchone()["id"]
    conn.close()
    return ContextoAutorizacao(conta_id=conta_id)


# 1. Cadastro de um aluno com nome convencional.
def test_01_cadastro_nome_convencional(ctx):
    caixa_id = cadastrar_caixa("C", 1, ctx)
    pasta_id = cadastrar_pasta("Rafael João Cardoso", "convencional", 2020, "Sim", 1, "Disponivel", ctx,
                                caixa_id=caixa_id)
    assert pasta_id is not None


# 2. Cadastro de um aluno com nome no padrão do arquivo.
def test_02_cadastro_nome_padrao_arquivo(ctx):
    caixa_id = cadastrar_caixa("C", 2, ctx)
    pasta_id = cadastrar_pasta("Cardoso, Rafael João", "arquivo", 2020, "Sim", 1, "Disponivel", ctx,
                                caixa_id=caixa_id)
    conn = conectar()
    pasta = conn.execute("SELECT * FROM pastas WHERE id = ?", (pasta_id,)).fetchone()
    conn.close()
    assert pasta["nome_ordem_convencional"] == "Rafael João Cardoso"


# 3. Extração correta do último sobrenome.
def test_03_extracao_ultimo_sobrenome():
    assert decompor_nome("João Pedro da Silva", "convencional").ultimo_sobrenome == "Silva"
    assert decompor_nome("Maria dos Santos", "convencional").ultimo_sobrenome == "Santos"


# 4. Classificação correta da letra da caixa.
def test_04_letra_classificacao():
    assert decompor_nome("Rafael João Cardoso", "convencional").letra_classificacao == "C"
    assert decompor_nome("Ana Beatriz Coelho", "convencional").letra_classificacao == "C"
    assert decompor_nome("João Pedro da Silva", "convencional").letra_classificacao == "S"


# 5. Geração automática de ID interno.
def test_05_id_interno_automatico(ctx):
    caixa_id = cadastrar_caixa("D", 1, ctx)
    id1 = cadastrar_pasta("Ana Teste", "convencional", 2021, "Nao", 1, "Disponivel", ctx, caixa_id=caixa_id)
    id2 = cadastrar_pasta("Bia Teste", "convencional", 2021, "Nao", 2, "Disponivel", ctx, caixa_id=caixa_id)
    assert id1 != id2 and isinstance(id1, int)


# 6. Cadastro de dois alunos homônimos.
def test_06_homonimos(ctx):
    caixa_id = cadastrar_caixa("E", 1, ctx)
    id1 = cadastrar_pasta("Carlos Souza", "convencional", 2019, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)
    id2 = cadastrar_pasta("Carlos Souza", "convencional", 2020, "Nao", 2, "Disponivel", ctx, caixa_id=caixa_id)
    assert id1 != id2


# 7. Bloqueio de campos obrigatórios vazios.
def test_07_bloqueio_campos_obrigatorios_vazios(ctx):
    caixa_id = cadastrar_caixa("F", 1, ctx)
    with pytest.raises(ErroValidacaoPasta):
        cadastrar_pasta("", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)
    with pytest.raises(ErroValidacaoPasta):
        cadastrar_pasta("Nome Sobrenome", "convencional", None, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)


# 8. Rejeição de posição já ocupada por outra pasta disponível.
def test_08_rejeicao_posicao_ocupada(ctx):
    caixa_id = cadastrar_caixa("G", 1, ctx)
    cadastrar_pasta("Primeiro Ocupante", "convencional", 2020, "Sim", 5, "Disponivel", ctx, caixa_id=caixa_id)
    with pytest.raises(ErroValidacaoPasta):
        cadastrar_pasta("Segundo Ocupante", "convencional", 2020, "Sim", 5, "Disponivel", ctx, caixa_id=caixa_id)


# 9. Cadastro de caixas com quantidades diferentes de pastas (sem limite artificial).
def test_09_caixas_quantidades_diferentes(ctx):
    caixa_a = cadastrar_caixa("H", 1, ctx)
    caixa_b = cadastrar_caixa("H", 2, ctx)
    for posicao in range(1, 11):
        cadastrar_pasta(f"Aluno H {posicao}", "convencional", 2020, "Sim", posicao, "Disponivel", ctx,
                         caixa_id=caixa_a)
    cadastrar_pasta("Aluno H Unico", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_b)
    assert len(pastas_da_caixa(caixa_a, ctx)) == 10
    assert len(pastas_da_caixa(caixa_b, ctx)) == 1


# 10. Pesquisa por nome exato.
def test_10_pesquisa_nome_exato(ctx):
    caixa_id = cadastrar_caixa("I", 1, ctx)
    cadastrar_pasta("Aline Ferreira", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)
    resultados = pesquisar_pastas(ctx, termo="Aline Ferreira")
    assert any(r["nome_ordem_convencional"] == "Aline Ferreira" for r in resultados)


# 11. Pesquisa por parte do nome.
def test_11_pesquisa_parte_do_nome(ctx):
    caixa_id = cadastrar_caixa("J", 1, ctx)
    cadastrar_pasta("Beatriz Lima Souza", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)
    resultados = pesquisar_pastas(ctx, termo="Lima")
    assert any("Beatriz Lima Souza" == r["nome_ordem_convencional"] for r in resultados)


# 12. Pesquisa com diferenças entre I, E e Y.
def test_12_pesquisa_diferenca_i_e_y(ctx):
    caixa_id = cadastrar_caixa("K", 1, ctx)
    cadastrar_pasta("Alyne Pereira", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)
    resultados = pesquisar_pastas(ctx, termo="Aline")
    assert any("Alyne" in r["nome_ordem_convencional"] for r in resultados)


# 13. Pesquisa com diferenças entre O e U.
def test_13_pesquisa_diferenca_o_u(ctx):
    caixa_id = cadastrar_caixa("L", 1, ctx)
    cadastrar_pasta("Roberto Nunes", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)
    resultados = pesquisar_pastas(ctx, termo="Rubertu Nunes")
    assert any("Roberto Nunes" == r["nome_ordem_convencional"] for r in resultados)


# 14. Pesquisa com acentos e erros de digitação.
def test_14_pesquisa_acentos_e_erros_digitacao(ctx):
    caixa_id = cadastrar_caixa("M", 1, ctx)
    cadastrar_pasta("José Antônio Gonçalves", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)
    resultados = pesquisar_pastas(ctx, termo="Jose Antonio Goncalvez")
    assert any("Gonçalves" in r["nome_ordem_convencional"] for r in resultados)


# 15. Filtragem da estante pelas caixas que contêm resultados.
def test_15_filtragem_estante_por_resultado(ctx):
    caixa_com = cadastrar_caixa("N", 1, ctx)
    caixa_sem = cadastrar_caixa("N", 2, ctx)
    cadastrar_pasta("Fulano Pesquisavel", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_com)
    cadastrar_pasta("Outra Pessoa Qualquer", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_sem)
    resultados = pesquisar_pastas(ctx, termo="Fulano Pesquisavel")
    caixas_ok = caixas_com_resultados(resultados)
    assert caixa_com in caixas_ok
    assert caixa_sem not in caixas_ok


# 16. Abertura de uma caixa e listagem por posição.
def test_16_listagem_por_posicao(ctx):
    caixa_id = cadastrar_caixa("O", 1, ctx)
    cadastrar_pasta("Terceiro Posicao", "convencional", 2020, "Sim", 3, "Disponivel", ctx, caixa_id=caixa_id)
    cadastrar_pasta("Primeiro Posicao", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)
    cadastrar_pasta("Segundo Posicao", "convencional", 2020, "Sim", 2, "Disponivel", ctx, caixa_id=caixa_id)
    pastas = pastas_da_caixa(caixa_id, ctx)
    assert [p["posicao"] for p in pastas] == [1, 2, 3]


# 17. Mudança de caixa e posição.
def test_17_mudanca_caixa_e_posicao(ctx):
    caixa_origem = cadastrar_caixa("P", 1, ctx)
    caixa_destino = cadastrar_caixa("P", 2, ctx)
    pasta_id = cadastrar_pasta("Movido Teste", "convencional", 2020, "Sim", 7, "Disponivel", ctx,
                                caixa_id=caixa_origem)
    mover_pasta(pasta_id, caixa_destino, 12, "Transferência física", ctx)
    conn = conectar()
    pasta = conn.execute("SELECT * FROM pastas WHERE id = ?", (pasta_id,)).fetchone()
    conn.close()
    assert pasta["caixa_id"] == caixa_destino and pasta["posicao"] == 12


# 18. Preservação do histórico de movimentações.
def test_18_preservacao_historico_movimentacoes(ctx):
    caixa_origem = cadastrar_caixa("Q", 1, ctx)
    caixa_destino = cadastrar_caixa("Q", 2, ctx)
    pasta_id = cadastrar_pasta("Historico Teste", "convencional", 2020, "Sim", 1, "Disponivel", ctx,
                                caixa_id=caixa_origem)
    mover_pasta(pasta_id, caixa_destino, 1, "Motivo 1", ctx)
    historico = historico_movimentacoes(pasta_id, ctx)
    assert len(historico) == 1
    assert historico[0]["caixa_origem_id"] == caixa_origem
    assert historico[0]["caixa_destino_id"] == caixa_destino


# 19. Registro de pasta desaparecida.
def test_19_registro_pasta_desaparecida(ctx):
    caixa_id = cadastrar_caixa("R", 1, ctx)
    pasta_id = cadastrar_pasta("Desaparecido Teste", "convencional", 2020, "Sim", 1, "Desaparecida", ctx,
                                caixa_id=caixa_id)
    conn = conectar()
    ocorrencias = conn.execute("SELECT * FROM ocorrencias WHERE pasta_id = ?", (pasta_id,)).fetchall()
    conn.close()
    assert len(ocorrencias) == 1 and ocorrencias[0]["tipo"] == "Desaparecida"


# 20. Registro de pasta danificada ou destruída.
def test_20_registro_pasta_danificada_ou_destruida(ctx):
    caixa_id = cadastrar_caixa("S", 1, ctx)
    pasta_id = cadastrar_pasta("Danificado Teste", "convencional", 2020, "Sim", 1, "Danificada", ctx,
                                caixa_id=caixa_id)
    conn = conectar()
    ocorrencias = conn.execute("SELECT * FROM ocorrencias WHERE pasta_id = ?", (pasta_id,)).fetchall()
    conn.close()
    assert ocorrencias[0]["tipo"] == "Danificada"


# 21. Localização de uma pasta anteriormente desaparecida.
def test_21_localizacao_pasta_anteriormente_desaparecida(ctx):
    caixa_id = cadastrar_caixa("T", 1, ctx)
    pasta_id = cadastrar_pasta("Reencontrado Teste", "convencional", 2020, "Sim", 1, "Desaparecida", ctx,
                                caixa_id=caixa_id)
    editar_pasta(pasta_id, {"situacao_fisica": "Disponivel", "descricao_ocorrencia": "Encontrada na caixa T"}, ctx)
    conn = conectar()
    pasta = conn.execute("SELECT situacao_fisica FROM pastas WHERE id = ?", (pasta_id,)).fetchone()
    ocorrencias = conn.execute("SELECT * FROM ocorrencias WHERE pasta_id = ?", (pasta_id,)).fetchall()
    conn.close()
    assert pasta["situacao_fisica"] == "Disponivel"
    assert any("Encontrada" in o["tipo"] for o in ocorrencias)


# 22. Importação de planilha com registros válidos e inválidos.
def test_22_importacao_planilha_validos_e_invalidos(ctx):
    df = pd.DataFrame([
        {"nome": "Valido Um", "formato_informado": "convencional", "ano_referencia": 2020,
         "concluinte": "Sim", "caixa": "U-01", "posicao": 1, "situacao_academica": None, "observacoes": None},
        {"nome": "", "formato_informado": "convencional", "ano_referencia": None,
         "concluinte": "Talvez", "caixa": None, "posicao": None, "situacao_academica": None, "observacoes": None},
    ])
    preview = gerar_preview(df, ctx)
    assert len(preview.validas) == 1
    assert len(preview.invalidas) == 1
    total = importar_linhas_confirmadas(preview.validas, ctx)
    assert total == 1


# 23. Criação e restauração de backup.
def test_23_criacao_e_restauracao_backup(ctx, tmp_path):
    caixa_id = cadastrar_caixa("V", 1, ctx)
    cadastrar_pasta("Backup Teste", "convencional", 2020, "Sim", 1, "Disponivel", ctx, caixa_id=caixa_id)

    caminho_backup = criar_backup(ctx)
    assert caminho_backup.exists()
    assert verificar_integridade(caminho_backup)

    destino_restauracao = tmp_path / "restaurado.db"
    restaurar_em_caminho_separado(caminho_backup, destino_restauracao, ctx)
    conn = sqlite3.connect(destino_restauracao)
    linha = conn.execute("SELECT nome_ordem_convencional FROM pastas WHERE caixa_id = ?", (caixa_id,)).fetchone()
    conn.close()
    assert linha is not None and linha[0] == "Backup Teste"
    assert caminho_db().exists()  # banco original preservado


# 24. Preservação dos dados após reiniciar o Streamlit (simulado por reabrir conexão/reinicializar).
def test_24_preservacao_apos_reinicio(ctx):
    caixa_id = cadastrar_caixa("W", 1, ctx)
    pasta_id = cadastrar_pasta("Persistente Teste", "convencional", 2020, "Sim", 1, "Disponivel", ctx,
                                caixa_id=caixa_id)
    inicializar()  # simula reexecução do script de inicialização ao reiniciar o Streamlit
    conn = conectar()
    pasta = conn.execute("SELECT * FROM pastas WHERE id = ?", (pasta_id,)).fetchone()
    conn.close()
    assert pasta is not None and pasta["nome_ordem_convencional"] == "Persistente Teste"


def test_extra_nao_gera_caixa_automatica_por_sobrenome(ctx):
    """Teste adicional exigido na seção 12.4: nenhuma caixa é criada automaticamente
    por sugestão algorítmica de sobrenome."""
    antes = {c["codigo"] for c in listar_caixas(ctx)}
    cadastrar_caixa("Z", 1, ctx)
    cadastrar_caixa("Z", 1, ctx)  # idempotente, mesma caixa
    depois = {c["codigo"] for c in listar_caixas(ctx)}
    assert depois - antes == {"Z-01"}


def test_extra_caixa_nova_nao_fica_orfa_se_cadastro_da_pasta_falhar(ctx):
    """Correção do diagnóstico da 2ª etapa: se a validação da pasta falhar, a caixa
    nova solicitada junto não deve ter sido persistida (transação atômica)."""
    antes = {c["codigo"] for c in listar_caixas(ctx)}
    with pytest.raises(ErroValidacaoPasta):
        cadastrar_pasta(
            "", "convencional", 2020, "Sim", 1, "Disponivel", ctx,
            nova_caixa_letra="Y", nova_caixa_numero=1,
        )
    depois = {c["codigo"] for c in listar_caixas(ctx)}
    assert depois == antes  # nenhuma caixa "Y-01" órfã foi criada
