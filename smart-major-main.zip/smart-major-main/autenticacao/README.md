# Autenticação

Cadastro central de pessoas, vínculos funcionais e contas de acesso, separados
(uma pessoa pode ter vários vínculos; nem toda pessoa tem conta).

## Banco

Compartilha `dados_privados/core.db` com `administracao/` — escolha documentada para
não duplicar cadastro de pessoas/contas entre módulos. `arquivo_passivo/`,
`folha_ponto/` e `almoxarifado/` têm bancos próprios e independentes.

## Segurança implementada

- Senhas: Argon2id via `argon2-cffi` (`senhas.py`), nunca texto claro.
- Sessões: token aleatório + digest SHA-256 armazenado, expiração, revogação (`sessoes.py`).
- Login: bloqueio após 5 tentativas consecutivas, mensagens genéricas (`login.py`).
- Reset de senha: token único, expiração de 30 min, e-mail via SMTP configurado por
  variáveis de ambiente (`recuperacao.py`) — **se o SMTP não estiver configurado, o
  sistema informa erro explícito, nunca finge que o e-mail foi enviado.**
- Bootstrap do primeiro Master: `python -m autenticacao.bootstrap_master --nome "..." --login "..."`
  com `SMART_MAJOR_BOOTSTRAP_SENHA` definida no ambiente. Recusa um segundo bootstrap.

## MFA do Master (pendente)

`pyotp` está instalado e disponível, mas o enrolamento/validação de TOTP para contas
Master **ainda não foi implementado nesta etapa** — não afirmar que MFA está ativo em
produção até essa pendência ser resolvida.

## Testes

`pytest autenticacao` — cadastro com múltiplos vínculos, homônimos, SIAPE federal,
login/bloqueio, token de reset de uso único, sessão revogada, bootstrap único do Master.
