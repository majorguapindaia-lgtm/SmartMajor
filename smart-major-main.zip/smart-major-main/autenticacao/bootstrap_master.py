"""Bootstrap seguro do primeiro usuário Master. Executável uma única vez.

Uso (terminal, ambiente local, com o segredo definido apenas na sessão do operador):
    SMART_MAJOR_BOOTSTRAP_SENHA="senha-forte-local" python -m autenticacao.bootstrap_master \
        --nome "Nome do Master" --login master.inicial

Após o primeiro bootstrap, uma segunda execução é recusada.
"""
import argparse
import os
import sys

from autenticacao.database import conectar, inicializar
from autenticacao.senhas import gerar_hash
from common.tempo import agora_utc


class BootstrapJaExecutado(Exception):
    pass


def bootstrap_primeiro_master(nome: str, login_unico: str, senha: str) -> int:
    inicializar()
    conn = conectar()
    try:
        ja_existe = conn.execute("SELECT 1 FROM bootstrap_master_flag WHERE id = 1").fetchone()
        if ja_existe is not None:
            raise BootstrapJaExecutado("O bootstrap do primeiro Master já foi executado neste banco.")

        agora = agora_utc().isoformat()
        cur = conn.execute(
            """INSERT INTO pessoas (nome, status, criado_em, criado_por, atualizado_em, atualizado_por)
               VALUES (?, 'ativo', ?, NULL, ?, NULL)""",
            (nome, agora, agora),
        )
        pessoa_id = cur.lastrowid

        senha_hash = gerar_hash(senha)
        conn.execute(
            """INSERT INTO contas (pessoa_id, login_unico, password_hash, ativa, master, criada_em)
               VALUES (?, ?, ?, 1, 1, ?)""",
            (pessoa_id, login_unico, senha_hash, agora),
        )
        conn.execute("INSERT INTO bootstrap_master_flag (id, executado_em) VALUES (1, ?)", (agora,))
        conn.commit()
        return pessoa_id
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _main() -> int:
    parser = argparse.ArgumentParser(description="Bootstrap do primeiro usuário Master do Smart Major.")
    parser.add_argument("--nome", required=True)
    parser.add_argument("--login", required=True)
    args = parser.parse_args()

    senha = os.environ.get("SMART_MAJOR_BOOTSTRAP_SENHA")
    if not senha:
        print("Defina a variável de ambiente SMART_MAJOR_BOOTSTRAP_SENHA antes de executar.", file=sys.stderr)
        return 1

    try:
        bootstrap_primeiro_master(args.nome, args.login, senha)
    except BootstrapJaExecutado as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 2
    print(f"Master '{args.login}' criado com sucesso. Troque a senha após o primeiro acesso.")
    return 0


if __name__ == "__main__":
    sys.exit(_main())
