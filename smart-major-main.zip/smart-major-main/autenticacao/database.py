"""Conexão e inicialização do banco central (core.db), usado por autenticacao/ e administracao/."""
import sqlite3
from pathlib import Path

from common.paths import caminho_banco

_SCHEMA_AUTENTICACAO = Path(__file__).resolve().parent / "schema.sql"


def caminho_core_db() -> Path:
    return caminho_banco("core.db")


def conectar() -> sqlite3.Connection:
    conn = sqlite3.connect(caminho_core_db(), timeout=30)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


def inicializar() -> None:
    """Cria as tabelas de autenticação caso não existam. Idempotente."""
    conn = conectar()
    try:
        conn.executescript(_SCHEMA_AUTENTICACAO.read_text(encoding="utf-8"))
        conn.commit()
    finally:
        conn.close()
