"""Autenticação de contas: login com limitação progressiva de tentativas."""
from dataclasses import dataclass

from autenticacao.database import conectar
from autenticacao.senhas import verificar_senha
from autenticacao.sessoes import criar_sessao, revogar_todas_sessoes_da_conta
from common.tempo import agora_utc

LIMITE_TENTATIVAS = 5
MENSAGEM_GENERICA = "Login ou senha inválidos."


@dataclass
class ResultadoLogin:
    sucesso: bool
    mensagem: str
    conta_id: int | None = None
    token_sessao: str | None = None


def autenticar(login_unico: str, senha: str, registrar_auditoria=None) -> ResultadoLogin:
    """registrar_auditoria: callback opcional(evento: dict) para registrar sucesso/falha."""
    conn = conectar()
    try:
        conta = conn.execute(
            "SELECT * FROM contas WHERE login_unico = ?", (login_unico,)
        ).fetchone()

        if conta is None:
            if registrar_auditoria:
                registrar_auditoria({"acao": "login_falha", "motivo": "conta_inexistente", "login": login_unico})
            return ResultadoLogin(False, MENSAGEM_GENERICA)

        if conta["bloqueada_at"] is not None or not conta["ativa"]:
            if registrar_auditoria:
                registrar_auditoria({"acao": "login_falha", "motivo": "conta_bloqueada", "conta_id": conta["id"]})
            return ResultadoLogin(False, "Conta bloqueada. Contate o administrador.")

        if not verificar_senha(conta["password_hash"], senha):
            novas_falhas = conta["falhas_consecutivas"] + 1
            bloqueio = agora_utc().isoformat() if novas_falhas >= LIMITE_TENTATIVAS else None
            conn.execute(
                "UPDATE contas SET falhas_consecutivas = ?, bloqueada_at = ? WHERE id = ?",
                (novas_falhas, bloqueio, conta["id"]),
            )
            conn.commit()
            if bloqueio:
                revogar_todas_sessoes_da_conta(conta["id"])
            if registrar_auditoria:
                registrar_auditoria({"acao": "login_falha", "motivo": "senha_incorreta", "conta_id": conta["id"]})
            return ResultadoLogin(False, MENSAGEM_GENERICA)

        conn.execute("UPDATE contas SET falhas_consecutivas = 0 WHERE id = ?", (conta["id"],))
        conn.commit()
        token = criar_sessao(conta["id"])
        if registrar_auditoria:
            registrar_auditoria({"acao": "login_sucesso", "conta_id": conta["id"]})
        return ResultadoLogin(True, "Login realizado com sucesso.", conta["id"], token)
    finally:
        conn.close()


def bloquear_conta(conta_id: int) -> None:
    conn = conectar()
    try:
        conn.execute(
            "UPDATE contas SET ativa = 0, bloqueada_at = ? WHERE id = ?",
            (agora_utc().isoformat(), conta_id),
        )
        conn.commit()
    finally:
        conn.close()
    revogar_todas_sessoes_da_conta(conta_id)


def desbloquear_conta(conta_id: int) -> None:
    conn = conectar()
    try:
        conn.execute(
            "UPDATE contas SET ativa = 1, bloqueada_at = NULL, falhas_consecutivas = 0 WHERE id = ?",
            (conta_id,),
        )
        conn.commit()
    finally:
        conn.close()
