"""Criação de contas, reset de senha via token único/expiração curta, e envio por SMTP real.

Importante: se o SMTP não estiver configurado por variáveis de ambiente, o sistema
informa um erro administrativo explícito. Nunca finge que um e-mail foi enviado.
"""
import hashlib
import os
import secrets
import smtplib
from datetime import timedelta
from email.message import EmailMessage

from autenticacao.database import conectar
from autenticacao.senhas import gerar_hash
from common.tempo import agora_utc

EXPIRACAO_TOKEN_MINUTOS = 30


class ErroSMTPNaoConfigurado(Exception):
    pass


def _digest(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def criar_conta(pessoa_id: int, login_unico: str, autor_id: int | None, master: bool = False) -> int:
    """Cria conta com senha temporária inacessível por padrão (exige reset por token)."""
    senha_inicial_hash = gerar_hash(secrets.token_urlsafe(24))
    conn = conectar()
    try:
        cur = conn.execute(
            """INSERT INTO contas (pessoa_id, login_unico, password_hash, ativa, master, criada_em, criada_por)
               VALUES (?, ?, ?, 1, ?, ?, ?)""",
            (pessoa_id, login_unico, senha_inicial_hash, int(master), agora_utc().isoformat(), autor_id),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def gerar_token_reset(conta_id: int) -> str:
    token = secrets.token_urlsafe(32)
    agora = agora_utc()
    expira = agora + timedelta(minutes=EXPIRACAO_TOKEN_MINUTOS)
    conn = conectar()
    try:
        conn.execute(
            "INSERT INTO tokens_recuperacao (conta_id, token_digest, expira_em, criado_em) VALUES (?, ?, ?, ?)",
            (conta_id, _digest(token), expira.isoformat(), agora.isoformat()),
        )
        conn.commit()
    finally:
        conn.close()
    return token


def consumir_token_e_redefinir(token: str, nova_senha: str) -> bool:
    conn = conectar()
    try:
        linha = conn.execute(
            "SELECT * FROM tokens_recuperacao WHERE token_digest = ?", (_digest(token),)
        ).fetchone()
        if linha is None or linha["consumido_em"] is not None:
            return False
        if linha["expira_em"] < agora_utc().isoformat():
            return False
        novo_hash = gerar_hash(nova_senha)
        conn.execute(
            "UPDATE contas SET password_hash = ?, falhas_consecutivas = 0 WHERE id = ?",
            (novo_hash, linha["conta_id"]),
        )
        conn.execute(
            "UPDATE tokens_recuperacao SET consumido_em = ? WHERE id = ?",
            (agora_utc().isoformat(), linha["id"]),
        )
        conn.commit()
        return True
    finally:
        conn.close()


def enviar_email_reset(destinatario: str, token: str) -> None:
    """Envia e-mail de redefinição via SMTP configurado em variáveis de ambiente.

    Variáveis exigidas: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM.
    Lança ErroSMTPNaoConfigurado se qualquer uma estiver ausente — a interface deve
    exibir esse erro ao administrador, nunca simular sucesso.
    """
    host = os.environ.get("SMTP_HOST")
    porta = os.environ.get("SMTP_PORT")
    usuario = os.environ.get("SMTP_USER")
    senha = os.environ.get("SMTP_PASSWORD")
    remetente = os.environ.get("SMTP_FROM")
    if not all([host, porta, usuario, senha, remetente]):
        raise ErroSMTPNaoConfigurado(
            "SMTP não configurado (SMTP_HOST/SMTP_PORT/SMTP_USER/SMTP_PASSWORD/SMTP_FROM). "
            "O e-mail de redefinição NÃO foi enviado."
        )

    msg = EmailMessage()
    msg["Subject"] = "Smart Major — Redefinição de senha"
    msg["From"] = remetente
    msg["To"] = destinatario
    msg.set_content(
        "Foi solicitada a redefinição da sua senha no Smart Major.\n"
        f"Código de redefinição (válido por {EXPIRACAO_TOKEN_MINUTOS} minutos): {token}\n"
        "Se você não solicitou, ignore esta mensagem."
    )

    with smtplib.SMTP(host, int(porta), timeout=15) as servidor:
        servidor.starttls()
        servidor.login(usuario, senha)
        servidor.send_message(msg)
