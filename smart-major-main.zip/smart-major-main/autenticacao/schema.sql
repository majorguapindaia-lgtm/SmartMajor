-- Schema do núcleo de autenticação: pessoas, vínculos, contas, tokens, sessões.
-- Banco central compartilhado com administracao/ (core.db), conforme documentado
-- em autenticacao/README.md e administracao/README.md.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_version (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    versao INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS pessoas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    endereco TEXT,
    email TEXT,
    cargo_principal TEXT,
    telefone TEXT,
    status TEXT NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo')),
    observacoes TEXT,
    criado_em TEXT NOT NULL,
    criado_por INTEGER,
    atualizado_em TEXT NOT NULL,
    atualizado_por INTEGER
);
CREATE INDEX IF NOT EXISTS idx_pessoas_nome ON pessoas(nome);

CREATE TABLE IF NOT EXISTS vinculos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pessoa_id INTEGER NOT NULL REFERENCES pessoas(id),
    tipo TEXT NOT NULL,                 -- categoria funcional: administrativo, voluntario, professor, diretor, federal, reeducando
    categoria TEXT NOT NULL,
    cargo TEXT,
    funcao TEXT,
    lotacao TEXT,
    turno TEXT CHECK (turno IN ('manha', 'tarde', 'integral', 'outro')),
    jornada_horas REAL,
    matricula TEXT,
    siape TEXT,
    data_inicio TEXT NOT NULL,
    data_fim TEXT,
    status TEXT NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo')),
    modelo_ponto_id TEXT,
    observacoes TEXT,
    criado_em TEXT NOT NULL,
    criado_por INTEGER,
    atualizado_em TEXT NOT NULL,
    atualizado_por INTEGER
);
CREATE INDEX IF NOT EXISTS idx_vinculos_pessoa ON vinculos(pessoa_id);
CREATE INDEX IF NOT EXISTS idx_vinculos_matricula ON vinculos(matricula);
CREATE INDEX IF NOT EXISTS idx_vinculos_siape ON vinculos(siape);

CREATE TABLE IF NOT EXISTS contas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pessoa_id INTEGER NOT NULL REFERENCES pessoas(id),
    login_unico TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    ativa INTEGER NOT NULL DEFAULT 1,
    master INTEGER NOT NULL DEFAULT 0,
    mfa_secret TEXT,
    mfa_ativo INTEGER NOT NULL DEFAULT 0,
    falhas_consecutivas INTEGER NOT NULL DEFAULT 0,
    bloqueada_at TEXT,
    criada_em TEXT NOT NULL,
    criada_por INTEGER
);
CREATE INDEX IF NOT EXISTS idx_contas_pessoa ON contas(pessoa_id);

CREATE TABLE IF NOT EXISTS tokens_recuperacao (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conta_id INTEGER NOT NULL REFERENCES contas(id),
    token_digest TEXT NOT NULL,
    expira_em TEXT NOT NULL,
    consumido_em TEXT,
    criado_em TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tokens_conta ON tokens_recuperacao(conta_id);

CREATE TABLE IF NOT EXISTS sessoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conta_id INTEGER NOT NULL REFERENCES contas(id),
    sessao_digest TEXT NOT NULL UNIQUE,
    criado_em TEXT NOT NULL,
    expira_em TEXT NOT NULL,
    revogado_em TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessoes_conta ON sessoes(conta_id);

CREATE TABLE IF NOT EXISTS bootstrap_master_flag (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    executado_em TEXT NOT NULL
);

INSERT OR IGNORE INTO schema_version (id, versao) VALUES (1, 1);
