"""Hash e verificação de senhas com Argon2id. Nunca armazenar senha em texto claro."""
import secrets

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError

_ph = PasswordHasher()  # parâmetros padrão da biblioteca (Argon2id)


def gerar_hash(senha: str) -> str:
    if not senha or len(senha) < 8:
        raise ValueError("A senha deve ter ao menos 8 caracteres.")
    return _ph.hash(senha)


def verificar_senha(password_hash: str, senha: str) -> bool:
    try:
        _ph.verify(password_hash, senha)
        return True
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def precisa_rehash(password_hash: str) -> bool:
    return _ph.check_needs_rehash(password_hash)


def gerar_senha_temporaria(tamanho: int = 12) -> str:
    """Gera senha aleatória criptograficamente segura para contas novas/reset manual."""
    alfabeto = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    return "".join(secrets.choice(alfabeto) for _ in range(tamanho))
