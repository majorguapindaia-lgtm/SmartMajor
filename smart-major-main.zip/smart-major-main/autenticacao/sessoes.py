"""Criação, verificação e revogação de sessões autenticadas."""
import hashlib
import secrets
from datetime import timedelta

from autenticacao.database import conectar
from common.tempo import agora_utc

DURACAO_SESSAO_HORAS = 8
DURACAO_INATIVIDADE_MINUTOS = 60


def _digest(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def criar_sessao(conta_id: int) -> str:
    """Cria uma sessão e retorna o token em texto puro (entregue uma única vez ao cliente)."""
    token = secrets.token_urlsafe(32)
    agora = agora_utc()
    expira = agora + timedelta(hours=DURACAO_SESSAO_HORAS)
    conn = conectar()
    try:
        conn.execute(
            "INSERT INTO sessoes (conta_id, sessao_digest, criado_em, expira_em) VALUES (?, ?, ?, ?)",
            (conta_id, _digest(token), agora.isoformat(), expira.isoformat()),
        )
        conn.commit()
    finally:
        conn.close()
    return token


def validar_sessao(token: str) -> int | None:
    """Retorna conta_id se a sessão for válida (não expirada, não revogada), senão None."""
    if not token:
        return None
    conn = conectar()
    try:
        linha = conn.execute(
            "SELECT * FROM sessoes WHERE sessao_digest = ?", (_digest(token),)
        ).fetchone()
        if linha is None:
            return None
        if linha["revogado_em"] is not None:
            return None
        expira = linha["expira_em"]
        if expira < agora_utc().isoformat():
            return None
        conta = conn.execute(
            "SELECT ativa, bloqueada_at FROM contas WHERE id = ?", (linha["conta_id"],)
        ).fetchone()
        if conta is None or not conta["ativa"] or conta["bloqueada_at"] is not None:
            return None
        return linha["conta_id"]
    finally:
        conn.close()


def revogar_sessao(token: str) -> None:
    conn = conectar()
    try:
        conn.execute(
            "UPDATE sessoes SET revogado_em = ? WHERE sessao_digest = ?",
            (agora_utc().isoformat(), _digest(token)),
        )
        conn.commit()
    finally:
        conn.close()


def revogar_todas_sessoes_da_conta(conta_id: int) -> None:
    """Usado ao bloquear conta ou revogar acesso crítico: invalida sessões imediatamente."""
    conn = conectar()
    try:
        conn.execute(
            "UPDATE sessoes SET revogado_em = ? WHERE conta_id = ? AND revogado_em IS NULL",
            (agora_utc().isoformat(), conta_id),
        )
        conn.commit()
    finally:
        conn.close()
