import pytest

from autenticacao.database import inicializar
from autenticacao.usuarios_cadastro import DadosPessoa, DadosVinculo, cadastrar_pessoa, ErroValidacao
from autenticacao.usuarios_consulta import obter_pessoa, buscar_por_matricula_ou_siape
from autenticacao.usuarios_edicao import editar_vinculo
from autenticacao.recuperacao import criar_conta, gerar_token_reset, consumir_token_e_redefinir
from autenticacao.login import autenticar, LIMITE_TENTATIVAS
from autenticacao.sessoes import validar_sessao, revogar_sessao
from autenticacao.bootstrap_master import bootstrap_primeiro_master, BootstrapJaExecutado


@pytest.fixture(autouse=True)
def banco():
    inicializar()


def test_pessoa_com_dois_vinculos_simultaneos():
    """Uma pessoa com vínculo administrativo à tarde e voluntário pela manhã."""
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome="Maria Exemplo"),
        [
            DadosVinculo(tipo="funcionaria", categoria="administrativo", turno="tarde",
                         jornada_horas=6, matricula="ADM-001", data_inicio="2026-01-01"),
            DadosVinculo(tipo="voluntaria", categoria="voluntario", turno="manha",
                         data_inicio="2026-01-01"),
        ],
        autor_id=None,
    )
    pessoa = obter_pessoa(pessoa_id)
    assert pessoa["nome"] == "Maria Exemplo"
    assert len(pessoa["vinculos"]) == 2
    categorias = {v["categoria"] for v in pessoa["vinculos"]}
    assert categorias == {"administrativo", "voluntario"}


def test_federal_exige_siape():
    with pytest.raises(ErroValidacao):
        cadastrar_pessoa(
            DadosPessoa(nome="Funcionário Federal"),
            [DadosVinculo(tipo="federal", categoria="federal", data_inicio="2026-01-01")],
            autor_id=None,
        )


def test_busca_por_siape():
    cadastrar_pessoa(
        DadosPessoa(nome="Servidor Federal"),
        [DadosVinculo(tipo="federal", categoria="federal", siape="1234567", data_inicio="2026-01-01")],
        autor_id=None,
    )
    resultado = buscar_por_matricula_ou_siape("1234567")
    assert len(resultado) == 1
    assert resultado[0]["pessoa"]["nome"] == "Servidor Federal"


def test_alteracao_jornada_nao_afeta_registro_historico_diretamente():
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome="Func Jornada"),
        [DadosVinculo(tipo="adm", categoria="administrativo", jornada_horas=6, data_inicio="2026-01-01")],
        autor_id=None,
    )
    vinculo_id = obter_pessoa(pessoa_id)["vinculos"][0]["id"]
    editar_vinculo(vinculo_id, {"jornada_horas": 8}, autor_id=None)
    pessoa = obter_pessoa(pessoa_id)
    assert pessoa["vinculos"][0]["jornada_horas"] == 8


def test_homonimos_sao_registros_distintos():
    id1 = cadastrar_pessoa(
        DadosPessoa(nome="João Silva"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    id2 = cadastrar_pessoa(
        DadosPessoa(nome="João Silva"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    assert id1 != id2


def test_login_sucesso_e_senha_nunca_em_claro():
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome="Login Teste"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    conta_id = criar_conta(pessoa_id, "login.teste", autor_id=None)
    token_reset = gerar_token_reset(conta_id)
    assert consumir_token_e_redefinir(token_reset, "SenhaForte123")

    resultado = autenticar("login.teste", "SenhaForte123")
    assert resultado.sucesso
    assert resultado.token_sessao is not None

    conta_valida = validar_sessao(resultado.token_sessao)
    assert conta_valida == conta_id

    import sqlite3
    from autenticacao.database import conectar
    conn = conectar()
    linha = conn.execute("SELECT password_hash FROM contas WHERE id = ?", (conta_id,)).fetchone()
    conn.close()
    assert "SenhaForte123" not in linha["password_hash"]


def test_bloqueio_apos_tentativas_repetidas():
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome="Bloqueio Teste"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    conta_id = criar_conta(pessoa_id, "bloqueio.teste", autor_id=None)
    token_reset = gerar_token_reset(conta_id)
    consumir_token_e_redefinir(token_reset, "SenhaCorreta1")

    for _ in range(LIMITE_TENTATIVAS):
        resultado = autenticar("bloqueio.teste", "senha-errada")
        assert not resultado.sucesso

    resultado_final = autenticar("bloqueio.teste", "SenhaCorreta1")
    assert not resultado_final.sucesso
    assert "bloqueada" in resultado_final.mensagem.lower()


def test_token_reset_uso_unico():
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome="Token Teste"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    conta_id = criar_conta(pessoa_id, "token.teste", autor_id=None)
    token = gerar_token_reset(conta_id)
    assert consumir_token_e_redefinir(token, "PrimeiraSenha1")
    assert not consumir_token_e_redefinir(token, "SegundaSenha1")


def test_sessao_revogada_fica_invalida():
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome="Sessao Teste"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    conta_id = criar_conta(pessoa_id, "sessao.teste", autor_id=None)
    token = gerar_token_reset(conta_id)
    consumir_token_e_redefinir(token, "SenhaSessao1")
    resultado = autenticar("sessao.teste", "SenhaSessao1")
    assert validar_sessao(resultado.token_sessao) == conta_id
    revogar_sessao(resultado.token_sessao)
    assert validar_sessao(resultado.token_sessao) is None


def test_bootstrap_master_unico():
    bootstrap_primeiro_master("Master Um", "master.um", "SenhaMasterForte1")
    with pytest.raises(BootstrapJaExecutado):
        bootstrap_primeiro_master("Master Dois", "master.dois", "OutraSenhaForte1")
