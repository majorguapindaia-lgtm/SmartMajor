"""Cadastro de pessoas e vínculos funcionais (sem criação de conta de acesso)."""
from dataclasses import dataclass

from autenticacao.database import conectar
from common.tempo import agora_utc

CATEGORIAS_VALIDAS = {
    "administrativo", "voluntario", "professor", "diretor", "federal", "reeducando",
}
TURNOS_VALIDOS = {"manha", "tarde", "integral", "outro"}


class ErroValidacao(Exception):
    pass


@dataclass
class DadosPessoa:
    nome: str
    endereco: str | None = None
    email: str | None = None
    cargo_principal: str | None = None
    telefone: str | None = None
    observacoes: str | None = None


@dataclass
class DadosVinculo:
    tipo: str
    categoria: str
    cargo: str | None = None
    funcao: str | None = None
    lotacao: str | None = None
    turno: str | None = None
    jornada_horas: float | None = None
    matricula: str | None = None
    siape: str | None = None
    data_inicio: str = ""
    data_fim: str | None = None
    modelo_ponto_id: str | None = None
    observacoes: str | None = None


def _validar_pessoa(dados: DadosPessoa) -> None:
    if not dados.nome or not dados.nome.strip():
        raise ErroValidacao("O nome completo é obrigatório.")


def _validar_vinculo(dados: DadosVinculo) -> None:
    if dados.categoria not in CATEGORIAS_VALIDAS:
        raise ErroValidacao(f"Categoria inválida: {dados.categoria}")
    if dados.turno and dados.turno not in TURNOS_VALIDOS:
        raise ErroValidacao(f"Turno inválido: {dados.turno}")
    if not dados.data_inicio:
        raise ErroValidacao("A data de início do vínculo é obrigatória.")
    if dados.categoria == "federal" and not dados.siape:
        raise ErroValidacao("SIAPE é obrigatório para vínculos federais.")


def cadastrar_pessoa(dados: DadosPessoa, vinculos: list[DadosVinculo], autor_id: int | None) -> int:
    """Cadastra uma pessoa com um ou mais vínculos, em uma única transação."""
    _validar_pessoa(dados)
    if not vinculos:
        raise ErroValidacao("É necessário informar ao menos um vínculo/atividade.")
    for v in vinculos:
        _validar_vinculo(v)

    agora = agora_utc().isoformat()
    conn = conectar()
    try:
        cur = conn.execute(
            """INSERT INTO pessoas (nome, endereco, email, cargo_principal, telefone,
                                     status, observacoes, criado_em, criado_por, atualizado_em, atualizado_por)
               VALUES (?, ?, ?, ?, ?, 'ativo', ?, ?, ?, ?, ?)""",
            (dados.nome.strip(), dados.endereco, dados.email, dados.cargo_principal,
             dados.telefone, dados.observacoes, agora, autor_id, agora, autor_id),
        )
        pessoa_id = cur.lastrowid
        for v in vinculos:
            conn.execute(
                """INSERT INTO vinculos (pessoa_id, tipo, categoria, cargo, funcao, lotacao, turno,
                                          jornada_horas, matricula, siape, data_inicio, data_fim, status,
                                          modelo_ponto_id, observacoes, criado_em, criado_por, atualizado_em, atualizado_por)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ativo', ?, ?, ?, ?, ?, ?)""",
                (pessoa_id, v.tipo, v.categoria, v.cargo, v.funcao, v.lotacao, v.turno,
                 v.jornada_horas, v.matricula, v.siape, v.data_inicio, v.data_fim,
                 v.modelo_ponto_id, v.observacoes, agora, autor_id, agora, autor_id),
            )
        conn.commit()
        return pessoa_id
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def adicionar_vinculo(pessoa_id: int, dados: DadosVinculo, autor_id: int | None) -> int:
    _validar_vinculo(dados)
    agora = agora_utc().isoformat()
    conn = conectar()
    try:
        existe = conn.execute("SELECT id FROM pessoas WHERE id = ?", (pessoa_id,)).fetchone()
        if existe is None:
            raise ErroValidacao("Pessoa não encontrada.")
        cur = conn.execute(
            """INSERT INTO vinculos (pessoa_id, tipo, categoria, cargo, funcao, lotacao, turno,
                                      jornada_horas, matricula, siape, data_inicio, data_fim, status,
                                      modelo_ponto_id, observacoes, criado_em, criado_por, atualizado_em, atualizado_por)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ativo', ?, ?, ?, ?, ?, ?)""",
            (pessoa_id, dados.tipo, dados.categoria, dados.cargo, dados.funcao, dados.lotacao,
             dados.turno, dados.jornada_horas, dados.matricula, dados.siape, dados.data_inicio,
             dados.data_fim, dados.modelo_ponto_id, dados.observacoes, agora, autor_id, agora, autor_id),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()
