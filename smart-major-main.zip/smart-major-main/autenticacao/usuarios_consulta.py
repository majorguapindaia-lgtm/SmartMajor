"""Consulta de pessoas e vínculos, com filtros."""
from autenticacao.database import conectar


def buscar_pessoas(termo: str | None = None, categoria: str | None = None,
                    status: str | None = None) -> list[dict]:
    conn = conectar()
    try:
        sql = "SELECT * FROM pessoas WHERE 1=1"
        params: list = []
        if termo:
            sql += " AND (nome LIKE ? OR email LIKE ?)"
            params += [f"%{termo}%", f"%{termo}%"]
        if status:
            sql += " AND status = ?"
            params.append(status)
        sql += " ORDER BY nome"
        pessoas = [dict(r) for r in conn.execute(sql, params).fetchall()]

        for p in pessoas:
            sql_v = "SELECT * FROM vinculos WHERE pessoa_id = ?"
            params_v: list = [p["id"]]
            if categoria:
                sql_v += " AND categoria = ?"
                params_v.append(categoria)
            p["vinculos"] = [dict(r) for r in conn.execute(sql_v, params_v).fetchall()]

        if categoria:
            pessoas = [p for p in pessoas if p["vinculos"]]
        return pessoas
    finally:
        conn.close()


def buscar_por_matricula_ou_siape(valor: str) -> list[dict]:
    conn = conectar()
    try:
        linhas = conn.execute(
            "SELECT * FROM vinculos WHERE matricula = ? OR siape = ?", (valor, valor)
        ).fetchall()
        resultado = []
        for v in linhas:
            pessoa = conn.execute("SELECT * FROM pessoas WHERE id = ?", (v["pessoa_id"],)).fetchone()
            resultado.append({"vinculo": dict(v), "pessoa": dict(pessoa) if pessoa else None})
        return resultado
    finally:
        conn.close()


def obter_pessoa(pessoa_id: int) -> dict | None:
    conn = conectar()
    try:
        p = conn.execute("SELECT * FROM pessoas WHERE id = ?", (pessoa_id,)).fetchone()
        if p is None:
            return None
        resultado = dict(p)
        resultado["vinculos"] = [
            dict(r) for r in conn.execute(
                "SELECT * FROM vinculos WHERE pessoa_id = ? ORDER BY data_inicio", (pessoa_id,)
            ).fetchall()
        ]
        return resultado
    finally:
        conn.close()
