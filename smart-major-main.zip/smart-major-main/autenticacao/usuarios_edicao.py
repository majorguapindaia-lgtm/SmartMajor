"""Edição de pessoas e vínculos, preservando histórico (sem apagar vínculos encerrados)."""
from autenticacao.database import conectar
from common.tempo import agora_utc
from autenticacao.usuarios_cadastro import ErroValidacao, _validar_vinculo, DadosVinculo


def editar_pessoa(pessoa_id: int, campos: dict, autor_id: int | None) -> None:
    permitidos = {"nome", "endereco", "email", "cargo_principal", "telefone", "observacoes", "status"}
    campos_validos = {k: v for k, v in campos.items() if k in permitidos}
    if not campos_validos:
        return
    conn = conectar()
    try:
        existe = conn.execute("SELECT id FROM pessoas WHERE id = ?", (pessoa_id,)).fetchone()
        if existe is None:
            raise ErroValidacao("Pessoa não encontrada.")
        set_sql = ", ".join(f"{k} = ?" for k in campos_validos)
        valores = list(campos_validos.values()) + [agora_utc().isoformat(), autor_id, pessoa_id]
        conn.execute(
            f"UPDATE pessoas SET {set_sql}, atualizado_em = ?, atualizado_por = ? WHERE id = ?",
            valores,
        )
        conn.commit()
    finally:
        conn.close()


def editar_vinculo(vinculo_id: int, campos: dict, autor_id: int | None) -> None:
    """Edita um vínculo existente. Encerrar um vínculo = status='inativo' + data_fim, nunca exclusão."""
    permitidos = {
        "cargo", "funcao", "lotacao", "turno", "jornada_horas", "matricula", "siape",
        "data_fim", "status", "modelo_ponto_id", "observacoes",
    }
    campos_validos = {k: v for k, v in campos.items() if k in permitidos}
    if not campos_validos:
        return
    conn = conectar()
    try:
        linha = conn.execute("SELECT * FROM vinculos WHERE id = ?", (vinculo_id,)).fetchone()
        if linha is None:
            raise ErroValidacao("Vínculo não encontrado.")
        set_sql = ", ".join(f"{k} = ?" for k in campos_validos)
        valores = list(campos_validos.values()) + [agora_utc().isoformat(), autor_id, vinculo_id]
        conn.execute(
            f"UPDATE vinculos SET {set_sql}, atualizado_em = ?, atualizado_por = ? WHERE id = ?",
            valores,
        )
        conn.commit()
    finally:
        conn.close()
