"""Verificação de sessão válida, independentemente do menu exibido.

Esta verificação cobre apenas identidade/sessão (conta ativa, não bloqueada, sessão
não expirada). A verificação de PERMISSÃO GRANULAR por módulo/ação é responsabilidade
de administracao.permissoes — deve ser chamada pelo serviço que executa a ação, não
apenas pelo menu.
"""
from autenticacao.sessoes import validar_sessao


def conta_autenticada(token_sessao: str | None) -> int | None:
    """Retorna conta_id se a sessão for válida, senão None. Chamar em toda operação sensível."""
    return validar_sessao(token_sessao)
