"""Fachada de vínculos funcionais: reexporta as operações de vínculo dos módulos de
cadastro/edição/consulta, mantendo um ponto único de referência para a UI."""
from autenticacao.usuarios_cadastro import DadosVinculo, adicionar_vinculo, CATEGORIAS_VALIDAS, TURNOS_VALIDOS
from autenticacao.usuarios_edicao import editar_vinculo
from autenticacao.usuarios_consulta import buscar_por_matricula_ou_siape

__all__ = [
    "DadosVinculo", "adicionar_vinculo", "editar_vinculo", "buscar_por_matricula_ou_siape",
    "CATEGORIAS_VALIDAS", "TURNOS_VALIDOS",
]
