"""UI de Cadastro de Funcionários — tela raiz que usa os serviços de autenticacao/.

Cadastrar/editar funcionários NÃO dá direito de alterar permissões nem tornar
alguém Master — essas ações vivem exclusivamente em administracao_ui.py.

Nota de escopo (2ª etapa de diagnóstico): a verificação de permissão desta tela
segue na camada de UI, como antes. A extensão do bloqueio em nível de serviço
(igual ao que foi feito em arquivo_passivo/folha_ponto/almoxarifado/administracao)
para autenticacao/usuarios_cadastro.py, usuarios_edicao.py e recuperacao.criar_conta
NÃO foi incluída nesta rodada de correção — ver pendência no relatório final.
"""
import streamlit as st

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import exigir_permissao, possui_permissao, ErroPermissao
from autenticacao.usuarios_cadastro import DadosPessoa, DadosVinculo, cadastrar_pessoa, ErroValidacao, CATEGORIAS_VALIDAS, TURNOS_VALIDOS
from autenticacao.usuarios_consulta import buscar_pessoas
from autenticacao.usuarios_edicao import editar_pessoa, editar_vinculo
from autenticacao.recuperacao import criar_conta


def renderizar_cadastro_funcionarios(contexto: ContextoAutorizacao):
    st.header("Cadastro de Funcionários")
    aba = st.radio("Tela", ["Cadastrar", "Consultar", "Editar"], horizontal=True)
    if aba == "Cadastrar":
        _tela_cadastrar(contexto)
    elif aba == "Consultar":
        _tela_consultar(contexto)
    else:
        _tela_editar(contexto)


def _tela_cadastrar(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "funcionarios.cadastrar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    st.subheader("Dados Pessoais")
    nome = st.text_input("Nome completo *")
    endereco = st.text_input("Endereço")
    email = st.text_input("E-mail")
    telefone = st.text_input("Telefone")
    observacoes = st.text_area("Observações")

    if "vinculos_pendentes" not in st.session_state:
        st.session_state["vinculos_pendentes"] = []

    st.subheader("Vínculos e Atividades")
    with st.form("form_vinculo", clear_on_submit=True):
        categoria = st.selectbox("Categoria *", sorted(CATEGORIAS_VALIDAS))
        turno = st.selectbox("Turno", sorted(TURNOS_VALIDOS))
        jornada = st.number_input("Jornada (horas)", min_value=0.0, max_value=12.0, step=1.0)
        matricula = st.text_input("Matrícula")
        siape = st.text_input("SIAPE (obrigatório se federal)")
        data_inicio = st.date_input("Data de início *")
        adicionar = st.form_submit_button("+ Adicionar vínculo")

    if adicionar:
        st.session_state["vinculos_pendentes"].append(DadosVinculo(
            tipo=categoria, categoria=categoria, turno=turno, jornada_horas=jornada or None,
            matricula=matricula or None, siape=siape or None, data_inicio=data_inicio.isoformat(),
        ))

    for v in st.session_state["vinculos_pendentes"]:
        st.caption(f"• {v.categoria} — turno {v.turno} — {v.jornada_horas or '-'}h — "
                   f"matrícula {v.matricula or '-'} — SIAPE {v.siape or '-'}")

    if st.button("Salvar cadastro completo"):
        try:
            pessoa_id = cadastrar_pessoa(
                DadosPessoa(nome=nome, endereco=endereco or None, email=email or None,
                            telefone=telefone or None, observacoes=observacoes or None),
                st.session_state["vinculos_pendentes"], contexto.conta_id,
            )
            st.success(f"Pessoa cadastrada com sucesso (ID {pessoa_id}).")
            st.session_state["vinculos_pendentes"] = []
        except ErroValidacao as exc:
            st.error(str(exc))


def _tela_consultar(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "funcionarios.consultar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    termo = st.text_input("Buscar por nome ou e-mail")
    for pessoa in buscar_pessoas(termo=termo or None):
        with st.expander(pessoa["nome"]):
            st.write(f"Status: {pessoa['status']} — E-mail: {pessoa.get('email') or '-'}")
            for v in pessoa["vinculos"]:
                st.caption(f"{v['categoria']} — {v['turno']} — matrícula {v.get('matricula') or '-'} "
                           f"— SIAPE {v.get('siape') or '-'} — status {v['status']}")


def _tela_editar(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "funcionarios.editar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    termo = st.text_input("Buscar pessoa para editar")
    pessoas = buscar_pessoas(termo=termo or None) if termo else []
    if not pessoas:
        st.info("Digite um nome para localizar a pessoa.")
        return

    rotulos = {p["nome"]: p for p in pessoas}
    escolhido = st.selectbox("Pessoa", list(rotulos.keys()))
    pessoa = rotulos[escolhido]

    novo_email = st.text_input("E-mail", value=pessoa.get("email") or "")
    if st.button("Salvar dados pessoais"):
        editar_pessoa(pessoa["id"], {"email": novo_email or None}, contexto.conta_id)
        st.success("Dados atualizados.")

    st.markdown("#### Criar conta de acesso (sem conceder permissões)")
    novo_login = st.text_input("Login para a nova conta")
    if st.button("Criar conta"):
        conta_nova_id = criar_conta(pessoa["id"], novo_login, contexto.conta_id)
        st.success(
            f"Conta criada (ID {conta_nova_id}), sem permissões. "
            "Vá à Administração para conceder acesso e iniciar a senha."
        )
