"""Mecanismo de backup/restauração reutilizável, usando sqlite3.Connection.backup()
(API segura mesmo com o banco em uso). Extraído do padrão original de
`arquivo_passivo/backup.py` para ser compartilhado por todos os módulos com banco
próprio (correção da 2ª etapa de diagnóstico: antes só o Arquivo Passivo tinha
backup implementado)."""
import sqlite3
from datetime import datetime
from pathlib import Path

from common.paths import caminho_backups


def criar_backup_generico(caminho_origem: Path, prefixo: str) -> Path:
    """Cria uma cópia consistente do banco em `caminho_origem`, com data/hora no nome.
    Nunca sobrescreve um backup existente (nome sempre inclui timestamp)."""
    origem = sqlite3.connect(caminho_origem)
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        destino_path = caminho_backups() / f"{prefixo}_{timestamp}.db"
        destino = sqlite3.connect(destino_path)
        try:
            origem.backup(destino)
        finally:
            destino.close()
        return destino_path
    finally:
        origem.close()


def verificar_integridade_generico(caminho_backup: Path) -> bool:
    conn = sqlite3.connect(caminho_backup)
    try:
        resultado = conn.execute("PRAGMA integrity_check").fetchone()
        return resultado is not None and resultado[0] == "ok"
    finally:
        conn.close()


def restaurar_em_caminho_separado_generico(caminho_backup: Path, caminho_destino: Path) -> None:
    """Restaura o backup em um arquivo SEPARADO, nunca sobre o banco de produção
    diretamente — testar e validar antes de qualquer substituição manual."""
    origem = sqlite3.connect(caminho_backup)
    try:
        destino = sqlite3.connect(caminho_destino)
        try:
            origem.backup(destino)
        finally:
            destino.close()
    finally:
        origem.close()
