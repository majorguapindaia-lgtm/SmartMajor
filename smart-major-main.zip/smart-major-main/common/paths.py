"""Caminhos centrais do projeto, resolvidos de forma relativa à raiz do app."""
import os
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent


def dados_privados() -> Path:
    override = os.environ.get("SMART_MAJOR_DATA_DIR")
    base = Path(override) if override else RAIZ / "dados_privados"
    (base / "backups").mkdir(parents=True, exist_ok=True)
    (base / "arquivos").mkdir(parents=True, exist_ok=True)
    base.mkdir(parents=True, exist_ok=True)
    return base


def caminho_banco(nome_arquivo: str) -> Path:
    """Retorna o caminho absoluto de um banco SQLite dentro de dados_privados/."""
    return dados_privados() / nome_arquivo


def caminho_backups() -> Path:
    return dados_privados() / "backups"


def caminho_arquivos() -> Path:
    return dados_privados() / "arquivos"


# Compatibilidade com uso anterior como constantes (avaliadas na importação).
DADOS_PRIVADOS = dados_privados()
BACKUPS = caminho_backups()
ARQUIVOS = caminho_arquivos()
