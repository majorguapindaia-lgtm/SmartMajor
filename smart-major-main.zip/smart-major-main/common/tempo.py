"""Funções de tempo: persistência em UTC, exibição no timezone institucional."""
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

TIMEZONE_INSTITUCIONAL = ZoneInfo("America/Porto_Velho")


def agora_utc() -> datetime:
    return datetime.now(timezone.utc)


def para_exibicao(momento_utc: datetime) -> datetime:
    if momento_utc.tzinfo is None:
        momento_utc = momento_utc.replace(tzinfo=timezone.utc)
    return momento_utc.astimezone(TIMEZONE_INSTITUCIONAL)


def formatar_data_br(momento_utc: datetime) -> str:
    return para_exibicao(momento_utc).strftime("%d/%m/%Y %H:%M:%S")
