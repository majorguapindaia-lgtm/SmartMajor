"""Isola cada teste em um diretório de dados privados temporário, evitando que a
suíte toque o banco real do operador."""
import os

import pytest


@pytest.fixture(autouse=True)
def isolar_dados_privados(tmp_path, monkeypatch):
    monkeypatch.setenv("SMART_MAJOR_DATA_DIR", str(tmp_path / "dados_privados"))
    yield
