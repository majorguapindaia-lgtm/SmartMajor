# Folha de Ponto

Gera documentos **para preenchimento e assinatura manual** — não é ponto eletrônico.
Exporta PDF, DOCX e XLSX diretamente em Python (reportlab, python-docx, openpyxl).

## PENDÊNCIA EXPLÍCITA

Os sete modelos em `modelos.py` são **protótipos estruturais rotulados "NÃO OFICIAL"**.
A fidelidade visual aos formulários institucionais reais (bordas, logotipo, posição
exata de campos) depende do recebimento das planilhas-modelo oficiais. Enquanto isso
não ocorrer, todo artefato gerado exibe esse aviso.

## Regras centrais implementadas e testadas

- Calendário mensal único, global, versionado (V1/V2/...), nunca sobrescrito.
- Fins de semana sempre bloqueados (cinza escuro); feriados/pontos facultativos
  cadastrados manualmente (cinza claro); sábado/domingo prevalece visualmente quando
  coincide com feriado, preservando o metadado do feriado.
- Modelo resolvido pela categoria do vínculo (administrativo distingue 6h/8h pela
  jornada cadastrada — nunca perguntada na emissão).
- Emissão gera snapshot imutável + 3 artefatos com SHA-256; duplicação de emissão é bloqueada.
- Reimpressão original devolve exatamente os mesmos bytes arquivados.
- Nova versão nunca sobrescreve a anterior; cadeia de versões é consultável.

## Testes

`pytest folha_ponto` cobre os cenários da seção 12.3 do Prompt Mestre: meses de
28/29/30/31 dias, bissexto, bloqueio de fim de semana/feriado, versionamento de
calendário V1→V2, resolução de modelo por categoria/jornada, emissão com os três
formatos, reimpressão idêntica por SHA-256, nova versão preservando a anterior, e
pessoa com dois vínculos gerando duas folhas no mesmo mês.

## Pendente de validação com dados oficiais

Comparação pixel a pixel com os formulários reais (bordas, mesclagens, brasão,
frente/verso exato dos professores) — não afirmada como concluída.
