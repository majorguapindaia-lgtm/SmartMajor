"""Backup/restauração do banco SQLite da Folha de Ponto (folha_ponto.db).

Correção de segurança (2ª etapa): mecanismo de backup que antes só existia para o
Arquivo Passivo, agora disponível também aqui, usando o mesmo padrão
sqlite3.Connection.backup(). Restrito ao Master."""
from pathlib import Path

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import conta_eh_master, ErroPermissao
from folha_ponto.database import caminho_db
from common.backup import (
    criar_backup_generico, verificar_integridade_generico, restaurar_em_caminho_separado_generico,
)


def _exigir_master(contexto: ContextoAutorizacao) -> None:
    if contexto is None or not isinstance(contexto, ContextoAutorizacao):
        raise ErroPermissao("Backup exige um contexto de autorização válido.")
    if not conta_eh_master(contexto.conta_id):
        raise ErroPermissao("Somente o Master pode executar backup/restauração.")


def criar_backup(contexto: ContextoAutorizacao) -> Path:
    _exigir_master(contexto)
    return criar_backup_generico(caminho_db(), "folha_ponto")


def verificar_integridade(caminho_backup: Path) -> bool:
    return verificar_integridade_generico(caminho_backup)


def restaurar_em_caminho_separado(caminho_backup: Path, caminho_destino: Path,
                                   contexto: ContextoAutorizacao) -> None:
    _exigir_master(contexto)
    restaurar_em_caminho_separado_generico(caminho_backup, caminho_destino)
