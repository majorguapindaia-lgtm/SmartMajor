"""Cálculo de dias não trabalháveis de um mês: fins de semana (automático) e
feriados/pontos facultativos (cadastro manual, nunca hard-coded por ano)."""
import calendar
from dataclasses import dataclass
from datetime import date

from administracao.contexto import ContextoAutorizacao, exigir
from folha_ponto.database import conectar

TIPO_UTIL = "util"
TIPO_SABADO = "sabado"
TIPO_DOMINGO = "domingo"
TIPO_FERIADO = "feriado"
TIPO_PONTO_FACULTATIVO = "ponto_facultativo"


@dataclass(frozen=True)
class DiaCalendario:
    data: date
    tipo: str          # tipo exibido (sábado/domingo prevalece sobre feriado)
    rotulo: str
    descricao_feriado: str | None = None  # preservado para auditoria, mesmo se sobreposto


def obter_calendario_vigente(ano: int, mes: int, contexto: ContextoAutorizacao) -> dict | None:
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        return next(
            (dict(r) for r in conn.execute(
                "SELECT * FROM calendarios WHERE ano = ? AND mes = ? AND status = 'publicado' "
                "ORDER BY versao DESC LIMIT 1", (ano, mes),
            ).fetchall()), None,
        )
    finally:
        conn.close()


def dias_especiais_do_calendario(calendario_id: int) -> list[dict]:
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM calendario_dias WHERE calendario_id = ?", (calendario_id,)
        ).fetchall()]
    finally:
        conn.close()


def montar_grade_mensal(ano: int, mes: int, calendario_id: int) -> list[DiaCalendario]:
    """Monta a grade do mês com a precedência: sábado/domingo > feriado/ponto facultativo > útil."""
    especiais = {d["data"]: d for d in dias_especiais_do_calendario(calendario_id)}
    _, total_dias = calendar.monthrange(ano, mes)

    grade = []
    for dia in range(1, total_dias + 1):
        data_atual = date(ano, mes, dia)
        iso = data_atual.isoformat()
        dia_semana = data_atual.weekday()  # 0=segunda ... 5=sábado, 6=domingo

        especial = especiais.get(iso)
        descricao_especial = especial["descricao"] if especial else None

        if dia_semana == 5:
            grade.append(DiaCalendario(data_atual, TIPO_SABADO, "SÁBADO", descricao_especial))
        elif dia_semana == 6:
            grade.append(DiaCalendario(data_atual, TIPO_DOMINGO, "DOMINGO", descricao_especial))
        elif especial:
            rotulo = "FERIADO" if especial["tipo"] == "feriado" else "PONTO FACULTATIVO"
            grade.append(DiaCalendario(data_atual, especial["tipo"], rotulo, descricao_especial))
        else:
            grade.append(DiaCalendario(data_atual, TIPO_UTIL, "", None))
    return grade


def dia_e_assinavel(dia: DiaCalendario) -> bool:
    return dia.tipo == TIPO_UTIL
