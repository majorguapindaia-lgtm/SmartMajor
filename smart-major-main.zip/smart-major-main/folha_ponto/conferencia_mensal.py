"""Relatório mensal de conferência: cada par pessoa+vínculo+período é uma folha
prevista. Cruza dados de vínculos (banco core) com folhas emitidas (banco próprio)
pelo serviço, sem assumir FK nativa entre bancos separados."""
from dataclasses import dataclass

from administracao.contexto import ContextoAutorizacao, exigir
from folha_ponto.database import conectar
from folha_ponto.versoes_calendario import listar_versoes

STATUS_NAO_EMITIDA = "Não emitida"
STATUS_EMITIDA = "Emitida"
STATUS_NOVA_VERSAO = "Nova versão emitida"
STATUS_CALENDARIO_ANTERIOR = "Calendário anterior — verificar reemissão"


@dataclass
class LinhaConferencia:
    pessoa_id: int
    vinculo_id: int
    nome: str
    matricula: str | None
    siape: str | None
    categoria: str
    modelo_ponto_id: str | None
    status: str
    folha_id: int | None
    versao_folha: int | None


def montar_relatorio(vinculos_ativos: list[dict], ano: int, mes: int,
                      contexto: ContextoAutorizacao) -> list[LinhaConferencia]:
    """vinculos_ativos: lista de dicts vindos de autenticacao.usuarios_consulta,
    já filtrados pelos vínculos vigentes no período (responsabilidade do chamador)."""
    exigir(contexto, "folha_ponto.consultar")
    versoes = listar_versoes(ano, mes, contexto)
    calendario_vigente_id = next((v["id"] for v in versoes if v["status"] == "publicado"), None)

    conn = conectar()
    try:
        folhas_por_vinculo = {}
        for linha in conn.execute(
            "SELECT * FROM folhas WHERE ano = ? AND mes = ? ORDER BY versao_folha DESC", (ano, mes)
        ).fetchall():
            folha = dict(linha)
            folhas_por_vinculo.setdefault(folha["vinculo_id"], folha)
    finally:
        conn.close()

    linhas = []
    for vinculo in vinculos_ativos:
        folha = folhas_por_vinculo.get(vinculo["id"])
        if folha is None:
            status = STATUS_NAO_EMITIDA
        elif folha["versao_folha"] > 1:
            status = STATUS_NOVA_VERSAO
        elif calendario_vigente_id is not None and folha["calendario_id"] != calendario_vigente_id:
            status = STATUS_CALENDARIO_ANTERIOR
        else:
            status = STATUS_EMITIDA

        linhas.append(LinhaConferencia(
            pessoa_id=vinculo["pessoa_id"], vinculo_id=vinculo["id"], nome=vinculo.get("nome", ""),
            matricula=vinculo.get("matricula"), siape=vinculo.get("siape"), categoria=vinculo["categoria"],
            modelo_ponto_id=folha["modelo_ponto_id"] if folha else None, status=status,
            folha_id=folha["id"] if folha else None, versao_folha=folha["versao_folha"] if folha else None,
        ))
    return linhas
