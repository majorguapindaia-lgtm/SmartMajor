"""Emissão de folhas de ponto: primeira emissão produz snapshot imutável + PDF/DOCX/XLSX."""
from administracao.contexto import ContextoAutorizacao, exigir
from folha_ponto.database import conectar
from folha_ponto.calendario import obter_calendario_vigente, montar_grade_mensal
from folha_ponto.modelos import resolver_modelo
from folha_ponto.exportacao_pdf import gerar_pdf
from folha_ponto.exportacao_word import gerar_docx
from folha_ponto.exportacao_excel import gerar_xlsx
from folha_ponto.services import salvar_artefato, registrar_evento_emissao, serializar_snapshot
from common.tempo import agora_utc


class ErroEmissao(Exception):
    pass


def ja_existe_folha(pessoa_id: int, vinculo_id: int, ano: int, mes: int,
                     contexto: ContextoAutorizacao) -> dict | None:
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        linha = conn.execute(
            """SELECT * FROM folhas WHERE pessoa_id = ? AND vinculo_id = ? AND ano = ? AND mes = ?
               ORDER BY versao_folha DESC LIMIT 1""",
            (pessoa_id, vinculo_id, ano, mes),
        ).fetchone()
        return dict(linha) if linha else None
    finally:
        conn.close()


def emitir_folha(
    pessoa_id: int, vinculo_id: int, nome: str, categoria: str, jornada_horas: float | None,
    ano: int, mes: int, contexto: ContextoAutorizacao,
) -> int:
    exigir(contexto, "folha_ponto.emitir")
    existente = ja_existe_folha(pessoa_id, vinculo_id, ano, mes, contexto)
    if existente:
        raise ErroEmissao(
            f"Já existe folha emitida para esta pessoa/vínculo em {mes:02d}/{ano} "
            f"(folha {existente['id']}, versão {existente['versao_folha']}). "
            "Use reimpressão ou gere nova versão."
        )

    calendario = obter_calendario_vigente(ano, mes, contexto)
    if calendario is None:
        raise ErroEmissao(f"Nenhum calendário publicado para {mes:02d}/{ano}.")

    modelo = resolver_modelo(categoria, jornada_horas)
    grade = montar_grade_mensal(ano, mes, calendario["id"])

    cabecalho = {"nome": nome, "ano": ano, "mes": mes, "categoria": categoria}
    snapshot = {
        "cabecalho": cabecalho,
        "pessoa_id": pessoa_id, "vinculo_id": vinculo_id,
        "modelo_id": modelo.id, "modelo_versao": modelo.versao,
        "calendario_id": calendario["id"], "calendario_versao": calendario["versao"],
        "dias": [{"data": d.data.isoformat(), "tipo": d.tipo, "rotulo": d.rotulo} for d in grade],
    }

    conn = conectar()
    try:
        agora = agora_utc().isoformat()
        cur = conn.execute(
            """INSERT INTO folhas (pessoa_id, vinculo_id, ano, mes, versao_folha, calendario_id,
                                    modelo_ponto_id, snapshot_dados, criada_por, criada_em)
               VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?)""",
            (pessoa_id, vinculo_id, ano, mes, calendario["id"], modelo.id,
             serializar_snapshot(snapshot), contexto.conta_id, agora),
        )
        folha_id = cur.lastrowid
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    for formato, gerador in (("pdf", gerar_pdf), ("docx", gerar_docx), ("xlsx", gerar_xlsx)):
        conteudo = gerador(cabecalho, grade, modelo)
        salvar_artefato(folha_id, formato, conteudo)

    registrar_evento_emissao(folha_id, "emissao", contexto.conta_id)
    return folha_id
