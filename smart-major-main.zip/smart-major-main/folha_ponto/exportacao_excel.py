"""Geração de XLSX da folha de ponto com openpyxl.

PROTÓTIPO NÃO OFICIAL (ver folha_ponto/modelos.py) até validação com formulários reais.
Para o modelo de professores (frente e verso), usa duas abas: 'Frente' e 'Verso'.
"""
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font
from openpyxl.worksheet.page import PageMargins

from folha_ponto.calendario import dia_e_assinavel
from folha_ponto.modelos import ModeloPonto

PREENCHIMENTO_ESCURO = PatternFill(start_color="808080", end_color="808080", fill_type="solid")
PREENCHIMENTO_CLARO = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")


def _preencher_planilha(aba, cabecalho: dict, grade: list, modelo: ModeloPonto) -> None:
    aba.append(["FOLHA DE PONTO — PROTÓTIPO NÃO OFICIAL"])
    aba["A1"].font = Font(bold=True, size=14)
    aba.append([f"Modelo: {modelo.nome}", f"Mês/Ano: {cabecalho['mes']:02d}/{cabecalho['ano']}"])
    aba.append([f"Nome: {cabecalho['nome']}"])
    aba.append([])
    aba.append(["Data", "Dia", "Entrada", "Saída", "Assinatura"])

    for dia in grade:
        linha = [dia.data.strftime("%d/%m/%Y")]
        if dia_e_assinavel(dia):
            linha += ["", "", "", ""]
            aba.append(linha)
        else:
            linha += [dia.rotulo, "", "", ""]
            aba.append(linha)
            preenchimento = PREENCHIMENTO_ESCURO if dia.tipo in ("sabado", "domingo") else PREENCHIMENTO_CLARO
            for celula in aba[aba.max_row]:
                celula.fill = preenchimento

    aba.page_setup.orientation = "landscape" if modelo.orientacao == "paisagem" else "portrait"
    aba.page_margins = PageMargins(left=0.5, right=0.5, top=0.5, bottom=0.5)
    aba.print_area = f"A1:E{aba.max_row}"
    for coluna, largura in zip("ABCDE", (14, 18, 12, 12, 24)):
        aba.column_dimensions[coluna].width = largura


def gerar_xlsx(cabecalho: dict, grade: list, modelo: ModeloPonto) -> bytes:
    livro = Workbook()
    aba_frente = livro.active
    aba_frente.title = "Frente"
    _preencher_planilha(aba_frente, cabecalho, grade, modelo)

    if modelo.paginas == 2:
        aba_verso = livro.create_sheet("Verso")
        aba_verso.append(["Verso — campos complementares (professores)."])

    buffer = BytesIO()
    livro.save(buffer)
    return buffer.getvalue()
