"""Geração de PDF da folha de ponto com ReportLab.

PROTÓTIPO NÃO OFICIAL (ver folha_ponto/modelos.py) até a validação com os
formulários institucionais reais.
"""
from io import BytesIO

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

from folha_ponto.calendario import dia_e_assinavel
from folha_ponto.modelos import ModeloPonto

CINZA_ESCURO = colors.HexColor("#808080")
CINZA_CLARO = colors.HexColor("#D9D9D9")


def gerar_pdf(cabecalho: dict, grade: list, modelo: ModeloPonto) -> bytes:
    buffer = BytesIO()
    tamanho_pagina = landscape(A4) if modelo.orientacao == "paisagem" else A4
    doc = SimpleDocTemplate(buffer, pagesize=tamanho_pagina,
                             leftMargin=1.5 * cm, rightMargin=1.5 * cm,
                             topMargin=1.5 * cm, bottomMargin=1.5 * cm)
    estilos = getSampleStyleSheet()
    elementos = [
        Paragraph("FOLHA DE PONTO — PROTÓTIPO NÃO OFICIAL", estilos["Title"]),
        Paragraph(f"Modelo: {modelo.nome} — Mês/Ano: {cabecalho['mes']:02d}/{cabecalho['ano']}", estilos["Normal"]),
        Paragraph(f"Nome: {cabecalho['nome']}", estilos["Normal"]),
        Spacer(1, 0.3 * cm),
    ]

    linhas = [["Data", "Dia", "Entrada", "Saída", "Assinatura"]]
    estilos_linhas = []
    for indice, dia in enumerate(grade, start=1):
        if dia_e_assinavel(dia):
            linhas.append([dia.data.strftime("%d/%m/%Y"), "", "", "", ""])
        else:
            linhas.append([dia.data.strftime("%d/%m/%Y"), dia.rotulo, "", "", ""])
            cor = CINZA_ESCURO if dia.tipo in ("sabado", "domingo") else CINZA_CLARO
            estilos_linhas.append(("BACKGROUND", (0, indice), (-1, indice), cor))

    tabela = Table(linhas, colWidths=[2.5 * cm, 3.5 * cm, 3 * cm, 3 * cm, 5 * cm])
    estilo_base = [
        ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
    ] + estilos_linhas
    tabela.setStyle(TableStyle(estilo_base))
    elementos.append(tabela)

    doc.build(elementos)
    return buffer.getvalue()
