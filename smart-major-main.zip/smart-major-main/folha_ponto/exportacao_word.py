"""Geração de DOCX da folha de ponto com python-docx.

PROTÓTIPO NÃO OFICIAL (ver folha_ponto/modelos.py) até validação com formulários reais.
"""
from io import BytesIO

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.shared import Pt, RGBColor

from folha_ponto.calendario import dia_e_assinavel
from folha_ponto.modelos import ModeloPonto

CINZA_ESCURO = RGBColor(0x80, 0x80, 0x80)
CINZA_CLARO = RGBColor(0xD9, 0xD9, 0xD9)


def _sombrear_celula(celula, cor_hex: str) -> None:
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    propriedades = celula._tc.get_or_add_tcPr()
    sombreado = OxmlElement("w:shd")
    sombreado.set(qn("w:fill"), cor_hex)
    propriedades.append(sombreado)


def gerar_docx(cabecalho: dict, grade: list, modelo: ModeloPonto) -> bytes:
    documento = Document()

    if modelo.orientacao == "paisagem":
        secao = documento.sections[0]
        secao.orientation = WD_ORIENT.LANDSCAPE
        secao.page_width, secao.page_height = secao.page_height, secao.page_width

    titulo = documento.add_heading("FOLHA DE PONTO — PROTÓTIPO NÃO OFICIAL", level=1)
    documento.add_paragraph(f"Modelo: {modelo.nome} — Mês/Ano: {cabecalho['mes']:02d}/{cabecalho['ano']}")
    documento.add_paragraph(f"Nome: {cabecalho['nome']}")

    tabela = documento.add_table(rows=1, cols=5)
    tabela.style = "Table Grid"
    cabecalhos = ["Data", "Dia", "Entrada", "Saída", "Assinatura"]
    for indice, texto in enumerate(cabecalhos):
        tabela.rows[0].cells[indice].text = texto

    for dia in grade:
        linha = tabela.add_row().cells
        linha[0].text = dia.data.strftime("%d/%m/%Y")
        if dia_e_assinavel(dia):
            linha[1].text = ""
        else:
            linha[1].text = dia.rotulo
            cor_hex = "808080" if dia.tipo in ("sabado", "domingo") else "D9D9D9"
            for celula in linha:
                _sombrear_celula(celula, cor_hex)

    if modelo.paginas == 2:
        documento.add_page_break()
        documento.add_heading("Verso", level=2)
        documento.add_paragraph("Campos complementares do verso (frente e verso — professores).")

    buffer = BytesIO()
    documento.save(buffer)
    return buffer.getvalue()
