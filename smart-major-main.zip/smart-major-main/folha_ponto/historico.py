"""Consulta de histórico imutável de folhas emitidas."""
from administracao.contexto import ContextoAutorizacao, exigir
from folha_ponto.database import conectar


def listar_folhas_pessoa_vinculo(pessoa_id: int, vinculo_id: int,
                                  contexto: ContextoAutorizacao) -> list[dict]:
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            """SELECT * FROM folhas WHERE pessoa_id = ? AND vinculo_id = ?
               ORDER BY ano DESC, mes DESC, versao_folha DESC""",
            (pessoa_id, vinculo_id),
        ).fetchall()]
    finally:
        conn.close()


def cadeia_de_versoes(folha_id: int, contexto: ContextoAutorizacao) -> list[dict]:
    """Retorna a cadeia de versões (da mais antiga à mais recente) de uma folha."""
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        folha = conn.execute("SELECT * FROM folhas WHERE id = ?", (folha_id,)).fetchone()
        if folha is None:
            return []
        cadeia = [dict(folha)]
        cursor = dict(folha)
        while cursor["anterior_id"] is not None:
            anterior = conn.execute("SELECT * FROM folhas WHERE id = ?", (cursor["anterior_id"],)).fetchone()
            if anterior is None:
                break
            cursor = dict(anterior)
            cadeia.insert(0, cursor)
        return cadeia
    finally:
        conn.close()


def eventos_da_folha(folha_id: int, contexto: ContextoAutorizacao) -> list[dict]:
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM eventos_emissao WHERE folha_id = ? ORDER BY data", (folha_id,)
        ).fetchall()]
    finally:
        conn.close()
