"""Catálogo dos SETE modelos de folha de ponto.

IMPORTANTE — PENDÊNCIA EXPLÍCITA: os layouts abaixo são protótipos estruturais
(campos, orientação, páginas), NÃO reproduções visuais fiéis dos formulários
oficiais. A fidelidade visual (bordas, logotipos, posição exata de campos) só pode
ser implementada após o recebimento das planilhas-modelo reais. Todo artefato
gerado por este motor enquanto essa pendência existir é rotulado como "NÃO OFICIAL".
"""
from dataclasses import dataclass, field

NAO_OFICIAL = True  # enquanto as planilhas reais não forem recebidas, ver módulo acima.


@dataclass(frozen=True)
class ModeloPonto:
    id: str
    categoria: str
    nome: str
    versao: int
    orientacao: str  # 'retrato' | 'paisagem'
    paginas: int
    campos: tuple[str, ...] = field(default_factory=tuple)


CATALOGO_MODELOS: dict[str, ModeloPonto] = {
    "reeducandos": ModeloPonto(
        id="reeducandos", categoria="reeducando", nome="Reeducandos", versao=1,
        orientacao="retrato", paginas=1,
        campos=("nome", "entrada", "saida", "assinatura"),
    ),
    "amigos_voluntarios": ModeloPonto(
        id="amigos_voluntarios", categoria="voluntario", nome="Amigos Voluntários", versao=1,
        orientacao="retrato", paginas=1,
        campos=("nome", "entrada", "saida", "assinatura"),
    ),
    "administrativo_6h": ModeloPonto(
        id="administrativo_6h", categoria="administrativo", nome="Administrativo 6 horas", versao=1,
        orientacao="retrato", paginas=1,
        campos=("nome", "matricula", "entrada", "saida", "assinatura"),
    ),
    "administrativo_8h": ModeloPonto(
        id="administrativo_8h", categoria="administrativo", nome="Administrativo 8 horas", versao=1,
        orientacao="retrato", paginas=1,
        campos=("nome", "matricula", "entrada_manha", "saida_manha", "entrada_tarde", "saida_tarde", "assinatura"),
    ),
    "diretor": ModeloPonto(
        id="diretor", categoria="diretor", nome="Diretor (Secretaria Municipal/Estadual)", versao=1,
        orientacao="retrato", paginas=1,
        campos=("nome", "orgao", "entrada_manha", "saida_manha", "entrada_tarde", "saida_tarde", "assinatura"),
    ),
    "federais": ModeloPonto(
        id="federais", categoria="federal", nome="Funcionários Federais (SIAPE)", versao=1,
        orientacao="retrato", paginas=1,
        campos=("nome", "siape", "entrada", "saida", "assinatura"),
    ),
    "professores": ModeloPonto(
        id="professores", categoria="professor", nome="Professores (paisagem, frente e verso)", versao=1,
        orientacao="paisagem", paginas=2,
        campos=("nome", "matricula", "disciplina", "entrada", "saida", "assinatura"),
    ),
}


def resolver_modelo(categoria: str, jornada_horas: float | None = None) -> ModeloPonto:
    """Deriva o modelo a partir da categoria do vínculo, distinguindo 6h/8h para
    administrativo. A jornada vem do vínculo cadastrado — não é pedida na emissão."""
    if categoria == "administrativo":
        if jornada_horas is not None and float(jornada_horas) >= 8:
            return CATALOGO_MODELOS["administrativo_8h"]
        return CATALOGO_MODELOS["administrativo_6h"]
    for modelo in CATALOGO_MODELOS.values():
        if modelo.categoria == categoria:
            return modelo
    raise ValueError(f"Nenhum modelo de folha de ponto associado à categoria '{categoria}'.")
