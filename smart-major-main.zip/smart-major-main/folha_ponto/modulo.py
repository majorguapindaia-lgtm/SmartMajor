"""Interface Streamlit da Folha de Ponto.

Correção de segurança: cada ação verifica sua permissão granular ESPECÍFICA
(emitir / reimprimir / nova_versao / alterar_calendario / consultar), tanto aqui
quanto dentro dos serviços chamados — ter uma não concede as outras.
"""
import streamlit as st
import pandas as pd

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import exigir_permissao, ErroPermissao
from autenticacao.usuarios_consulta import buscar_pessoas
from folha_ponto.database import inicializar
from folha_ponto.calendario import montar_grade_mensal, obter_calendario_vigente, dia_e_assinavel
from folha_ponto.versoes_calendario import publicar_calendario, listar_versoes
from folha_ponto.emissao import emitir_folha, ErroEmissao
from folha_ponto.reimpressao import reimprimir_original, gerar_nova_versao, solicitar_reimpressao
from folha_ponto.historico import listar_folhas_pessoa_vinculo
from folha_ponto.conferencia_mensal import montar_relatorio
from folha_ponto.modelos import NAO_OFICIAL


def renderizar(contexto: ContextoAutorizacao):
    inicializar()
    st.header("Folha de Ponto")
    if NAO_OFICIAL:
        st.warning(
            "Protótipo estrutural: os layouts gerados ainda NÃO reproduzem fielmente os "
            "formulários institucionais oficiais. Pendente o recebimento das planilhas-modelo reais."
        )
    aba = st.radio("Tela", ["Calendário mensal", "Emitir / Reimprimir", "Conferência mensal"], horizontal=True)
    if aba == "Calendário mensal":
        _tela_calendario(contexto)
    elif aba == "Emitir / Reimprimir":
        _tela_emissao(contexto)
    else:
        _tela_conferencia(contexto)


def _tela_calendario(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "folha_ponto.alterar_calendario")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    col1, col2 = st.columns(2)
    with col1:
        ano = st.number_input("Ano", min_value=2000, max_value=2100, value=2026, step=1)
    with col2:
        mes = st.number_input("Mês", min_value=1, max_value=12, value=11, step=1)

    vigente = obter_calendario_vigente(int(ano), int(mes), contexto)
    if vigente:
        st.info(f"Calendário vigente: versão {vigente['versao']} (publicado em {vigente['publicado_em']}).")

    st.markdown("#### Cadastrar dias não trabalháveis (feriado/ponto facultativo)")
    data_especial = st.date_input("Data")
    tipo_especial = st.radio("Tipo", ["feriado", "ponto_facultativo"])
    descricao_especial = st.text_input("Descrição")
    decreto_especial = st.text_input("Decreto/fonte (opcional)")

    if "dias_pendentes" not in st.session_state:
        st.session_state["dias_pendentes"] = []

    if st.button("+ Adicionar data"):
        st.session_state["dias_pendentes"].append({
            "data": data_especial.isoformat(), "tipo": tipo_especial,
            "descricao": descricao_especial, "decreto": decreto_especial or None,
        })

    if st.session_state["dias_pendentes"]:
        st.dataframe(pd.DataFrame(st.session_state["dias_pendentes"]))

    motivo_publicacao = st.text_input("Motivo da publicação (obrigatório ao atualizar versão existente)")
    if st.button("Publicar nova versão do calendário"):
        publicar_calendario(int(ano), int(mes), st.session_state["dias_pendentes"], contexto, motivo_publicacao)
        st.session_state["dias_pendentes"] = []
        st.success("Calendário publicado como nova versão global.")

    versoes = listar_versoes(int(ano), int(mes), contexto)
    if versoes:
        st.markdown("#### Histórico de versões")
        st.dataframe(pd.DataFrame(versoes))


def _tela_emissao(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "folha_ponto.emitir")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    pessoas = buscar_pessoas()
    rotulos = {p["nome"]: p for p in pessoas}
    if not rotulos:
        st.info("Nenhuma pessoa cadastrada ainda. Cadastre em Autenticação/Funcionários.")
        return

    nome_escolhido = st.selectbox("Pessoa", list(rotulos.keys()))
    pessoa = rotulos[nome_escolhido]
    vinculos = pessoa.get("vinculos", [])
    if not vinculos:
        st.warning("Esta pessoa não possui vínculos cadastrados.")
        return

    rotulos_vinculo = {f"{v['categoria']} ({v.get('turno') or '-'})": v for v in vinculos}
    vinculo_escolhido = st.selectbox("Vínculo", list(rotulos_vinculo.keys()))
    vinculo = rotulos_vinculo[vinculo_escolhido]

    col1, col2 = st.columns(2)
    with col1:
        ano = st.number_input("Ano", min_value=2000, max_value=2100, value=2026, step=1, key="emit_ano")
    with col2:
        mes = st.number_input("Mês", min_value=1, max_value=12, value=11, step=1, key="emit_mes")

    if st.button("Emitir folha"):
        try:
            folha_id = emitir_folha(
                pessoa["id"], vinculo["id"], pessoa["nome"], vinculo["categoria"],
                vinculo.get("jornada_horas"), int(ano), int(mes), contexto,
            )
            st.success(f"Folha {folha_id} emitida com sucesso (PDF, DOCX e XLSX gerados).")
        except ErroEmissao as exc:
            st.error(str(exc))

    st.divider()
    st.markdown("#### Histórico desta pessoa/vínculo")
    try:
        exigir_permissao(contexto.conta_id, "folha_ponto.consultar")
    except ErroPermissao as exc:
        st.caption(f"Histórico indisponível: {exc}")
        return
    folhas = listar_folhas_pessoa_vinculo(pessoa["id"], vinculo["id"], contexto)
    if not folhas:
        st.caption("Nenhuma folha emitida ainda.")
        return

    rotulos_folha = {f"{f['mes']:02d}/{f['ano']} — v{f['versao_folha']} (ID {f['id']})": f for f in folhas}
    folha_escolhida = st.selectbox("Abrir folha existente", list(rotulos_folha.keys()))
    folha = rotulos_folha[folha_escolhida]

    st.markdown("**Deseja reimprimir a versão original ou gerar uma nova versão?**")
    acao = st.radio("Ação", ["Reimprimir original", "Gerar nova versão"], key="acao_folha")

    if acao == "Reimprimir original":
        if not _tem_permissao_silenciosa(contexto, "folha_ponto.reimprimir"):
            st.info("Sua conta não tem a permissão 'folha_ponto.reimprimir'.")
        else:
            formato = st.selectbox("Formato", ["pdf", "docx", "xlsx"])
            motivo_reimpressao = st.text_input("Motivo (opcional)")
            if st.button("Baixar reimpressão"):
                try:
                    conteudo = reimprimir_original(folha["id"], formato, contexto, motivo_reimpressao or None)
                    st.download_button("Clique para baixar", data=conteudo,
                                        file_name=f"folha_{folha['id']}_original.{formato}")
                except Exception as exc:
                    st.error(str(exc))
    else:
        if not _tem_permissao_silenciosa(contexto, "folha_ponto.nova_versao"):
            st.info("Sua conta não tem a permissão 'folha_ponto.nova_versao'.")
        else:
            motivo_nova_versao = st.text_input("Justificativa obrigatória para nova versão")
            if st.button("Confirmar nova versão"):
                try:
                    nova_id = gerar_nova_versao(folha["id"], contexto, motivo_nova_versao)
                    st.success(f"Nova versão criada: folha {nova_id}.")
                except Exception as exc:
                    st.error(str(exc))

    if _tem_permissao_silenciosa(contexto, "folha_ponto.reimprimir"):
        with st.expander("Solicitar reimpressão por erro manuscrito"):
            motivo_solicitacao = st.text_input("Motivo da solicitação")
            if st.button("Registrar solicitação"):
                solicitar_reimpressao(folha["id"], motivo_solicitacao, contexto)
                st.success("Solicitação registrada.")


def _tem_permissao_silenciosa(contexto: ContextoAutorizacao, permissao: str) -> bool:
    from administracao.permissoes import possui_permissao
    return possui_permissao(contexto.conta_id, permissao)


def _tela_conferencia(contexto: ContextoAutorizacao):
    try:
        exigir_permissao(contexto.conta_id, "folha_ponto.consultar")
    except ErroPermissao as exc:
        st.error(str(exc))
        return

    col1, col2 = st.columns(2)
    with col1:
        ano = st.number_input("Ano", min_value=2000, max_value=2100, value=2026, step=1, key="conf_ano")
    with col2:
        mes = st.number_input("Mês", min_value=1, max_value=12, value=11, step=1, key="conf_mes")

    pessoas = buscar_pessoas()
    vinculos_ativos = []
    for p in pessoas:
        for v in p.get("vinculos", []):
            if v["status"] == "ativo":
                vinculo_com_nome = dict(v)
                vinculo_com_nome["nome"] = p["nome"]
                vinculos_ativos.append(vinculo_com_nome)

    linhas = montar_relatorio(vinculos_ativos, int(ano), int(mes), contexto)
    if not linhas:
        st.info("Nenhum vínculo ativo encontrado.")
        return

    df = pd.DataFrame([l.__dict__ for l in linhas])
    st.dataframe(df, use_container_width=True)
    st.caption(f"Total de folhas previstas: {len(linhas)}")
