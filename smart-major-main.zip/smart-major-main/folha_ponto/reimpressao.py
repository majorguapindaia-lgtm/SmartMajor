"""Reimpressão da versão original (bytes arquivados, identidade exata) e geração
de nova versão explícita (nunca reutiliza o identificador/arquivo da versão anterior).

Correção de segurança (2ª etapa de diagnóstico): `folha_ponto.emitir`,
`folha_ponto.reimprimir` e `folha_ponto.nova_versao` são permissões GRANULARES
distintas, cada uma verificada dentro do serviço correspondente — ter uma não
implica ter as outras.
"""
import hashlib
import json

from administracao.contexto import ContextoAutorizacao, exigir
from folha_ponto.database import conectar
from folha_ponto.calendario import obter_calendario_vigente, montar_grade_mensal
from folha_ponto.modelos import resolver_modelo
from folha_ponto.exportacao_pdf import gerar_pdf
from folha_ponto.exportacao_word import gerar_docx
from folha_ponto.exportacao_excel import gerar_xlsx
from folha_ponto.services import (
    salvar_artefato, obter_artefatos_da_folha, ler_bytes_artefato,
    registrar_evento_emissao, serializar_snapshot,
)
from common.tempo import agora_utc


class ErroReimpressao(Exception):
    pass


def reimprimir_original(folha_id: int, formato: str, contexto: ContextoAutorizacao,
                         motivo: str | None = None) -> bytes:
    """Retorna os MESMOS bytes arquivados na emissão original (nunca regenera)."""
    exigir(contexto, "folha_ponto.reimprimir")
    artefatos = obter_artefatos_da_folha(folha_id, contexto)
    artefato = next((a for a in artefatos if a["formato"] == formato), None)
    if artefato is None:
        raise ErroReimpressao(f"Artefato '{formato}' não encontrado para a folha {folha_id}.")

    conteudo = ler_bytes_artefato(artefato["arquivo_protegido"])
    if hashlib.sha256(conteudo).hexdigest() != artefato["sha256"]:
        raise ErroReimpressao("Integridade do arquivo arquivado não pôde ser confirmada (SHA-256 divergente).")

    registrar_evento_emissao(folha_id, "reimpressao", contexto.conta_id, motivo=motivo, formato=formato)
    return conteudo


def solicitar_reimpressao(folha_id: int, motivo: str, contexto: ContextoAutorizacao) -> int:
    """Registra pedido de reimpressão (erro manuscrito etc.). Nunca confirma
    automaticamente que o documento foi assinado/entregue — isso é fato humano."""
    exigir(contexto, "folha_ponto.reimprimir")
    conn = conectar()
    try:
        cur = conn.execute(
            "INSERT INTO solicitacoes_reimpressao (folha_id, motivo, solicitante, situacao, criado_em) "
            "VALUES (?, ?, ?, 'pendente', ?)",
            (folha_id, motivo, contexto.conta_id, agora_utc().isoformat()),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def listar_solicitacoes(contexto: ContextoAutorizacao, folha_id: int | None = None) -> list[dict]:
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        sql = "SELECT * FROM solicitacoes_reimpressao"
        params: list = []
        if folha_id is not None:
            sql += " WHERE folha_id = ?"
            params.append(folha_id)
        sql += " ORDER BY criado_em DESC"
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()


def atender_solicitacao(solicitacao_id: int, contexto: ContextoAutorizacao) -> None:
    exigir(contexto, "folha_ponto.reimprimir")
    conn = conectar()
    try:
        conn.execute("UPDATE solicitacoes_reimpressao SET situacao = 'atendida' WHERE id = ?", (solicitacao_id,))
        conn.commit()
    finally:
        conn.close()


def gerar_nova_versao(folha_id_anterior: int, contexto: ContextoAutorizacao, motivo: str) -> int:
    """Cria uma nova versão explícita da folha, preservando a anterior integralmente."""
    exigir(contexto, "folha_ponto.nova_versao")
    if not motivo or not motivo.strip():
        raise ErroReimpressao("É obrigatório informar a justificativa para gerar nova versão.")

    conn = conectar()
    try:
        anterior = conn.execute("SELECT * FROM folhas WHERE id = ?", (folha_id_anterior,)).fetchone()
        if anterior is None:
            raise ErroReimpressao("Folha anterior não encontrada.")
        anterior = dict(anterior)
    finally:
        conn.close()

    snapshot_anterior = json.loads(anterior["snapshot_dados"])
    cabecalho = snapshot_anterior["cabecalho"]
    ano, mes = anterior["ano"], anterior["mes"]

    calendario_vigente = obter_calendario_vigente(ano, mes, contexto)
    if calendario_vigente is None:
        raise ErroReimpressao(f"Nenhum calendário publicado para {mes:02d}/{ano}.")

    modelo = resolver_modelo(cabecalho["categoria"])
    grade = montar_grade_mensal(ano, mes, calendario_vigente["id"])

    novo_snapshot = dict(snapshot_anterior)
    novo_snapshot["calendario_id"] = calendario_vigente["id"]
    novo_snapshot["calendario_versao"] = calendario_vigente["versao"]
    novo_snapshot["dias"] = [{"data": d.data.isoformat(), "tipo": d.tipo, "rotulo": d.rotulo} for d in grade]
    novo_snapshot["motivo_nova_versao"] = motivo

    conn = conectar()
    try:
        agora = agora_utc().isoformat()
        cur = conn.execute(
            """INSERT INTO folhas (pessoa_id, vinculo_id, ano, mes, versao_folha, calendario_id,
                                    modelo_ponto_id, anterior_id, snapshot_dados, criada_por, criada_em)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (anterior["pessoa_id"], anterior["vinculo_id"], ano, mes,
             anterior["versao_folha"] + 1, calendario_vigente["id"], modelo.id,
             folha_id_anterior, serializar_snapshot(novo_snapshot), contexto.conta_id, agora),
        )
        nova_folha_id = cur.lastrowid
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

    for formato, gerador in (("pdf", gerar_pdf), ("docx", gerar_docx), ("xlsx", gerar_xlsx)):
        conteudo = gerador(cabecalho, grade, modelo)
        salvar_artefato(nova_folha_id, formato, conteudo)

    registrar_evento_emissao(nova_folha_id, "nova_versao", contexto.conta_id, motivo=motivo)
    return nova_folha_id
