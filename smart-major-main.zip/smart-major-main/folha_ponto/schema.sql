-- Banco SQLite independente da Folha de Ponto (folha_ponto.db).

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_version (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    versao INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS calendarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ano INTEGER NOT NULL,
    mes INTEGER NOT NULL,
    versao INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'publicado' CHECK (status IN ('publicado', 'substituido')),
    publicado_em TEXT NOT NULL,
    publicado_por INTEGER,
    motivo TEXT,
    anterior_id INTEGER REFERENCES calendarios(id),
    UNIQUE (ano, mes, versao)
);
CREATE INDEX IF NOT EXISTS idx_calendarios_ano_mes ON calendarios(ano, mes);

CREATE TABLE IF NOT EXISTS calendario_dias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    calendario_id INTEGER NOT NULL REFERENCES calendarios(id),
    data TEXT NOT NULL,
    tipo TEXT NOT NULL CHECK (tipo IN ('feriado', 'ponto_facultativo')),
    descricao TEXT NOT NULL,
    decreto TEXT
);
CREATE INDEX IF NOT EXISTS idx_calendario_dias_cal ON calendario_dias(calendario_id);

CREATE TABLE IF NOT EXISTS folhas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pessoa_id INTEGER NOT NULL,
    vinculo_id INTEGER NOT NULL,
    ano INTEGER NOT NULL,
    mes INTEGER NOT NULL,
    versao_folha INTEGER NOT NULL DEFAULT 1,
    calendario_id INTEGER NOT NULL REFERENCES calendarios(id),
    modelo_ponto_id TEXT NOT NULL,
    anterior_id INTEGER REFERENCES folhas(id),
    snapshot_dados TEXT NOT NULL,          -- JSON imutável
    criada_por INTEGER,
    criada_em TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_folhas_pessoa_vinculo ON folhas(pessoa_id, vinculo_id, ano, mes);

CREATE TABLE IF NOT EXISTS folha_artefatos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    folha_id INTEGER NOT NULL REFERENCES folhas(id),
    formato TEXT NOT NULL CHECK (formato IN ('pdf', 'docx', 'xlsx')),
    arquivo_protegido TEXT NOT NULL,       -- caminho opaco em dados_privados/arquivos
    sha256 TEXT NOT NULL,
    bytes INTEGER NOT NULL,
    criado_em TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_artefatos_folha ON folha_artefatos(folha_id);

CREATE TABLE IF NOT EXISTS eventos_emissao (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    folha_id INTEGER NOT NULL REFERENCES folhas(id),
    acao TEXT NOT NULL CHECK (acao IN ('emissao', 'reimpressao', 'nova_versao')),
    autor INTEGER,
    data TEXT NOT NULL,
    motivo TEXT,
    formato TEXT
);
CREATE INDEX IF NOT EXISTS idx_eventos_folha ON eventos_emissao(folha_id);

CREATE TABLE IF NOT EXISTS solicitacoes_reimpressao (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    folha_id INTEGER NOT NULL REFERENCES folhas(id),
    motivo TEXT NOT NULL,
    solicitante INTEGER,
    situacao TEXT NOT NULL DEFAULT 'pendente' CHECK (situacao IN ('pendente', 'atendida', 'recusada')),
    criado_em TEXT NOT NULL
);

INSERT OR IGNORE INTO schema_version (id, versao) VALUES (1, 1);
