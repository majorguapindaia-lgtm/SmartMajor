"""Persistência de artefatos (PDF/DOCX/XLSX) com nomes opacos, SHA-256 e proteção
fora do diretório servido pelo Streamlit."""
import hashlib
import json
import uuid

from administracao.contexto import ContextoAutorizacao, exigir
from folha_ponto.database import conectar
from common.paths import caminho_arquivos
from common.tempo import agora_utc

PASTA_ARTEFATOS = caminho_arquivos() / "folha_ponto"
PASTA_ARTEFATOS.mkdir(parents=True, exist_ok=True)


def salvar_artefato(folha_id: int, formato: str, conteudo: bytes) -> dict:
    nome_opaco = f"{uuid.uuid4().hex}.{formato}"
    caminho = PASTA_ARTEFATOS / nome_opaco
    caminho.write_bytes(conteudo)
    sha256 = hashlib.sha256(conteudo).hexdigest()

    conn = conectar()
    try:
        conn.execute(
            """INSERT INTO folha_artefatos (folha_id, formato, arquivo_protegido, sha256, bytes, criado_em)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (folha_id, formato, str(caminho), sha256, len(conteudo), agora_utc().isoformat()),
        )
        conn.commit()
    finally:
        conn.close()
    return {"formato": formato, "caminho": str(caminho), "sha256": sha256, "bytes": len(conteudo)}


def obter_artefatos_da_folha(folha_id: int, contexto: ContextoAutorizacao) -> list[dict]:
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM folha_artefatos WHERE folha_id = ?", (folha_id,)
        ).fetchall()]
    finally:
        conn.close()


def ler_bytes_artefato(caminho: str) -> bytes:
    from pathlib import Path
    return Path(caminho).read_bytes()


def registrar_evento_emissao(folha_id: int, acao: str, autor: int | None,
                              motivo: str | None = None, formato: str | None = None) -> None:
    conn = conectar()
    try:
        conn.execute(
            "INSERT INTO eventos_emissao (folha_id, acao, autor, data, motivo, formato) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (folha_id, acao, autor, agora_utc().isoformat(), motivo, formato),
        )
        conn.commit()
    finally:
        conn.close()


def serializar_snapshot(dados: dict) -> str:
    return json.dumps(dados, ensure_ascii=False, sort_keys=True, default=str)
