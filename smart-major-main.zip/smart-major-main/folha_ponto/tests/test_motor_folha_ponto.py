"""Cobre os cenários da seção 12.3 do Prompt Mestre (calendário/folha).

Desde a correção de segurança, cada ação exige permissão granular verificada no
próprio serviço — os testes usam contextos com permissões específicas concedidas
por um Master real, não apenas um `autor_id` solto."""
import hashlib

import pytest

from administracao.contexto import ContextoAutorizacao
from administracao.database import inicializar as inicializar_admin
from administracao.permissoes import conceder_permissao, ErroPermissao
from administracao.registro_modulos import semear_catalogo_inicial
from autenticacao.database import inicializar as inicializar_core
from autenticacao.bootstrap_master import bootstrap_primeiro_master
from autenticacao.recuperacao import criar_conta, gerar_token_reset, consumir_token_e_redefinir
from autenticacao.usuarios_cadastro import DadosPessoa, DadosVinculo, cadastrar_pessoa

from folha_ponto.database import inicializar
from folha_ponto.calendario import montar_grade_mensal, obter_calendario_vigente, dia_e_assinavel
from folha_ponto.versoes_calendario import publicar_calendario, listar_versoes, folhas_afetadas_por_versao_anterior
from folha_ponto.modelos import resolver_modelo
from folha_ponto.emissao import emitir_folha, ErroEmissao
from folha_ponto.reimpressao import reimprimir_original, gerar_nova_versao
from folha_ponto.historico import listar_folhas_pessoa_vinculo, cadeia_de_versoes
from folha_ponto.services import obter_artefatos_da_folha


@pytest.fixture
def ctx() -> ContextoAutorizacao:
    """Contexto Master, com TODAS as permissões de folha_ponto (Master tem acesso
    operacional irrestrito por definição em administracao.permissoes)."""
    inicializar()
    inicializar_core()
    inicializar_admin()
    semear_catalogo_inicial()
    pessoa_id = bootstrap_primeiro_master("Master FP", "master.fp.teste", "SenhaMasterForte1")
    from autenticacao.database import conectar as conectar_core
    conn = conectar_core()
    conta_id = conn.execute("SELECT id FROM contas WHERE pessoa_id = ?", (pessoa_id,)).fetchone()["id"]
    conn.close()
    return ContextoAutorizacao(conta_id=conta_id)


def _conta_comum_com_permissoes(login: str, master_ctx: ContextoAutorizacao, *permissoes: str) -> ContextoAutorizacao:
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome=f"Pessoa {login}"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    conta_id = criar_conta(pessoa_id, login, autor_id=None)
    token = gerar_token_reset(conta_id)
    consumir_token_e_redefinir(token, "SenhaComum123")
    for permissao in permissoes:
        conceder_permissao(conta_id, permissao, concedida_por=master_ctx.conta_id)
    return ContextoAutorizacao(conta_id=conta_id)


def test_meses_28_29_30_31_dias_e_bissexto(ctx):
    publicar_calendario(2024, 2, [], ctx)   # bissexto
    publicar_calendario(2025, 2, [], ctx)   # 28 dias
    publicar_calendario(2026, 4, [], ctx)   # 30 dias
    publicar_calendario(2026, 1, [], ctx)   # 31 dias

    cal_bissexto = obter_calendario_vigente(2024, 2, ctx)
    cal_comum = obter_calendario_vigente(2025, 2, ctx)
    cal_30 = obter_calendario_vigente(2026, 4, ctx)
    cal_31 = obter_calendario_vigente(2026, 1, ctx)

    assert len(montar_grade_mensal(2024, 2, cal_bissexto["id"])) == 29
    assert len(montar_grade_mensal(2025, 2, cal_comum["id"])) == 28
    assert len(montar_grade_mensal(2026, 4, cal_30["id"])) == 30
    assert len(montar_grade_mensal(2026, 1, cal_31["id"])) == 31


def test_fim_de_semana_sempre_bloqueado(ctx):
    publicar_calendario(2026, 11, [], ctx)
    cal = obter_calendario_vigente(2026, 11, ctx)
    grade = montar_grade_mensal(2026, 11, cal["id"])
    sabados_domingos = [d for d in grade if d.data.weekday() in (5, 6)]
    assert sabados_domingos
    for dia in sabados_domingos:
        assert not dia_e_assinavel(dia)
        assert dia.rotulo in ("SÁBADO", "DOMINGO")


def test_feriado_e_ponto_facultativo_bloqueados_globalmente(ctx):
    publicar_calendario(2026, 11, [
        {"data": "2026-11-02", "tipo": "feriado", "descricao": "Finados"},
        {"data": "2026-11-20", "tipo": "ponto_facultativo", "descricao": "Consciência Negra - facultativo"},
    ], ctx)
    cal = obter_calendario_vigente(2026, 11, ctx)
    grade = montar_grade_mensal(2026, 11, cal["id"])
    dia_feriado = next(d for d in grade if d.data.isoformat() == "2026-11-02")
    dia_facultativo = next(d for d in grade if d.data.isoformat() == "2026-11-20")
    assert not dia_e_assinavel(dia_feriado) and dia_feriado.rotulo == "FERIADO"
    assert not dia_e_assinavel(dia_facultativo) and dia_facultativo.rotulo == "PONTO FACULTATIVO"


def test_precedencia_fim_de_semana_sobre_feriado_preserva_metadado(ctx):
    publicar_calendario(2026, 11, [
        {"data": "2026-11-01", "tipo": "feriado", "descricao": "Feriado coincidente com domingo"},
    ], ctx)
    cal = obter_calendario_vigente(2026, 11, ctx)
    grade = montar_grade_mensal(2026, 11, cal["id"])
    dia = next(d for d in grade if d.data.isoformat() == "2026-11-01")
    assert dia.rotulo == "DOMINGO"
    assert dia.descricao_feriado == "Feriado coincidente com domingo"


def test_uma_configuracao_mensal_atende_todos_os_vinculos_e_versionamento_v1_v2(ctx):
    publicar_calendario(2026, 11, [], ctx)
    cal_v1 = obter_calendario_vigente(2026, 11, ctx)
    assert cal_v1["versao"] == 1

    emitir_folha(1, 10, "Pessoa A", "administrativo", 6, 2026, 11, ctx)
    emitir_folha(2, 20, "Pessoa B", "professor", None, 2026, 11, ctx)

    publicar_calendario(2026, 11, [
        {"data": "2026-11-15", "tipo": "feriado", "descricao": "Nova data incluída"},
    ], ctx, motivo="Ato oficial corrigiu data")
    cal_v2 = obter_calendario_vigente(2026, 11, ctx)
    assert cal_v2["versao"] == 2

    versoes = listar_versoes(2026, 11, ctx)
    assert len(versoes) == 2
    assert versoes[0]["status"] == "substituido" and versoes[1]["status"] == "publicado"

    afetadas = folhas_afetadas_por_versao_anterior(2026, 11, cal_v1["id"], ctx)
    assert len(afetadas) == 2

    emitir_folha(3, 30, "Pessoa C", "administrativo", 8, 2026, 11, ctx)
    folha_c = listar_folhas_pessoa_vinculo(3, 30, ctx)[0]
    assert folha_c["calendario_id"] == cal_v2["id"]


def test_categoria_determina_modelo_6h_8h_professor_diretor_federal():
    assert resolver_modelo("administrativo", 6).id == "administrativo_6h"
    assert resolver_modelo("administrativo", 8).id == "administrativo_8h"
    assert resolver_modelo("professor").id == "professores"
    assert resolver_modelo("diretor").id == "diretor"
    assert resolver_modelo("federal").id == "federais"


def test_primeira_emissao_gera_pdf_docx_xlsx_e_folha_duplicada_e_bloqueada(ctx):
    publicar_calendario(2026, 11, [], ctx)
    folha_id = emitir_folha(1, 10, "Pessoa Teste", "administrativo", 6, 2026, 11, ctx)
    artefatos = obter_artefatos_da_folha(folha_id, ctx)
    formatos = {a["formato"] for a in artefatos}
    assert formatos == {"pdf", "docx", "xlsx"}
    for artefato in artefatos:
        assert artefato["bytes"] > 0

    with pytest.raises(ErroEmissao):
        emitir_folha(1, 10, "Pessoa Teste", "administrativo", 6, 2026, 11, ctx)


def test_reimpressao_original_devolve_mesmos_bytes_sha256(ctx):
    publicar_calendario(2026, 11, [], ctx)
    folha_id = emitir_folha(1, 10, "Pessoa Reimpressao", "administrativo", 6, 2026, 11, ctx)
    artefatos = {a["formato"]: a for a in obter_artefatos_da_folha(folha_id, ctx)}

    conteudo_reimpresso = reimprimir_original(folha_id, "pdf", ctx, motivo="Erro manuscrito")
    assert hashlib.sha256(conteudo_reimpresso).hexdigest() == artefatos["pdf"]["sha256"]


def test_nova_versao_preserva_anterior_e_nao_reutiliza_identificador(ctx):
    publicar_calendario(2026, 11, [], ctx)
    folha_v1 = emitir_folha(1, 10, "Pessoa Versao", "administrativo", 6, 2026, 11, ctx)
    folha_v2 = gerar_nova_versao(folha_v1, ctx, motivo="Correção de data após decreto")

    assert folha_v2 != folha_v1
    cadeia = cadeia_de_versoes(folha_v2, ctx)
    assert [f["id"] for f in cadeia] == [folha_v1, folha_v2]
    assert [f["versao_folha"] for f in cadeia] == [1, 2]

    artefatos_v1 = obter_artefatos_da_folha(folha_v1, ctx)
    artefatos_v2 = obter_artefatos_da_folha(folha_v2, ctx)
    assert len(artefatos_v1) == 3 and len(artefatos_v2) == 3


def test_pessoa_com_dois_vinculos_produz_duas_folhas_no_mesmo_mes(ctx):
    publicar_calendario(2026, 11, [], ctx)
    folha_vinculo_1 = emitir_folha(1, 10, "Pessoa Dupla", "administrativo", 6, 2026, 11, ctx)
    folha_vinculo_2 = emitir_folha(1, 11, "Pessoa Dupla", "voluntario", None, 2026, 11, ctx)
    assert folha_vinculo_1 != folha_vinculo_2
    assert len(listar_folhas_pessoa_vinculo(1, 10, ctx)) == 1
    assert len(listar_folhas_pessoa_vinculo(1, 11, ctx)) == 1


# --- Testes de permissões granulares separadas (correção da 2ª etapa) ---

def test_permissao_emitir_nao_concede_reimprimir_nem_nova_versao(ctx):
    publicar_calendario(2026, 11, [], ctx)
    folha_id = emitir_folha(1, 10, "Pessoa Perm", "administrativo", 6, 2026, 11, ctx)

    conta_so_emite = _conta_comum_com_permissoes("so.emite", ctx, "folha_ponto.emitir", "folha_ponto.consultar")
    with pytest.raises(ErroPermissao):
        reimprimir_original(folha_id, "pdf", conta_so_emite)
    with pytest.raises(ErroPermissao):
        gerar_nova_versao(folha_id, conta_so_emite, motivo="Tentativa sem permissão")


def test_permissao_reimprimir_nao_concede_emitir_nem_nova_versao(ctx):
    publicar_calendario(2026, 11, [], ctx)
    emitir_folha(1, 10, "Pessoa Perm2", "administrativo", 6, 2026, 11, ctx)

    conta_so_reimprime = _conta_comum_com_permissoes("so.reimprime", ctx, "folha_ponto.reimprimir",
                                                       "folha_ponto.consultar")
    with pytest.raises(ErroPermissao):
        emitir_folha(9, 90, "Outra Pessoa", "administrativo", 6, 2026, 11, conta_so_reimprime)


def test_permissao_alterar_calendario_e_independente_das_demais(ctx):
    conta_sem_calendario = _conta_comum_com_permissoes(
        "sem.calendario", ctx, "folha_ponto.emitir", "folha_ponto.consultar",
    )
    with pytest.raises(ErroPermissao):
        publicar_calendario(2027, 1, [], conta_sem_calendario)
