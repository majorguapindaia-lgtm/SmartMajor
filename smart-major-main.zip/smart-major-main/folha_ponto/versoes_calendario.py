"""Publicação de calendário mensal (versão global, válida para todos os vínculos) e
versionamento controlado: nunca sobrescreve a versão anterior.

Correção de segurança: publicar calendário exige `folha_ponto.alterar_calendario`
verificado dentro do próprio serviço, não apenas na tela."""
from administracao.contexto import ContextoAutorizacao, exigir
from folha_ponto.database import conectar
from folha_ponto.calendario import obter_calendario_vigente
from common.tempo import agora_utc


class ErroCalendario(Exception):
    pass


def publicar_calendario(
    ano: int, mes: int, dias_especiais: list[dict], contexto: ContextoAutorizacao,
    motivo: str | None = None,
) -> int:
    """dias_especiais: [{"data": "2026-11-15", "tipo": "feriado"|"ponto_facultativo",
    "descricao": str, "decreto": str|None}, ...]. Cria sempre uma NOVA versão."""
    exigir(contexto, "folha_ponto.alterar_calendario")
    anterior = obter_calendario_vigente(ano, mes, contexto)
    nova_versao = (anterior["versao"] + 1) if anterior else 1

    conn = conectar()
    try:
        agora = agora_utc().isoformat()
        cur = conn.execute(
            """INSERT INTO calendarios (ano, mes, versao, status, publicado_em, publicado_por,
                                         motivo, anterior_id)
               VALUES (?, ?, ?, 'publicado', ?, ?, ?, ?)""",
            (ano, mes, nova_versao, agora, contexto.conta_id, motivo, anterior["id"] if anterior else None),
        )
        novo_id = cur.lastrowid

        for dia in dias_especiais:
            conn.execute(
                "INSERT INTO calendario_dias (calendario_id, data, tipo, descricao, decreto) "
                "VALUES (?, ?, ?, ?, ?)",
                (novo_id, dia["data"], dia["tipo"], dia["descricao"], dia.get("decreto")),
            )

        if anterior:
            conn.execute("UPDATE calendarios SET status = 'substituido' WHERE id = ?", (anterior["id"],))

        conn.commit()
        return novo_id
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def listar_versoes(ano: int, mes: int, contexto: ContextoAutorizacao) -> list[dict]:
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM calendarios WHERE ano = ? AND mes = ? ORDER BY versao", (ano, mes)
        ).fetchall()]
    finally:
        conn.close()


def folhas_afetadas_por_versao_anterior(ano: int, mes: int, calendario_id_anterior: int,
                                         contexto: ContextoAutorizacao) -> list[dict]:
    """Lista folhas emitidas com uma versão de calendário que não é mais a vigente —
    para a secretaria decidir, manualmente, o que reemitir. Nunca reemite sozinho."""
    exigir(contexto, "folha_ponto.consultar")
    conn = conectar()
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM folhas WHERE ano = ? AND mes = ? AND calendario_id = ?",
            (ano, mes, calendario_id_anterior),
        ).fetchall()]
    finally:
        conn.close()
