import time
import re
import io
import keyboard
import pandas as pd
from pathlib import Path
from datetime import datetime
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

class SDEForaDoArError(Exception):
    """Exceção lançada quando o SDE está indisponível ou fora do ar."""
    pass

URL_LOGIN = "https://sde.seduc.ro.gov.br/login.php"
URL_TODAS_TURMAS = "https://sde.seduc.ro.gov.br/escola/turma/form_inclusao_turma.php"
URL_ESPELHO_BASE = "https://sde.seduc.ro.gov.br/escola/nota/form_imprimi_turma_aluno.php"
URL_BOLETIM_BASE = "https://sde.seduc.ro.gov.br/escola/nota/rel_boletim_refatoracao.php"

TURMAS_ALVO = [
    "REGULAR - 1EM - M - A", "REGULAR - 1EM - M - B", "REGULAR - 1EM - M - C", "REGULAR - 1EM - M - D", "REGULAR - 1EM - M - E",
    "REGULAR - 1EM - T - F", "REGULAR - 1EM - T - G", "REGULAR - 1EM - T - H", "REGULAR - 1EM - T - I", "REGULAR - 1EM - T - J",
    "REGULAR - 2EM - M - A", "REGULAR - 2EM - M - B", "REGULAR - 2EM - M - C", "REGULAR - 2EM - M - D", "REGULAR - 2EM - M - E",
    "REGULAR - 2EM - T - F", "REGULAR - 2EM - T - G", "REGULAR - 2EM - T - H", "REGULAR - 2EM - T - I", "REGULAR - 2EM - T - J",
    "REGULAR - 3EM - M - A", "REGULAR - 3EM - M - B", "REGULAR - 3EM - M - C", "REGULAR - 3EM - M - D", "REGULAR - 3EM - M - E", "REGULAR - 3EM - M - F",
    "REGULAR - 3EM - T - G", "REGULAR - 3EM - T - H", "REGULAR - 3EM - T - I", "REGULAR - 3EM - T - J", "REGULAR - 3EM - T - K", "REGULAR - 3EM - T - L"
]

def normalizar_texto(texto):
    if not texto:
        return ""
    return re.sub(r'\s+', ' ', str(texto)).strip().upper()

def carregar_mapa_todas_turmas(driver_inst):
    try:
        driver_inst.get(URL_TODAS_TURMAS)
        time.sleep(2)
        soup = BeautifulSoup(driver_inst.page_source, "html.parser")
        rows = soup.find_all("tr", class_="turma-row")
        mapa_turmas = {}
        for row in rows:
            id_cell = row.find("td", class_="id-cell")
            mod_cell = row.find("td", class_="modalidade-cell")
            ano_cell = row.find("td", class_="ano-cell")
            turno_cell = row.find("td", class_="turno-cell")
            sala_cell = row.find("td", class_="sala-cell")
            if id_cell and mod_cell and ano_cell and turno_cell and sala_cell:
                codigo = id_cell.text.strip()
                mod = normalizar_texto(mod_cell.text)
                ano_t = normalizar_texto(ano_cell.text)
                turno_t = normalizar_texto(turno_cell.text)
                sala_t = normalizar_texto(sala_cell.text)
                chave = f"{mod} - {ano_t} - {turno_t} - {sala_t}"
                mapa_turmas[chave] = codigo
        return mapa_turmas
    except Exception as e:
        raise SDEForaDoArError(f"Erro ao acessar listagem de turmas no SDE: {e}")

def extrair_notas_boletim_direto(driver_inst, url_boletim, bimestre_str, ignorar_trilha=False):
    """Navega até a URL do boletim do aluno mantendo a sessão ativa."""
    driver_inst.get(url_boletim)
    time.sleep(1.0)
    
    soup = BeautifulSoup(driver_inst.page_source, "html.parser")
    tabela = soup.find("table", id="notas")
    if not tabela:
        return None

    col_index = None
    thead = tabela.find("thead")
    
    meta_bim = "1ºB"
    if "2" in bimestre_str: meta_bim = "2ºB"
    elif "3" in bimestre_str: meta_bim = "3ºB"
    elif "4" in bimestre_str: meta_bim = "4ºB"

    if thead:
        headers = thead.find_all("th")
        for idx, th in enumerate(headers):
            texto_th = th.text.strip().upper()
            if meta_bim in texto_th:
                col_index = idx
                break

    if col_index is None:
        col_map = {"1º Bimestre": 2, "2º Bimestre": 4, "3º Bimestre": 6, "4º Bimestre": 8}
        col_index = col_map.get(bimestre_str, 2)

    disciplinas_notas = []
    tbody = tabela.find("tbody") if tabela.find("tbody") else tabela

    # Palavras-chave associadas às Trilhas/Eletivas do Novo Ensino Médio
    KW_TRILHAS = ["TRILHA", "ELETIVA", "ITINERARIO", "APROFUNDAMENTO"]

    for tr in tbody.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) > col_index:
            materia = normalizar_texto(tds[0].text)
            
            # Descarta componentes opcionais
            if "OPCIONAL" in materia:
                continue

            # Se o marcador mandar ignorar trilha nesta turma/ano
            if ignorar_trilha and any(kw in materia for kw in KW_TRILHAS):
                continue

            val_raw = tds[col_index].text.strip().replace(",", ".")
            if val_raw in ["-", "", "S/N"]:
                disciplinas_notas.append({"materia": materia, "nota": None, "raw": "-"})
            else:
                try:
                    nota_num = float(val_raw)
                    disciplinas_notas.append({"materia": materia, "nota": nota_num, "raw": val_raw})
                except ValueError:
                    disciplinas_notas.append({"materia": materia, "nota": None, "raw": val_raw})

    return disciplinas_notas

def processar_boletins_da_turma(driver_inst, codigo_turma, bimestre_str, ignorar_trilha=False):
    url_turma = f"{URL_ESPELHO_BASE}?id_turma={codigo_turma}"
    driver_inst.get(url_turma)
    time.sleep(1.5)
    
    soup = BeautifulSoup(driver_inst.page_source, "html.parser")
    alunos_com_notas = []
    
    linhas = soup.find_all("tr")
    for linha in linhas:
        colunas = linha.find_all("td")
        if len(colunas) >= 6:
            situacao = colunas[5].text.strip().upper()
            if "MATRICULADO" in situacao:
                id_aluno = colunas[1].text.strip()
                chamada = colunas[2].text.strip()
                nome_aluno = normalizar_texto(colunas[3].text)
                
                botao_boletim = colunas[0].find("a", href=True)
                if botao_boletim:
                    href = botao_boletim['href']
                    if not href.startswith("http"):
                        url_boletim = f"https://sde.seduc.ro.gov.br/escola/nota/{href}"
                    else:
                        url_boletim = href
                    
                    if "id_turma=" not in url_boletim:
                        url_boletim = f"https://sde.seduc.ro.gov.br/escola/nota/rel_boletim_refatoracao.php?id_turma={codigo_turma}&id_aluno={id_aluno}&chamada={chamada}"

                    notas = extrair_notas_boletim_direto(driver_inst, url_boletim, bimestre_str, ignorar_trilha)
                    
                    alunos_com_notas.append({
                        "id_aluno": id_aluno,
                        "chamada": chamada,
                        "nome": nome_aluno,
                        "notas": notas if notas else []
                    })
                    
                    driver_inst.get(url_turma)
                    time.sleep(0.5)

    return alunos_com_notas

def avaliar_e_ranquear_alunos(alunos_com_notas):
    desqualificados = []
    qualificados = []

    for aluno in alunos_com_notas:
        notas_objs = aluno.get("notas", [])
        
        if not notas_objs:
            desqualificados.append({
                **aluno,
                "menor_nota": 0.0,
                "qtd_10": 0,
                "media": 0.0,
                "observacoes": "Boletim indisponível.",
                "motivo": "Sem dados de boletim."
            })
            continue

        notas_lancadas = [m for m in notas_objs if m["nota"] is not None]
        sem_lancamento = [m["materia"] for m in notas_objs if m["nota"] is None]

        obs_pendencias = ""
        if sem_lancamento:
            obs_pendencias = f"Sem lançamento em: {', '.join(sem_lancamento)}."

        if not notas_lancadas:
            desqualificados.append({
                **aluno,
                "menor_nota": 0.0,
                "qtd_10": 0,
                "media": 0.0,
                "observacoes": obs_pendencias if obs_pendencias else "Nenhuma nota lançada.",
                "motivo": "Aluno sem qualquer nota lançada no bimestre."
            })
            continue

        valores_notas = [m["nota"] for m in notas_lancadas]
        menor_nota = min(valores_notas)

        if menor_nota < 6.0:
            disciplinas_baixas = [f"{m['materia']} ({m['nota']})" for m in notas_lancadas if m["nota"] < 6.0]
            motivo_elim = f"Eliminado: Possui nota < 6.0 em ({', '.join(disciplinas_baixas)})."
            desqualificados.append({
                **aluno,
                "menor_nota": menor_nota,
                "qtd_10": valores_notas.count(10.0),
                "media": round(sum(valores_notas) / len(valores_notas), 2),
                "observacoes": f"{obs_pendencias} {motivo_elim}".strip(),
                "motivo": motivo_elim
            })
        else:
            qtd_10 = valores_notas.count(10.0)
            media = sum(valores_notas) / len(valores_notas)
            notas_ordenadas = sorted(valores_notas)

            qualificados.append({
                **aluno,
                "menor_nota": menor_nota,
                "notas_ordenadas": notas_ordenadas,
                "qtd_10": qtd_10,
                "media": media,
                "total_lancadas": len(valores_notas),
                "observacoes": obs_pendencias if obs_pendencias else "Todas as notas válidas."
            })

    qualificados_ordenados = sorted(
        qualificados,
        key=lambda x: (x["notas_ordenadas"], x["qtd_10"], x["media"]),
        reverse=True
    )

    ranking = []
    for idx, al in enumerate(qualificados_ordenados, start=1):
        motivo = f"Classificado em {idx}º lugar (Menor nota: {al['menor_nota']:.1f} | Notas 10.0: {al['qtd_10']} | Média: {al['media']:.2f})."
        ranking.append({
            "posicao": idx,
            "nome": al["nome"],
            "id_aluno": al["id_aluno"],
            "menor_nota": al["menor_nota"],
            "qtd_10": al["qtd_10"],
            "media": round(al["media"], 2),
            "status": "Qualificado",
            "observacoes": al["observacoes"],
            "motivo": motivo
        })

    for al in desqualificados:
        ranking.append({
            "posicao": "N/A",
            "nome": al["nome"],
            "id_aluno": al["id_aluno"],
            "menor_nota": al.get("menor_nota", 0.0),
            "qtd_10": al.get("qtd_10", 0),
            "media": al.get("media", 0.0),
            "status": "Desqualificado",
            "observacoes": al["observacoes"],
            "motivo": al["motivo"]
        })

    return ranking

def gerador_excel_bytes(resultados_por_turma, rotulo_bimestre):
    output = io.BytesIO()
    writer = pd.ExcelWriter(output, engine="openpyxl")
    
    registros = []
    for turma, alunos in resultados_por_turma.items():
        for al in alunos:
            registros.append({
                "Turma": turma,
                "Posição": al["posicao"],
                "Nome do Estudante": al["nome"],
                "ID Estadual": al["id_aluno"],
                "Menor Nota": al["menor_nota"] if al["status"] == "Qualificado" else "-",
                "Qtd Notas 10.0": al["qtd_10"] if al["status"] == "Qualificado" else "-",
                "Média Geral": al["media"] if al["status"] == "Qualificado" else "-",
                "Status": al["status"],
                "Observações (Disciplinas Sem Nota)": al["observacoes"],
                "Parecer / Motivo da Posição": al["motivo"]
            })

    df = pd.DataFrame(registros)
    df.to_excel(writer, sheet_name="Aluno Nota 10", index=False)
    
    wb = writer.book
    ws = writer.sheets["Aluno Nota 10"]
    
    header_fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    align_center = Alignment(horizontal="center", vertical="center")
    
    for col_idx, col_name in enumerate(df.columns, 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = align_center
        
        max_len = max(df[col_name].astype(str).map(len).max(), len(col_name)) + 3
        col_letter = get_column_letter(col_idx)
        ws.column_dimensions[col_letter].width = min(max_len, 50)

    writer.close()
    output.seek(0)
    return output.getvalue()

def gerador_pdf_bytes(resultados_por_turma, rotulo_bimestre):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=landscape(letter),
        rightMargin=15, leftMargin=15, topMargin=20, bottomMargin=20
    )
    elements = []
    styles = getSampleStyleSheet()

    titulo_style = ParagraphStyle('TituloPDF', parent=styles['Heading1'], fontSize=14, textColor=colors.HexColor("#1F497D"), alignment=1, spaceAfter=8)
    subtitulo_style = ParagraphStyle('SubTituloPDF', parent=styles['Heading2'], fontSize=11, textColor=colors.HexColor("#333333"), spaceBefore=10, spaceAfter=6)
    cell_style = ParagraphStyle('CellText', parent=styles['Normal'], fontSize=7, leading=9)
    cell_bold = ParagraphStyle('CellBold', parent=styles['Normal'], fontSize=7, leading=9, fontName='Helvetica-Bold')
    cell_header = ParagraphStyle('CellHeader', parent=styles['Normal'], fontSize=8, leading=10, textColor=colors.whitesmoke, fontName='Helvetica-Bold')

    elements.append(Paragraph(f"SmartMajor - Relatório Prêmio Aluno Nota 10 ({rotulo_bimestre})", titulo_style))
    elements.append(Paragraph(f"Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}", styles['Normal']))
    elements.append(Spacer(1, 10))

    for turma_nome, alunos in resultados_por_turma.items():
        elements.append(Paragraph(f"Turma: {turma_nome}", subtitulo_style))
        
        data = [[
            Paragraph("Posição", cell_header),
            Paragraph("Nome do Estudante", cell_header),
            Paragraph("ID Estadual", cell_header),
            Paragraph("Menor Nota", cell_header),
            Paragraph("Notas 10.0", cell_header),
            Paragraph("Média", cell_header),
            Paragraph("Observações", cell_header),
            Paragraph("Parecer / Motivo da Posição", cell_header)
        ]]

        table_styles = [
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F497D")),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ]

        for r_idx, al in enumerate(alunos, start=1):
            pos_str = str(al["posicao"])
            is_top3 = al["status"] == "Qualificado" and isinstance(al["posicao"], int) and al["posicao"] <= 3

            bg_color = colors.white
            if is_top3:
                if al["posicao"] == 1: bg_color = colors.HexColor("#FFF2CC")
                elif al["posicao"] == 2: bg_color = colors.HexColor("#E6E6E6")
                elif al["posicao"] == 3: bg_color = colors.HexColor("#F8CECC")
            elif al["status"] == "Desqualificado":
                bg_color = colors.HexColor("#F2F2F2")

            row_cells = [
                Paragraph(pos_str, cell_bold if is_top3 else cell_style),
                Paragraph(al["nome"], cell_bold if is_top3 else cell_style),
                Paragraph(str(al["id_aluno"]), cell_style),
                Paragraph(str(al["menor_nota"]) if al["status"] == "Qualificado" else "-", cell_style),
                Paragraph(str(al["qtd_10"]) if al["status"] == "Qualificado" else "-", cell_style),
                Paragraph(str(al["media"]) if al["status"] == "Qualificado" else "-", cell_style),
                Paragraph(al["observacoes"], cell_style),
                Paragraph(al["motivo"], cell_style)
            ]
            
            data.append(row_cells)
            if bg_color != colors.white:
                table_styles.append(('BACKGROUND', (0, r_idx), (-1, r_idx), bg_color))

        t_turma = Table(data, colWidths=[40, 150, 55, 50, 50, 40, 160, 180], hAlign='LEFT', repeatRows=1)
        t_turma.setStyle(TableStyle(table_styles))
        elements.append(t_turma)
        elements.append(Spacer(1, 10))

    doc.build(elements)
    buffer.seek(0)
    return buffer

def executar_aluno_nota_10(usuario_sde, senha_sde, opcao_turma_str="TODAS AS TURMAS", opcao_bimestre_str="1º Bimestre", ignorar_trilha_2ano=False, ignorar_trilha_3ano=False, status_callback=None, **kwargs):
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 30)

    resultados_por_turma = {}

    try:
        if status_callback:
            status_callback("Realizando login no SDE...", 0.02, 0)
        driver.get(URL_LOGIN)

        try:
            campo_cpf = wait.until(EC.presence_of_element_located((By.ID, "cpf")))
            campo_cpf.clear()
            campo_cpf.send_keys(usuario_sde)

            campo_senha = driver.find_element(By.XPATH, "//input[@type='password']")
            campo_senha.clear()
            campo_senha.send_keys(senha_sde)
            campo_senha.send_keys(Keys.RETURN)

            time.sleep(3)
        except Exception as e:
            raise SDEForaDoArError(f"Falha na autenticação SDE: {e}")

        if status_callback:
            status_callback("Carregando mapa de turmas da escola...", 0.05, 0)
        mapa_turmas = carregar_mapa_todas_turmas(driver)

        if opcao_turma_str == "TODAS AS TURMAS":
            turmas_alvo_proc = TURMAS_ALVO
        elif opcao_turma_str.startswith("1ºs Anos"):
            turmas_alvo_proc = [t for t in TURMAS_ALVO if "1EM" in t]
        elif opcao_turma_str.startswith("2ºs Anos"):
            turmas_alvo_proc = [t for t in TURMAS_ALVO if "2EM" in t]
        elif opcao_turma_str.startswith("3ºs Anos"):
            turmas_alvo_proc = [t for t in TURMAS_ALVO if "3EM" in t]
        else:
            turmas_alvo_proc = [opcao_turma_str]

        total_turmas = len(turmas_alvo_proc)
        inicio_exec = time.time()

        for t_idx, turma_nome in enumerate(turmas_alvo_proc, start=1):
            if keyboard.is_pressed("esc"):
                break

            cod_turma = mapa_turmas.get(turma_nome)
            if not cod_turma:
                continue

            # Verifica dinamicamente se deve ignorar as trilhas para esta turma
            ignorar_trilha_turma = False
            if "2EM" in turma_nome and ignorar_trilha_2ano:
                ignorar_trilha_turma = True
            elif "3EM" in turma_nome and ignorar_trilha_3ano:
                ignorar_trilha_turma = True

            progresso_pct = 0.05 + (t_idx / total_turmas) * 0.85
            tempo_decorrido = time.time() - inicio_exec
            tempo_medio = tempo_decorrido / max(t_idx, 1)
            tempo_restante_seg = int(tempo_medio * (total_turmas - t_idx))

            if status_callback:
                status_callback(
                    f"Processando Turma [{t_idx}/{total_turmas}]: {turma_nome}",
                    progresso_pct, tempo_restante_seg
                )

            alunos_com_notas = processar_boletins_da_turma(driver, cod_turma, opcao_bimestre_str, ignorar_trilha_turma)
            ranking_turma = avaliar_e_ranquear_alunos(alunos_com_notas)
            resultados_por_turma[turma_nome] = ranking_turma

        if status_callback:
            status_callback("Gerando relatórios em Excel e PDF...", 0.95, 2)

        excel_bytes = gerador_excel_bytes(resultados_por_turma, opcao_bimestre_str)
        pdf_bytes = gerador_pdf_bytes(resultados_por_turma, opcao_bimestre_str)

        nome_base = f"Aluno_Nota_10_{opcao_bimestre_str.replace(' ', '_')}"
        
        return {
            "excel_bytes": excel_bytes,
            "pdf_bytes": pdf_bytes,
            "nome_arquivo_excel": f"{nome_base}.xlsx",
            "nome_arquivo_pdf": f"{nome_base}.pdf",
            "resultados_por_turma": resultados_por_turma
        }

    finally:
        driver.quit()