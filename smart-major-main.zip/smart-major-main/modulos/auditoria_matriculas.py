import time
import re
import io
from datetime import datetime
import pandas as pd
from pathlib import Path
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

# Módulos para geração de PDF via ReportLab
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

# --- EXCEÇÃO CUSTOMIZADA PARA CAPTURA NO APP.PY ---
class SDEForaDoArError(Exception):
    """Exceção lançada quando o SDE está indisponível ou fora do ar."""
    pass

URL_LOGIN = "https://sde.seduc.ro.gov.br/login.php"
URL_TODAS_TURMAS = "https://sde.seduc.ro.gov.br/escola/turma/form_inclusao_turma.php"
URL_ESPELHO_BASE = "https://sde.seduc.ro.gov.br/escola/turmamanutencao/form_imprimi_turma_aluno.php"
URL_PESQUISA_ALUNO_BASE = "https://sde.seduc.ro.gov.br/escola/aluno/form_pesquisa_aluno_turma.php"

TURMAS_REGULARES = [
    "REGULAR - 1EM - M - A", "REGULAR - 1EM - M - B", "REGULAR - 1EM - M - C", "REGULAR - 1EM - M - D", "REGULAR - 1EM - M - E",
    "REGULAR - 1EM - T - F", "REGULAR - 1EM - T - G", "REGULAR - 1EM - T - H", "REGULAR - 1EM - T - I", "REGULAR - 1EM - T - J",
    "REGULAR - 2EM - M - A", "REGULAR - 2EM - M - B", "REGULAR - 2EM - M - C", "REGULAR - 2EM - M - D", "REGULAR - 2EM - M - E",
    "REGULAR - 2EM - T - F", "REGULAR - 2EM - T - G", "REGULAR - 2EM - T - H", "REGULAR - 2EM - T - I", "REGULAR - 2EM - T - J",
    "REGULAR - 3EM - M - A", "REGULAR - 3EM - M - B", "REGULAR - 3EM - M - C", "REGULAR - 3EM - M - D", "REGULAR - 3EM - M - E", "REGULAR - 3EM - M - F",
    "REGULAR - 3EM - T - G", "REGULAR - 3EM - T - H", "REGULAR - 3EM - T - I", "REGULAR - 3EM - T - J", "REGULAR - 3EM - T - K", "REGULAR - 3EM - T - L"
]

def normalizar_texto(texto):
    if not texto:
        return ""
    return re.sub(r'\s+', ' ', str(texto)).strip().upper()

def carregar_mapa_todas_turmas(driver_inst):
    try:
        driver_inst.get(URL_TODAS_TURMAS)
        time.sleep(2)
        soup = BeautifulSoup(driver_inst.page_source, "html.parser")
        rows = soup.find_all("tr", class_="turma-row")
        mapa_turmas = {}
        for row in rows:
            id_cell = row.find("td", class_="id-cell")
            mod_cell = row.find("td", class_="modalidade-cell")
            ano_cell = row.find("td", class_="ano-cell")
            turno_cell = row.find("td", class_="turno-cell")
            sala_cell = row.find("td", class_="sala-cell")
            if id_cell and mod_cell and ano_cell and turno_cell and sala_cell:
                codigo = id_cell.text.strip()
                mod = normalizar_texto(mod_cell.text)
                ano_t = normalizar_texto(ano_cell.text)
                turno_t = normalizar_texto(turno_cell.text)
                sala_t = normalizar_texto(sala_cell.text)
                chave = f"{mod} - {ano_t} - {turno_t} - {sala_t}"
                mapa_turmas[chave] = codigo
        return mapa_turmas
    except Exception as e:
        raise SDEForaDoArError(f"Erro ao acessar listagem de turmas no SDE: {e}")

def extrair_alunos_do_espelho(driver_inst):
    soup = BeautifulSoup(driver_inst.page_source, "html.parser")
    alunos = []
    for row in soup.find_all("tr"):
        texto_tr = str(row)
        match_id = re.search(r'Estadual</b>:\s*(?:&nbsp;)?\s*(\d+)', texto_tr, re.IGNORECASE)
        tds = row.find_all("td")
        if match_id and len(tds) >= 2:
            id_estadual = match_id.group(1).strip()
            nome_aluno = tds[2].text.strip().upper() if len(tds) > 2 else tds[1].text.strip().upper()
            nome_aluno = normalizar_texto(nome_aluno)
            if nome_aluno and "NOME DO ESTUDANTE" not in nome_aluno:
                alunos.append({"id_estadual": id_estadual, "nome": nome_aluno})
    return alunos

def analisar_historico_matriculas(html_conteudo):
    soup = BeautifulSoup(html_conteudo, "html.parser")
    tabela = soup.find("table", id="studentTable")
    dados_matriculas = {
        "regular_atual": None, "regular_situacao": None, "regular_anterior": [],
        "eletiva_status": "NÃO MATRICULADO", "eletiva_turma": "-",
        "trilha_status": "NÃO MATRICULADO", "trilha_turma": "-",
        "espanhol_status": "NÃO MATRICULADO", "espanhol_turma": "-"
    }

    if not tabela or not tabela.find("tbody"):
        return dados_matriculas

    for tr in tabela.find("tbody").find_all("tr", recursive=False):
        tds = tr.find_all("td", recursive=False)
        if len(tds) >= 8:
            nome_turma = normalizar_texto(tds[5].text)
            situacao = normalizar_texto(tds[7].text)

            is_regular = ("REGULAR" in nome_turma) and not any(
                kw in nome_turma for kw in ["ELETIVAS", "TRILHAS", "LINGUA ESPANHOLA", "ESPANHOL"]
            )
            if is_regular:
                if "MATRICULADO" in situacao or "TRANSFERIDO" in situacao:
                    dados_matriculas["regular_atual"] = nome_turma
                    dados_matriculas["regular_situacao"] = situacao
                elif "REMANEJADO" in situacao:
                    dados_matriculas["regular_anterior"].append(f"{nome_turma} (REMANEJADO)")
            elif "ELETIVAS" in nome_turma:
                if "MATRICULADO" in situacao:
                    dados_matriculas["eletiva_status"] = "MATRICULADO"
                    dados_matriculas["eletiva_turma"] = nome_turma
                elif "REMANEJADO" in situacao and dados_matriculas["eletiva_status"] != "MATRICULADO":
                    dados_matriculas["eletiva_status"] = "REMANEJADO TURMA"
                    dados_matriculas["eletiva_turma"] = f"{nome_turma} (REMANEJADO)"
            elif "TRILHAS" in nome_turma:
                if "MATRICULADO" in situacao:
                    dados_matriculas["trilha_status"] = "MATRICULADO"
                    dados_matriculas["trilha_turma"] = nome_turma
                elif "REMANEJADO" in situacao and dados_matriculas["trilha_status"] != "MATRICULADO":
                    dados_matriculas["trilha_status"] = "REMANEJADO TURMA"
                    dados_matriculas["trilha_turma"] = f"{nome_turma} (REMANEJADO)"
            elif "ESPANHOLA" in nome_turma or "ESPANHOL" in nome_turma:
                if "MATRICULADO" in situacao:
                    dados_matriculas["espanhol_status"] = "MATRICULADO"
                    dados_matriculas["espanhol_turma"] = nome_turma
                elif "REMANEJADO" in situacao and dados_matriculas["espanhol_status"] != "MATRICULADO":
                    dados_matriculas["espanhol_status"] = "REMANEJADO TURMA"
                    dados_matriculas["espanhol_turma"] = f"{nome_turma} (REMANEJADO)"

    return dados_matriculas

def gerador_pdf_bytes(df_relatorio, sufixo_nome):
    """
    Gera relatório de auditoria de matrículas em formato PDF em memória (BytesIO)
    com cores no diagnóstico e sem cortar colunas.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(letter),
        rightMargin=15,
        leftMargin=15,
        topMargin=20,
        bottomMargin=20
    )
    elements = []
    styles = getSampleStyleSheet()

    titulo_style = ParagraphStyle(
        'TituloPDF',
        parent=styles['Heading1'],
        fontSize=14,
        textColor=colors.HexColor("#1F497D"),
        alignment=1,
        spaceAfter=10
    )

    cell_style = ParagraphStyle(
        'CellText',
        parent=styles['Normal'],
        fontSize=6.5,
        leading=8
    )

    cell_header_style = ParagraphStyle(
        'CellHeader',
        parent=styles['Normal'],
        fontSize=7,
        leading=9,
        textColor=colors.whitesmoke,
        fontName='Helvetica-Bold'
    )

    cell_black_bold = ParagraphStyle(
        'CellBlackBold',
        parent=styles['Normal'],
        fontSize=6.5,
        leading=8,
        textColor=colors.HexColor("#333333"),
        fontName='Helvetica-Bold'
    )

    elements.append(Paragraph(f"SmartMajor - Auditoria de Matrículas ({sufixo_nome.replace('_', ' ')})", titulo_style))
    elements.append(Paragraph(f"Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}", styles['Normal']))
    elements.append(Spacer(1, 10))

    colunas_pdf = [
        "Turma de Origem", "ID Estadual", "Nome do Estudante",
        "Status Eletiva", "Status Trilha", "Status Espanhol",
        "Situação Geral", "Possível Causa / Detalhe"
    ]
    cols_presentes = [c for c in colunas_pdf if c in df_relatorio.columns]

    if not df_relatorio.empty:
        df_sub = df_relatorio[cols_presentes].copy()

        larguras_mapa = {
            "Turma de Origem": 90,
            "ID Estadual": 50,
            "Nome do Estudante": 135,
            "Status Eletiva": 65,
            "Status Trilha": 65,
            "Status Espanhol": 65,
            "Situação Geral": 95,
            "Possível Causa / Detalhe": 197
        }
        col_widths = [larguras_mapa.get(c, 70) for c in cols_presentes]

        header_row = [Paragraph(c, cell_header_style) for c in cols_presentes]
        data_tabela = [header_row]

        table_styles = [
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F497D")),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 3),
            ('RIGHTPADDING', (0, 0), (-1, -1), 3),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC"))
        ]

        idx_sit = cols_presentes.index("Situação Geral") if "Situação Geral" in cols_presentes else -1
        idx_causa = cols_presentes.index("Possível Causa / Detalhe") if "Possível Causa / Detalhe" in cols_presentes else -1

        for row_idx, row_data in enumerate(df_sub.values, start=1):
            row_cells = []
            val_status = str(row_data[idx_sit]) if idx_sit != -1 else ""

            # Define cor de fundo conforme o status
            if "Regularizado" in val_status:
                bg_color = colors.HexColor("#C6EFCE")  # Verde claro (#C6EFCE)
            elif "Transferido" in val_status:
                bg_color = colors.HexColor("#FFEB9C")  # Amarelo/Laranja claro (#FFEB9C)
            else:
                bg_color = colors.HexColor("#FFC7CE")  # Vermelho claro (#FFC7CE)

            for col_idx, val in enumerate(row_data):
                val_str = str(val or "")
                # Aplica o fundo colorido na coluna Situação Geral e na Possível Causa / Detalhe
                if col_idx in [idx_sit, idx_causa]:
                    row_cells.append(Paragraph(val_str, cell_black_bold))
                    table_styles.append(('BACKGROUND', (col_idx, row_idx), (col_idx, row_idx), bg_color))
                else:
                    row_cells.append(Paragraph(val_str, cell_style))

            data_tabela.append(row_cells)

        t_auditoria = Table(data_tabela, colWidths=col_widths, hAlign='LEFT', repeatRows=1)
        t_auditoria.setStyle(TableStyle(table_styles))
        elements.append(t_auditoria)
    else:
        elements.append(Paragraph("Nenhum dado encontrado para auditoria.", styles['Normal']))

    doc.build(elements)
    buffer.seek(0)
    return buffer

def executar_auditoria_matriculas(usuario_sde, senha_sde, opcao_turma_str, status_callback=None, **kwargs):
    if opcao_turma_str == "TODAS AS TURMAS":
        turmas_para_processar = TURMAS_REGULARES
    else:
        turmas_para_processar = [opcao_turma_str]

    options = webdriver.ChromeOptions()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 20)

    try:
        if status_callback:
            status_callback("Realizando login no SDE...", 0.05, 0)
        driver.get(URL_LOGIN)

        try:
            campo_cpf = wait.until(EC.presence_of_element_located((By.ID, "cpf")))
            campo_cpf.clear()
            campo_cpf.send_keys(usuario_sde)

            campo_senha = driver.find_element(By.XPATH, "//input[@type='password']")
            campo_senha.clear()
            campo_senha.send_keys(senha_sde)
            campo_senha.send_keys(Keys.RETURN)

            time.sleep(2)
        except Exception as e:
            raise SDEForaDoArError(f"Não foi possível autenticar no SDE: {e}")

        if status_callback:
            status_callback("Mapeando códigos das turmas...", 0.10, 0)
        mapa_codigos_turmas = carregar_mapa_todas_turmas(driver)

        relatorio_dados_global = []
        total_turmas = len(turmas_para_processar)
        inicio = time.time()

        for idx_t, turma_alvo in enumerate(turmas_para_processar, 1):
            tempo_decorrido = time.time() - inicio
            tempo_medio = tempo_decorrido / max(idx_t, 1)
            turmas_restantes = total_turmas - idx_t
            tempo_restante_seg = int(tempo_medio * turmas_restantes)
            progresso_pct = 0.10 + (idx_t / total_turmas) * 0.85

            if status_callback:
                status_callback(
                    f"Auditando turma [{idx_t}/{total_turmas}]: {turma_alvo}",
                    progresso_pct, tempo_restante_seg
                )

            codigo_turma = mapa_codigos_turmas.get(turma_alvo)
            if not codigo_turma:
                continue

            serie_aluno = 1 if "1EM" in turma_alvo else (2 if "2EM" in turma_alvo else 3)

            driver.get(f"{URL_ESPELHO_BASE}?turma={codigo_turma}")
            time.sleep(1.5)

            lista_alunos = extrair_alunos_do_espelho(driver)

            for idx_a, aluno in enumerate(lista_alunos, 1):
                id_aluno = aluno.get("id_estadual", "-")
                nome_aluno = aluno.get("nome", "-")

                try:
                    driver.get(f"{URL_PESQUISA_ALUNO_BASE}?q={id_aluno}")
                    wait.until(EC.presence_of_element_located((By.ID, "studentTable")))

                    info = analisar_historico_matriculas(driver.page_source)

                    turma_atual = info.get("regular_atual") or turma_alvo
                    turma_anterior = ", ".join(info.get("regular_anterior", [])) if info.get("regular_anterior") else "Nenhum"
                    situacao_reg = info.get("regular_situacao") or ""

                    if "TRANSFERIDO" in situacao_reg:
                        status_geral = "Transferido"
                        possivel_causa = "Estudante constando como Transferido no SDE"
                    else:
                        pendencias = []
                        causas = []
                        if serie_aluno == 1:
                            if info.get("eletiva_status") != "MATRICULADO":
                                pendencias.append("Falta Eletiva")
                                causas.append("Não matriculado em nenhuma disciplina Eletiva")
                        elif serie_aluno == 2:
                            if info.get("trilha_status") != "MATRICULADO":
                                pendencias.append("Falta Trilha")
                                causas.append("Não matriculado na Trilha de Aprofundamento")
                        elif serie_aluno == 3:
                            if info.get("trilha_status") != "MATRICULADO":
                                pendencias.append("Falta Trilha")
                                causas.append("Não matriculado na Trilha de Aprofundamento")
                            if info.get("espanhol_status") != "MATRICULADO":
                                pendencias.append("Falta Espanhol")
                                causas.append("Não matriculado em Língua Espanhola")

                        if not pendencias:
                            status_geral = "Regularizado"
                            possivel_causa = "Matrículas regulares e optativas em dia"
                        else:
                            status_geral = f"Pendente ({', '.join(pendencias)})"
                            possivel_causa = " | ".join(causas)

                    item_relatorio = {
                        "Turma de Origem": turma_alvo,
                        "ID Estadual": id_aluno,
                        "Nome do Estudante": nome_aluno,
                        "Turma Regular Atual": turma_atual,
                        "Turma Regular Anterior": turma_anterior,
                        "Status Eletiva": info.get("eletiva_status", "N/A") if serie_aluno == 1 else "N/A",
                        "Turma Eletiva": info.get("eletiva_turma", "N/A") if serie_aluno == 1 else "N/A",
                        "Status Trilha": info.get("trilha_status", "N/A") if serie_aluno != 1 else "N/A",
                        "Turma Trilha": info.get("trilha_turma", "N/A") if serie_aluno != 1 else "N/A",
                        "Status Espanhol": info.get("espanhol_status", "N/A"),
                        "Turma Espanhol": info.get("espanhol_turma", "N/A"),
                        "Situação Geral": status_geral,
                        "Possível Causa / Detalhe": possivel_causa,
                        "Link Ficha SDE": f"{URL_PESQUISA_ALUNO_BASE}?q={id_aluno}"
                    }
                    relatorio_dados_global.append(item_relatorio)

                except Exception:
                    relatorio_dados_global.append({
                        "Turma de Origem": turma_alvo,
                        "ID Estadual": id_aluno,
                        "Nome do Estudante": nome_aluno,
                        "Turma Regular Atual": turma_alvo,
                        "Turma Regular Anterior": "Erro na Consulta",
                        "Status Eletiva": "Erro na Consulta",
                        "Turma Eletiva": "-",
                        "Status Trilha": "Erro na Consulta",
                        "Turma Trilha": "-",
                        "Status Espanhol": "Erro na Consulta",
                        "Turma Espanhol": "-",
                        "Situação Geral": "Erro na Consulta",
                        "Possível Causa / Detalhe": "Falha de conexão ou tabela de estudante inacessível no SDE",
                        "Link Ficha SDE": f"{URL_PESQUISA_ALUNO_BASE}?q={id_aluno}"
                    })

        sufixo_nome = turmas_para_processar[0].replace(' ', '_') if len(turmas_para_processar) == 1 else "TODAS_AS_TURMAS"
        carimbo_tempo = datetime.now().strftime("%Y%m%d_%H%M%S")
        nome_arquivo_base = f"Auditoria_Completa_{sufixo_nome}_{carimbo_tempo}"

        df_relatorio = pd.DataFrame(relatorio_dados_global)

        # 1. GERAR EXCEL EM MEMÓRIA (BytesIO)
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            df_relatorio.to_excel(writer, sheet_name="Auditoria", index=False)
            wb = writer.book
            ws = wb["Auditoria"]
            ws.views.sheetView[0].showGridLines = True

            header_fill = PatternFill(start_color="1F497D", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True)

            red_fill = PatternFill(start_color="FFC7CE", fill_type="solid")
            red_font = Font(color="9C0006", bold=True)
            green_fill = PatternFill(start_color="C6EFCE", fill_type="solid")
            green_font = Font(color="006100", bold=True)
            orange_fill = PatternFill(start_color="FFEB9C", fill_type="solid")
            orange_font = Font(color="9C6500", bold=True)

            for cell in ws[1]:
                cell.fill, cell.font = header_fill, header_font
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Destacar visualmente no Excel a coluna "Situação Geral"
            if "Situação Geral" in df_relatorio.columns:
                col_idx_status = df_relatorio.columns.get_loc("Situação Geral") + 1
                for row in ws.iter_rows(min_row=2):
                    celula_status = row[col_idx_status - 1]
                    valor_status = str(celula_status.value or "")
                    if "Regularizado" in valor_status:
                        celula_status.fill, celula_status.font = green_fill, green_font
                    elif "Transferido" in valor_status:
                        celula_status.fill, celula_status.font = orange_fill, orange_font
                    else:
                        celula_status.fill, celula_status.font = red_fill, red_font

            for col in ws.columns:
                max_len = max(len(str(cell.value or '')) for cell in col)
                col_letter = get_column_letter(col[0].column)
                ws.column_dimensions[col_letter].width = max(max_len + 3, 15)

        excel_buffer.seek(0)

        # 2. GERAR PDF EM MEMÓRIA (BytesIO)
        pdf_buffer = gerador_pdf_bytes(df_relatorio, sufixo_nome)

        if status_callback:
            status_callback("Concluído!", 1.0, 0)

        return {
            "excel_bytes": excel_buffer.getvalue(),
            "pdf_bytes": pdf_buffer.getvalue(),
            "nome_arquivo_excel": f"{nome_arquivo_base}.xlsx",
            "nome_arquivo_pdf": f"{nome_arquivo_base}.pdf",
            "df_auditoria": df_relatorio
        }

    finally:
        try:
            driver.quit()
        except Exception:
            pass