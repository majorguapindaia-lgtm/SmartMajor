import time
import re
import io
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import pandas as pd
from pathlib import Path
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

# Módulos para geração do PDF via ReportLab
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

# --- EXCEÇÃO CUSTOMIZADA PARA CAPTURA NO APP.PY ---
class SDEForaDoArError(Exception):
    """Exceção lançada quando o SDE está indisponível ou fora do ar."""
    pass

# --- CONSTANTES DE URL DO SDE ---
URL_LOGIN = "https://sde.seduc.ro.gov.br/login.php"
URL_TODAS_TURMAS = "https://sde.seduc.ro.gov.br/escola/turma/form_inclusao_turma.php"
URL_ESPELHO_BASE = "https://sde.seduc.ro.gov.br/escola/turmamanutencao/form_imprimi_turma_aluno.php"
URL_SUPERVISAO_PROFESSOR = "https://sde.seduc.ro.gov.br/escola/supervisao/professor_turma.php"
URL_PESQUISA_PROF_FREQ = "https://sde.seduc.ro.gov.br/escola/calendario/form_pesquisa_professor_frequencia.php"
URL_RELATORIO_FREQ = "https://sde.seduc.ro.gov.br/relatorios/frequencia.php"
URL_RELATORIO_ALUNOS = "https://sde.seduc.ro.gov.br/escola/aluno/rel_alunos.php"
URL_BOLETIM_LISTA = "https://sde.seduc.ro.gov.br/escola/nota/form_imprimi_turma_aluno.php"
URL_PESQUISA_ALUNO_BASE = "https://sde.seduc.ro.gov.br/escola/aluno/form_pesquisa_aluno_turma.php"

# --- LISTA PADRÃO DE TURMAS REGULARES ---
TURMAS_REGULARES = [
    "REGULAR - 1EM - M - A", "REGULAR - 1EM - M - B", "REGULAR - 1EM - M - C", "REGULAR - 1EM - M - D", "REGULAR - 1EM - M - E",
    "REGULAR - 1EM - T - F", "REGULAR - 1EM - T - G", "REGULAR - 1EM - T - H", "REGULAR - 1EM - T - I", "REGULAR - 1EM - T - J",
    "REGULAR - 2EM - M - A", "REGULAR - 2EM - M - B", "REGULAR - 2EM - M - C", "REGULAR - 2EM - M - D", "REGULAR - 2EM - M - E",
    "REGULAR - 2EM - T - F", "REGULAR - 2EM - T - G", "REGULAR - 2EM - T - H", "REGULAR - 2EM - T - I", "REGULAR - 2EM - T - J",
    "REGULAR - 3EM - M - A", "REGULAR - 3EM - M - B", "REGULAR - 3EM - M - C", "REGULAR - 3EM - M - D", "REGULAR - 3EM - M - E", "REGULAR - 3EM - M - F",
    "REGULAR - 3EM - T - G", "REGULAR - 3EM - T - H", "REGULAR - 3EM - T - I", "REGULAR - 3EM - T - J", "REGULAR - 3EM - T - K", "REGULAR - 3EM - T - L"
]

def normalizar_texto(texto):
    if not texto:
        return ""
    texto_limpo = str(texto).replace('\xa0', ' ').replace('&nbsp;', ' ')
    return re.sub(r'\s+', ' ', texto_limpo).strip().upper()

def carregar_mapa_todas_turmas(driver_inst):
    try:
        driver_inst.get(URL_TODAS_TURMAS)
        time.sleep(2)
        soup = BeautifulSoup(driver_inst.page_source, "html.parser")
        rows = soup.find_all("tr", class_="turma-row")
        mapa_turmas = {}
        for row in rows:
            id_cell = row.find("td", class_="id-cell")
            mod_cell = row.find("td", class_="modalidade-cell")
            ano_cell = row.find("td", class_="ano-cell")
            turno_cell = row.find("td", class_="turno-cell")
            sala_cell = row.find("td", class_="sala-cell")
            if id_cell and mod_cell and ano_cell and turno_cell and sala_cell:
                codigo = id_cell.text.strip()
                mod = normalizar_texto(mod_cell.text)
                ano_t = normalizar_texto(ano_cell.text)
                turno_t = normalizar_texto(turno_cell.text)
                sala_t = normalizar_texto(sala_cell.text)
                chave = f"{mod} - {ano_t} - {turno_t} - {sala_t}"
                mapa_turmas[chave] = codigo
        return mapa_turmas
    except Exception as e:
        raise SDEForaDoArError(f"Erro ao acessar listagem de turmas no SDE: {e}")

def extrair_alunos_do_espelho(driver_inst, codigo_turma):
    driver_inst.get(f"{URL_ESPELHO_BASE}?turma={codigo_turma}")
    time.sleep(1.5)
    soup = BeautifulSoup(driver_inst.page_source, "html.parser")
    alunos = []
    
    for row in soup.find_all("tr"):
        tds = row.find_all("td")
        if len(tds) < 3:
            continue

        id_estadual = None

        input_id = row.find("input", {"name": re.compile(r"^id_aluno")})
        if input_id and input_id.get("value"):
            id_estadual = input_id.get("value").strip()

        if not id_estadual:
            texto_td1 = str(tds[0])
            match_id = re.search(r'Estadual</b>:\s*(?:&nbsp;)?\s*(\d+)', texto_td1, re.IGNORECASE)
            if match_id:
                id_estadual = match_id.group(1).strip()

        if id_estadual:
            td_nome = tds[2]
            for span in td_nome.find_all("span"):
                span.decompose()

            nome_aluno = normalizar_texto(td_nome.text)
            
            if nome_aluno and "NOME DO ESTUDANTE" not in nome_aluno:
                alunos.append({"id_estadual": id_estadual, "nome": nome_aluno})

    return alunos

def extrair_professores_da_turma(driver_inst, codigo_turma):
    driver_inst.get(f"{URL_SUPERVISAO_PROFESSOR}?turma={codigo_turma}")
    time.sleep(1.5)
    soup = BeautifulSoup(driver_inst.page_source, "html.parser")
    professores = []
    
    for tr in soup.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) >= 5:
            cpf = tds[1].text.strip()
            nome_prof = normalizar_texto(tds[2].text)
            disciplina = normalizar_texto(tds[3].text)
            
            if re.match(r'^\d{11}$', cpf):
                professores.append({
                    "cpf": cpf,
                    "nome": nome_prof,
                    "disciplina": disciplina
                })
    return professores

def obter_codigo_turma_professor(driver_inst, cpf_prof, nome_turma, disciplina):
    driver_inst.get(f"{URL_PESQUISA_PROF_FREQ}?q={cpf_prof}")
    time.sleep(1.5)
    soup = BeautifulSoup(driver_inst.page_source, "html.parser")
    
    for tr in soup.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) >= 5:
            turma_texto = normalizar_texto(tds[3].text)
            disc_texto = normalizar_texto(tds[4].text)
            
            if nome_turma in turma_texto and disciplina in disc_texto:
                link = tds[0].find("a")
                if link and "href" in link.attrs:
                    href = link["href"]
                    match = re.search(r'codigo=(\d+)', href)
                    if match:
                        return match.group(1)
    return None

def extrair_frequencia_direta(driver_inst, cpf_prof, id_turmaprofessor, id_etapa="", mes=""):
    url_completa = (
        f"{URL_RELATORIO_FREQ}?"
        f"professor_cpf={cpf_prof}&"
        f"id_turmaprofessor={id_turmaprofessor}&"
        f"id_etapa={id_etapa}&"
        f"mes={mes}"
    )
    
    driver_inst.get(url_completa)
    time.sleep(2)

    if "Estudante" not in driver_inst.page_source:
        url_alt = f"https://sde.seduc.ro.gov.br/escola/calendario/form_dia_diario_frequencia.php?codigo={id_turmaprofessor}"
        driver_inst.get(url_alt)
        time.sleep(1.5)
        try:
            if id_etapa:
                select_etapa = WebDriverWait(driver_inst, 5).until(
                    EC.presence_of_element_located((By.ID, "id_etapa"))
                )
                select_etapa.send_keys(str(id_etapa))
            elif mes:
                select_mes = WebDriverWait(driver_inst, 5).until(
                    EC.presence_of_element_located((By.ID, "mes"))
                )
                select_mes.send_keys(str(mes).zfill(2))

            btn_vis = driver_inst.find_element(By.XPATH, "//button[@type='submit' and contains(text(), 'VISUALIZAR')]")
            btn_vis.click()
            time.sleep(2)
        except Exception:
            pass

    soup = BeautifulSoup(driver_inst.page_source, "html.parser")
    
    datas_aulas = []
    trs_cabecalho = soup.find_all("tr")
    header_tr = None
    for tr in trs_cabecalho:
        ths = tr.find_all("th")
        if ths and any(re.search(r'\d{2}/\d{2}', th.text) for th in ths):
            header_tr = tr
            break

    if header_tr:
        ths = header_tr.find_all("th")
        for th in ths:
            texto_th = normalizar_texto(th.text)
            match_data = re.search(r'\d{2}/\d{2}', texto_th)
            if match_data:
                datas_aulas.append(match_data.group(0))

    frequencias_alunos = {}
    
    for tr in soup.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) < 3:
            continue

        nome_elem = tr.find("p") or tds[1]
        nome_aluno = normalizar_texto(nome_elem.text)
        
        if not nome_aluno or "ESTUDANTE" in nome_aluno or "Nº" in nome_aluno or "RAZÃO SOCIAL" in nome_aluno:
            continue

        idx_situacao = -1
        for idx_c, td in enumerate(tds):
            txt_td = normalizar_texto(td.text)
            if any(sit in txt_td for sit in ["MATRICULADO", "REMANEJADO", "TRANSFERIDO", "FALECIDO", "CANCELADO"]):
                idx_situacao = idx_c
                break

        if idx_situacao != -1:
            situacao = normalizar_texto(tds[idx_situacao].text)
            colunas_frequencia = tds[idx_situacao + 1 :]
        else:
            situacao = "MATRICULADO"
            colunas_frequencia = tds[3:]

        datas_faltas_aluno = []
        total_faltas_aluno = 0

        for idx in range(len(datas_aulas)):
            if idx < len(colunas_frequencia):
                td_txt = normalizar_texto(colunas_frequencia[idx].text)
                qtd_f_celula = td_txt.count("F")
                if qtd_f_celula > 0:
                    total_faltas_aluno += qtd_f_celula
                    for _ in range(qtd_f_celula):
                        datas_faltas_aluno.append(datas_aulas[idx])

        frequencias_alunos[nome_aluno] = {
            "situacao": situacao,
            "total_faltas": total_faltas_aluno,
            "datas_faltas": datas_faltas_aluno
        }

    return datas_aulas, frequencias_alunos

def calcular_idade_anos_meses(data_nasc_str):
    if not data_nasc_str or data_nasc_str == "-":
        return "-"
    try:
        dt_nasc = datetime.strptime(data_nasc_str, "%d/%m/%Y")
        hoje = datetime.now()
        diff = relativedelta(hoje, dt_nasc)
        return f"{diff.years} anos e {diff.months} meses"
    except Exception:
        return "-"

def carregar_mapa_dados_pessoais(driver_inst):
    mapa = {}
    try:
        driver_inst.get(URL_RELATORIO_ALUNOS)
        time.sleep(2.5)

        soup = BeautifulSoup(driver_inst.page_source, "html.parser")
        for row in soup.find_all("tr"):
            tds = row.find_all("td")
            if len(tds) >= 8:
                id_est = tds[0].text.strip()
                turma_txt = normalizar_texto(tds[4].text)
                dt_nasc = tds[6].text.strip()
                contato = tds[7].text.strip()

                if id_est and id_est.isdigit():
                    chave = (id_est, turma_txt)
                    mapa[chave] = {
                        "data_nasc": dt_nasc if dt_nasc else "-",
                        "idade_str": calcular_idade_anos_meses(dt_nasc),
                        "contato": contato if contato else "-"
                    }
    except Exception:
        pass
    return mapa

def carregar_mapa_boletins_turma(driver_inst, codigo_turma):
    """Mapeia os links dos boletins da turma pelo ID do aluno."""
    mapa_boletins = {}
    try:
        url_lista = f"{URL_BOLETIM_LISTA}?id_turma={codigo_turma}"
        driver_inst.get(url_lista)
        time.sleep(1.5)

        soup = BeautifulSoup(driver_inst.page_source, "html.parser")
        for row in soup.find_all("tr"):
            link_a = row.find("a", href=re.compile(r"rel_boletim_refatoracao\.php"))
            if link_a and "href" in link_a.attrs:
                href = link_a["href"]
                match_id = re.search(r"id_aluno=(\d+)", href)
                if match_id:
                    id_aluno = match_id.group(1)
                    if href.startswith("http"):
                        url_boletim = href
                    else:
                        url_boletim = f"https://sde.seduc.ro.gov.br/escola/nota/{href.lstrip('/')}"
                    mapa_boletins[id_aluno] = url_boletim
    except Exception:
        pass
    return mapa_boletins

def extrair_faltas_validas_boletim(driver_inst, url_boletim):
    """Acessa o boletim e recolhe o total de faltas válidas."""
    if not url_boletim:
        return "-"
    try:
        driver_inst.get(url_boletim)
        time.sleep(1.2)

        soup = BeautifulSoup(driver_inst.page_source, "html.parser")
        for tr in soup.find_all("tr"):
            ths = tr.find_all("th")
            if ths and any("Total de faltas válidas" in th.text for th in ths):
                next_tr = tr.find_next_sibling("tr")
                if next_tr:
                    tds = next_tr.find_all("td")
                    if len(tds) >= 5:
                        val = tds[4].text.strip()
                        return val if val else "0"
    except Exception:
        pass
    return "-"

def processar_historico_completo_e_consecutivos(materia_datas_dict):
    ano_atual = datetime.now().year
    todas_faltas = []
    
    for disc, lista_datas in materia_datas_dict.items():
        for d_str in lista_datas:
            try:
                dt = datetime.strptime(f"{d_str}/{ano_atual}", "%d/%m/%Y").date()
                todas_faltas.append((dt, d_str, disc))
            except ValueError:
                continue

    if not todas_faltas:
        return 0, "Nenhuma falta registrada", "Nenhuma falta registrada"

    todas_faltas.sort(key=lambda x: x[0])

    dias_unicos = {}
    for dt, d_str, disc in todas_faltas:
        if dt not in dias_unicos:
            dias_unicos[dt] = (d_str, set())
        dias_unicos[dt][1].add(disc)

    datas_ordenadas = sorted(list(dias_unicos.keys()))

    max_seguidos = 1
    sequencia_maxima = [datas_ordenadas[0]]
    sequencia_atual = [datas_ordenadas[0]]

    for i in range(1, len(datas_ordenadas)):
        if datas_ordenadas[i] == datas_ordenadas[i - 1] + timedelta(days=1):
            sequencia_atual.append(datas_ordenadas[i])
            if len(sequencia_atual) > max_seguidos:
                max_seguidos = len(sequencia_atual)
                sequencia_maxima = list(sequencia_atual)
        else:
            sequencia_atual = [datas_ordenadas[i]]

    detalhes_consecutivos = []
    for dt in sequencia_maxima:
        d_str, set_discs = dias_unicos[dt]
        discs_texto = "/".join(sorted(list(set_discs)))
        detalhes_consecutivos.append(f"{d_str}: {discs_texto}")

    if max_seguidos > 1:
        texto_consecutivos = f"{max_seguidos} dias seguidos [{ ' | '.join(detalhes_consecutivos) }]"
    else:
        todas_datas_isoladas = [f"{dias_unicos[dt][0]}: {'/'.join(sorted(list(dias_unicos[dt][1])))}" for dt in datas_ordenadas]
        texto_consecutivos = f"Faltas isoladas [{ ' | '.join(todas_datas_isoladas) }]"

    todas_faltas_itens = []
    for dt in datas_ordenadas:
        d_str, set_discs = dias_unicos[dt]
        discs_texto = "/".join(sorted(list(set_discs)))
        todas_faltas_itens.append(f"{d_str}: {discs_texto}")

    texto_faltas_geral_completo = " | ".join(todas_faltas_itens)

    return max_seguidos, texto_consecutivos, texto_faltas_geral_completo

def gerador_pdf_bytes(df_relatorio, sufixo_nome):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(letter),
        rightMargin=10,
        leftMargin=10,
        topMargin=15,
        bottomMargin=15
    )
    elements = []
    styles = getSampleStyleSheet()

    titulo_style = ParagraphStyle(
        'TituloPDF',
        parent=styles['Heading1'],
        fontSize=11,
        textColor=colors.HexColor("#1F497D"),
        alignment=1,
        spaceAfter=4
    )

    cell_style = ParagraphStyle('CellText', parent=styles['Normal'], fontSize=5.5, leading=7)
    cell_header_style = ParagraphStyle('CellHeader', parent=styles['Normal'], fontSize=6, leading=7, textColor=colors.whitesmoke, fontName='Helvetica-Bold')
    cell_black_bold = ParagraphStyle('CellBlackBold', parent=styles['Normal'], fontSize=5.5, leading=7, textColor=colors.HexColor("#333333"), fontName='Helvetica-Bold')

    elements.append(Paragraph(f"SmartMajor - Monitoramento de Faltas e Risco de Abandono ({sufixo_nome.replace('_', ' ')})", titulo_style))
    elements.append(Paragraph(f"Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}", styles['Normal']))
    elements.append(Spacer(1, 6))

    colunas_pdf = [
        "Nº", "Diagnóstico", "Total Faltas", "Faltas Válidas (Ano)", "Estudante", "ID Estadual",
        "Data Nasc.", "Idade Atual", "Contato", "Turma", "Situação",
        "Dias Consecutivos (Detalhamento)", "Datas das Faltas (Geral)"
    ]
    cols_presentes = [c for c in colunas_pdf if c in df_relatorio.columns]

    if not df_relatorio.empty:
        df_sub = df_relatorio[cols_presentes].copy()

        # Larguras otimizadas para totalizar aproximadamente 770pt (largura da página landscape)
        larguras_mapa = {
            "Nº": 20,
            "Diagnóstico": 75,
            "Total Faltas": 25,
            "Faltas Válidas (Ano)": 35,
            "Estudante": 90,
            "ID Estadual": 40,
            "Data Nasc.": 45,
            "Idade Atual": 55,
            "Contato": 55,
            "Turma": 65,
            "Situação": 45,
            "Dias Consecutivos (Detalhamento)": 120,
            "Datas das Faltas (Geral)": 100
        }
        col_widths = [larguras_mapa.get(c, 50) for c in cols_presentes]

        header_row = [Paragraph(c, cell_header_style) for c in cols_presentes]
        data_tabela = [header_row]

        table_styles = [
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F497D")),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 1.5),
            ('TOPPADDING', (0, 0), (-1, -1), 1.5),
            ('LEFTPADDING', (0, 0), (-1, -1), 2),
            ('RIGHTPADDING', (0, 0), (-1, -1), 2),
            ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor("#CCCCCC"))
        ]

        idx_diag = cols_presentes.index("Diagnóstico") if "Diagnóstico" in cols_presentes else -1

        for row_idx, row_data in enumerate(df_sub.values, start=1):
            row_cells = []
            val_diag = str(row_data[idx_diag]) if idx_diag != -1 else ""

            if "🔴" in val_diag or "RISCO" in val_diag:
                bg_color = colors.HexColor("#FFC7CE")
            elif "🟡" in val_diag or "ALERTA" in val_diag:
                bg_color = colors.HexColor("#FFEB9C")
            else:
                bg_color = colors.HexColor("#C6EFCE")

            for col_idx, val in enumerate(row_data):
                val_str = str(val or "")
                if col_idx == idx_diag:
                    row_cells.append(Paragraph(val_str, cell_black_bold))
                    table_styles.append(('BACKGROUND', (col_idx, row_idx), (col_idx, row_idx), bg_color))
                else:
                    row_cells.append(Paragraph(val_str, cell_style))

            data_tabela.append(row_cells)

        t_abandono = Table(data_tabela, colWidths=col_widths, hAlign='LEFT', repeatRows=1)
        t_abandono.setStyle(TableStyle(table_styles))
        elements.append(t_abandono)
    else:
        elements.append(Paragraph("Nenhum registro encontrado.", styles['Normal']))

    doc.build(elements)
    buffer.seek(0)
    return buffer

# --- FUNÇÃO PRINCIPAL INTEGRADORA ---
def executar_analise_abandono(
    usuario_sde, 
    senha_sde, 
    turma_sel="TODAS", 
    tipo_filtro="Etapa", 
    id_etapa="", 
    mes="", 
    status_callback=None, 
    **kwargs
):
    logs_execucao = []
    def log(msg):
        logs_execucao.append(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

    log(f"Iniciando Módulo de Faltas e Abandono. Filtro: {tipo_filtro} | Turma: {turma_sel}")

    options = webdriver.ChromeOptions()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 20)

    try:
        if status_callback:
            status_callback("Realizando login no SDE...", 0.05, 0)
        
        driver.get(URL_LOGIN)

        try:
            campo_cpf = wait.until(EC.presence_of_element_located((By.ID, "cpf")))
            campo_cpf.clear()
            campo_cpf.send_keys(usuario_sde)

            campo_senha = driver.find_element(By.XPATH, "//input[@type='password']")
            campo_senha.clear()
            campo_senha.send_keys(senha_sde)
            campo_senha.send_keys(Keys.RETURN)
            time.sleep(2)
        except Exception as e:
            raise SDEForaDoArError(f"Não foi possível autenticar no SDE: {e}")

        if status_callback:
            status_callback("Mapeando turmas do sistema...", 0.10, 0)

        mapa_todas_turmas = carregar_mapa_todas_turmas(driver)

        if turma_sel == "TODAS":
            turmas_para_processar = [t for t in TURMAS_REGULARES if t in mapa_todas_turmas]
        else:
            turmas_para_processar = [turma_sel]

        alunos_dados = {}
        disciplinas_encontradas = set()

        total_turmas = len(turmas_para_processar)
        inicio = time.time()

        for idx_t, turma_alvo in enumerate(turmas_para_processar, 1):
            codigo_turma = mapa_todas_turmas.get(turma_alvo)
            if not codigo_turma:
                log(f"⚠️ Turma {turma_alvo} não possui código ID cadastrado.")
                continue

            log(f"🔍 Coletando espelho e estudantes da turma: {turma_alvo}")
            alunos_espelho = extrair_alunos_do_espelho(driver, codigo_turma)
            
            for al in alunos_espelho:
                chave_aluno = (turma_alvo, al["nome"])
                if chave_aluno not in alunos_dados:
                    alunos_dados[chave_aluno] = {
                        "Turma": turma_alvo,
                        "ID Estadual": al.get("id_estadual", "-"),
                        "Estudante": al["nome"],
                        "Situação": "MATRICULADO",
                        "Faltas_Por_Disciplina": {},
                        "Datas_Faltas_Por_Disciplina": {},
                        "Datas_Faltas_Geral": set()
                    }

            log(f"🔍 Mapeando professores da turma: {turma_alvo}")
            professores = extrair_professores_da_turma(driver, codigo_turma)
            if not professores:
                log(f"⚠️ Nenhum professor encontrado na supervisão para {turma_alvo}")
                continue

            for idx_p, prof in enumerate(professores, 1):
                cpf_p = prof["cpf"]
                nome_p = prof["nome"]
                disc_p = prof["disciplina"]
                disciplinas_encontradas.add(disc_p)

                tempo_decorrido = time.time() - inicio
                tempo_medio = tempo_decorrido / (idx_t + (idx_p / len(professores)))
                restantes = total_turmas - idx_t
                tempo_restante_seg = int(tempo_medio * restantes)
                progresso_pct = 0.10 + (idx_t / total_turmas) * 0.65

                if status_callback:
                    status_callback(
                        f"Lendo Frequência: [{turma_alvo}] - {disc_p} ({nome_p})",
                        progresso_pct, tempo_restante_seg
                    )

                cod_turmaprof = obter_codigo_turma_professor(driver, cpf_p, turma_alvo, disc_p)
                if not cod_turmaprof:
                    log(f"   ❌ Diário não localizado para {nome_p} em {disc_p}")
                    continue

                datas, freq_alunos = extrair_frequencia_direta(
                    driver, 
                    cpf_prof=cpf_p, 
                    id_turmaprofessor=cod_turmaprof, 
                    id_etapa=id_etapa, 
                    mes=mes
                )

                for nome_aluno, dados_aluno in freq_alunos.items():
                    chave_aluno = (turma_alvo, nome_aluno)
                    if chave_aluno not in alunos_dados:
                        alunos_dados[chave_aluno] = {
                            "Turma": turma_alvo,
                            "ID Estadual": "-",
                            "Estudante": nome_aluno,
                            "Situação": dados_aluno.get("situacao", "MATRICULADO"),
                            "Faltas_Por_Disciplina": {},
                            "Datas_Faltas_Por_Disciplina": {},
                            "Datas_Faltas_Geral": set()
                        }
                    else:
                        alunos_dados[chave_aluno]["Situação"] = dados_aluno.get("situacao", "MATRICULADO")

                    qtd_faltas = dados_aluno.get("total_faltas", 0)
                    datas_faltas_disc = dados_aluno.get("datas_faltas", [])

                    alunos_dados[chave_aluno]["Faltas_Por_Disciplina"][disc_p] = qtd_faltas
                    alunos_dados[chave_aluno]["Datas_Faltas_Por_Disciplina"][disc_p] = datas_faltas_disc
                    
                    for dt_f in datas_faltas_disc:
                        alunos_dados[chave_aluno]["Datas_Faltas_Geral"].add(dt_f)

        log("📋 Carregando dados pessoais estáticos de rel_alunos.php...")
        if status_callback:
            status_callback("Carregando relatório estático de dados pessoais...", 0.78, 5)

        mapa_dados_pessoais = carregar_mapa_dados_pessoais(driver)

        # Mapeamento prévio dos boletins de cada turma
        mapa_boletins_por_turma = {}
        for turma_alvo in turmas_para_processar:
            cod_t = mapa_todas_turmas.get(turma_alvo)
            if cod_t:
                mapa_boletins_por_turma[turma_alvo] = carregar_mapa_boletins_turma(driver, cod_t)

        cache_faltas_validas = {}
        total_alunos = len(alunos_dados)

        for idx_a, ((turma_nome, nome_aluno), info) in enumerate(alunos_dados.items(), 1):
            total_faltas = sum(info.get("Faltas_Por_Disciplina", {}).values())
            materia_datas_map = info.get("Datas_Faltas_Por_Disciplina", {})
            max_consecutivas, texto_consecutivos, texto_faltas_geral = processar_historico_completo_e_consecutivos(materia_datas_map)

            if max_consecutivas >= 5 or total_faltas >= 15:
                diagnostico = "🔴 RISCO DE ABANDONO"
            elif max_consecutivas >= 3 or total_faltas >= 8:
                diagnostico = "🟡 ALERTA DE FALTAS"
            else:
                diagnostico = "🟢 DADOS OK / FREQUÊNCIA REGULAR"

            info["Diagnóstico"] = diagnostico
            info["Dias Consecutivos (Detalhamento)"] = texto_consecutivos
            info["Datas das Faltas (Geral)"] = texto_faltas_geral

            id_est_aluno = info.get("ID Estadual", "-")
            turma_norm = normalizar_texto(turma_nome)
            
            chave_pessoal = (id_est_aluno, turma_norm)
            dados_pessoais = mapa_dados_pessoais.get(chave_pessoal)

            if not dados_pessoais:
                for (id_m, _), d_m in mapa_dados_pessoais.items():
                    if id_m == id_est_aluno:
                        dados_pessoais = d_m
                        break

            if dados_pessoais:
                info["Data Nasc."] = dados_pessoais["data_nasc"]
                info["Idade Atual"] = dados_pessoais["idade_str"]
                info["Contato"] = dados_pessoais["contato"]
            else:
                info["Data Nasc."] = "-"
                info["Idade Atual"] = "-"
                info["Contato"] = "-"

            # Consulta do Boletim para Faltas Válidas
            if status_callback:
                status_callback(
                    f"Consultando Boletim/Faltas Válidas: {nome_aluno}",
                    0.80 + (idx_a / max(total_alunos, 1)) * 0.18, 5
                )

            if id_est_aluno not in cache_faltas_validas:
                mapa_bol_turma = mapa_boletins_por_turma.get(turma_nome, {})
                url_boletim_aluno = mapa_bol_turma.get(id_est_aluno)
                
                faltas_val = extrair_faltas_validas_boletim(driver, url_boletim_aluno)
                cache_faltas_validas[id_est_aluno] = faltas_val
            
            info["Faltas Válidas (Ano)"] = cache_faltas_validas[id_est_aluno]

        lista_disciplinas = sorted(list(disciplinas_encontradas))
        relatorio_dados = []

        for idx_num, ((turma_nome, nome_aluno), info) in enumerate(alunos_dados.items(), start=1):
            total_faltas = sum(info.get("Faltas_Por_Disciplina", {}).values())
            detalhe_consecutivas = info.get("Dias Consecutivos (Detalhamento)", "Nenhuma falta registrada")
            datas_gerais_str = info.get("Datas das Faltas (Geral)", "Nenhuma falta registrada")
            
            if total_faltas == 0:
                detalhe_consecutivas = "Nenhuma falta registrada"
                datas_gerais_str = "Nenhuma falta registrada"

            id_est = info.get("ID Estadual", "-")

            item_linha = {
                "Nº": idx_num,
                "Diagnóstico": info.get("Diagnóstico", "Indefinido"),
                "Total Faltas": total_faltas,
                "Faltas Válidas (Ano)": info.get("Faltas Válidas (Ano)", "-"),
                "Estudante": nome_aluno,
                "ID Estadual": id_est,
                "Data Nasc.": info.get("Data Nasc.", "-"),
                "Idade Atual": info.get("Idade Atual", "-"),
                "Contato": info.get("Contato", "-"),
                "Turma": turma_nome,
                "Situação": info.get("Situação", "MATRICULADO"),
                "Dias Consecutivos (Detalhamento)": detalhe_consecutivas,
                "Datas das Faltas (Geral)": datas_gerais_str,
            }

            for disc in lista_disciplinas:
                qtd = info.get("Faltas_Por_Disciplina", {}).get(disc, 0)
                dts_disc = info.get("Datas_Faltas_Por_Disciplina", {}).get(disc, [])
                
                if qtd > 0:
                    if dts_disc:
                        item_linha[disc] = f"{qtd} ({', '.join(sorted(dts_disc))})"
                    else:
                        item_linha[disc] = f"{qtd} faltas"
                else:
                    item_linha[disc] = "0"

            item_linha["Link Ficha SDE"] = f"{URL_PESQUISA_ALUNO_BASE}?q={id_est}" if id_est != "-" else URL_PESQUISA_ALUNO_BASE
            relatorio_dados.append(item_linha)

        sufixo_nome = turma_sel.replace(' ', '_')
        carimbo_tempo = datetime.now().strftime("%Y%m%d_%H%M%S")
        nome_arquivo_base = f"Relatorio_Abandono_{sufixo_nome}_{carimbo_tempo}"

        df_relatorio = pd.DataFrame(relatorio_dados)

        if not df_relatorio.empty:
            cols_iniciais = [
                "Nº", "Diagnóstico", "Total Faltas", "Faltas Válidas (Ano)", "Estudante", "ID Estadual",
                "Data Nasc.", "Idade Atual", "Contato", "Turma", "Situação",
                "Dias Consecutivos (Detalhamento)", "Datas das Faltas (Geral)"
            ]
            cols_disc = [c for c in df_relatorio.columns if c not in cols_iniciais and c != "Link Ficha SDE"]
            ordem_final = cols_iniciais + cols_disc + ["Link Ficha SDE"]
            df_relatorio = df_relatorio[ordem_final]

        # 1. GERAR EXCEL EM MEMÓRIA
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            df_relatorio.to_excel(writer, sheet_name="Abandono_Frequencia", index=False)
            wb = writer.book
            ws = wb["Abandono_Frequencia"]
            ws.views.sheetView[0].showGridLines = True

            header_fill = PatternFill(start_color="1F497D", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True)

            red_fill = PatternFill(start_color="FFC7CE", fill_type="solid")
            red_font = Font(color="9C0006", bold=True)
            yellow_fill = PatternFill(start_color="FFEB9C", fill_type="solid")
            yellow_font = Font(color="9C6500", bold=True)
            green_fill = PatternFill(start_color="C6EFCE", fill_type="solid")
            green_font = Font(color="006100", bold=True)

            for cell in ws[1]:
                cell.fill, cell.font = header_fill, header_font
                cell.alignment = Alignment(horizontal="center", vertical="center")

            if "Diagnóstico" in df_relatorio.columns:
                col_idx_diag = df_relatorio.columns.get_loc("Diagnóstico") + 1
                for row in ws.iter_rows(min_row=2):
                    celula_diag = row[col_idx_diag - 1]
                    val_diag = str(celula_diag.value)

                    if "🔴" in val_diag or "RISCO" in val_diag:
                        celula_diag.fill, celula_diag.font = red_fill, red_font
                    elif "🟡" in val_diag or "ALERTA" in val_diag:
                        celula_diag.fill, celula_diag.font = yellow_fill, yellow_font
                    else:
                        celula_diag.fill, celula_diag.font = green_fill, green_font

            for col in ws.columns:
                max_len = max(len(str(cell.value or '')) for cell in col)
                col_letter = get_column_letter(col[0].column)
                ws.column_dimensions[col_letter].width = max(max_len + 3, 12)

        excel_buffer.seek(0)

        # 2. GERAR PDF EM MEMÓRIA
        pdf_buffer = gerador_pdf_bytes(df_relatorio, sufixo_nome)

        log("Relatório em memória gerado com sucesso.")
        if status_callback:
            status_callback("Concluído!", 1.0, 0)

        return {
            "excel_bytes": excel_buffer.getvalue(),
            "pdf_bytes": pdf_buffer.getvalue(),
            "nome_arquivo_excel": f"{nome_arquivo_base}.xlsx",
            "nome_arquivo_pdf": f"{nome_arquivo_base}.pdf",
            "df_relatorio": df_relatorio,
            "logs_execucao": logs_execucao
        }

    finally:
        try:
            driver.quit()
        except Exception:
            pass