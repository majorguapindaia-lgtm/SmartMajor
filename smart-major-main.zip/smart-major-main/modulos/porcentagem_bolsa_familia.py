import os
import re
import io
import time
import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

class SDEForaDoArError(Exception):
    """Exceção lançada quando o SDE está indisponível ou fora do ar."""
    pass

URL_LOGIN_SDE = "https://sde.seduc.ro.gov.br/login.php"
URL_DIARIO_BASE = "https://sde.seduc.ro.gov.br/escola/aluno/rel_alunos_ab_mes.php?mes_aula={mes_numero}&busca="

MAPA_MESES = {
    "Fevereiro": "02",
    "Março": "03",
    "Abril": "04",
    "Maio": "05",
    "Junho": "06",
    "Julho": "07",
    "Agosto": "08",
    "Setembro": "09",
    "Outubro": "10",
    "Novembro": "11",
    "Dezembro": "12"
}

def normalizar_texto(texto):
    if not texto:
        return ""
    return re.sub(r'\s+', ' ', str(texto)).strip().upper()

def processar_linhas_tabela(html_source, total_aulas, dados_mes):
    """Mapeia os dados do HTML baseado na estrutura da tabela do Bolsa Família, lendo todas as linhas (visíveis e ocultas)."""
    soup = BeautifulSoup(html_source, "html.parser")
    tabela = soup.find("table", id="bfTable") or soup.find("table")
    
    if tabela:
        tbody = tabela.find("tbody", id="bfBody") or tabela.find("tbody") or tabela
        linhas = tbody.find_all("tr")

        for linha in linhas:
            colunas = linha.find_all("td")
            
            if len(colunas) >= 9:
                id_aluno = colunas[0].text.strip()
                
                # Nome do Aluno
                nome_elem = colunas[1].find("span", class_="bf-nome")
                nome_bruto = nome_elem.text if nome_elem else colunas[1].text
                nome = normalizar_texto(nome_bruto)
                
                # NIS (coluna 5)
                nis_bruto = colunas[5].text.strip()
                nis = re.sub(r"\D", "", nis_bruto)

                # Faltas no mês (coluna 8)
                val_falta_elem = colunas[8].find("span", class_="bf-num")
                val_falta_str = val_falta_elem.text.strip() if val_falta_elem else colunas[8].text.strip()
                try:
                    faltas_mes = int(re.sub(r"\D", "", val_falta_str))
                except ValueError:
                    faltas_mes = 0

                # Cálculo de Presença
                aulas_presentes = max(0, total_aulas - faltas_mes)
                if total_aulas > 0:
                    porcentagem_presenca = int(round((aulas_presentes / total_aulas) * 100))
                else:
                    porcentagem_presenca = 100

                # Regra do negócio: teto máximo em 99%
                if porcentagem_presenca >= 100:
                    porcentagem_presenca = 99

                chave = nis if nis else (id_aluno if id_aluno else nome)
                
                if chave and chave not in dados_mes:
                    dados_mes[chave] = {
                        "id_aluno": id_aluno,
                        "nome": nome,
                        "nis": nis if nis else "-",
                        "faltas": faltas_mes,
                        "presenca": porcentagem_presenca
                    }

def extrair_dados_mes_sde(driver, wait, mes_numero, mes_nome, total_aulas):
    """Acessa o mês parametrizado e extrai todas as linhas da tabela."""
    try:
        url_mes = URL_DIARIO_BASE.format(mes_numero=mes_numero)
        driver.get(url_mes)

        wait.until(
            EC.presence_of_element_located((By.XPATH, "//table//tbody/tr[td]"))
        )
        time.sleep(1.5)

        # Exibe todas as linhas ocultas removendo o atributo 'hidden' via JS no navegador
        try:
            driver.execute_script(
                "document.querySelectorAll('#bfTable tbody tr, table tbody tr').forEach(tr => tr.removeAttribute('hidden'));"
            )
            time.sleep(1.0)
        except Exception:
            pass

        dados_mes = {}
        processar_linhas_tabela(driver.page_source, total_aulas, dados_mes)

        return dados_mes

    except Exception as e:
        raise SDEForaDoArError(f"Erro ao extrair dados de frequência do SDE ({mes_nome}): {e}")

def consolidar_dados_dois_meses(dados_m1, dados_m2):
    todas_chaves = set(dados_m1.keys()).union(set(dados_m2.keys()))
    dados_consolidados = []

    for chave in todas_chaves:
        aluno_m1 = dados_m1.get(chave, {})
        aluno_m2 = dados_m2.get(chave, {})

        id_aluno = aluno_m1.get("id_aluno") or aluno_m2.get("id_aluno", "-")
        nome = aluno_m1.get("nome") or aluno_m2.get("nome", "")
        nis = aluno_m1.get("nis") or aluno_m2.get("nis", "-")
        
        faltas_m1 = aluno_m1.get("faltas", 0)
        presenca_m1 = aluno_m1.get("presenca", 99)

        faltas_m2 = aluno_m2.get("faltas", 0)
        presenca_m2 = aluno_m2.get("presenca", 99)

        dados_consolidados.append({
            "id_aluno": id_aluno,
            "nome": nome,
            "nis": nis,
            "presenca_m1": presenca_m1,
            "presenca_m2": presenca_m2,
            "faltas_m1": faltas_m1,
            "faltas_m2": faltas_m2
        })

    dados_consolidados.sort(key=lambda x: x["nome"])
    return dados_consolidados

def gerador_excel_bytes(dados_consolidados, mes1_nome, mes2_nome):
    output = io.BytesIO()
    wb = Workbook()
    ws = wb.active
    ws.title = f"Presença_{mes1_nome[:3]}_{mes2_nome[:3]}"

    headers = [
        "ID Aluno",
        "Nome do Estudante",
        "NIS",
        f"Presença % ({mes1_nome})",
        f"Presença % ({mes2_nome})",
        f"Faltas ({mes1_nome})",
        f"Faltas ({mes2_nome})"
    ]
    ws.append(headers)

    for al in dados_consolidados:
        ws.append([
            al["id_aluno"],
            al["nome"],
            al["nis"],
            al["presenca_m1"],
            al["presenca_m2"],
            al["faltas_m1"],
            al["faltas_m2"]
        ])

    header_fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    
    # Fills idênticos ao PDF
    fill_risco = PatternFill(start_color="F8CECC", end_color="F8CECC", fill_type="solid")
    fill_normal = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

    thin_border = Border(
        left=Side(style="thin", color="D9D9D9"),
        right=Side(style="thin", color="D9D9D9"),
        top=Side(style="thin", color="D9D9D9"),
        bottom=Side(style="thin", color="D9D9D9")
    )

    # Estiliza o Cabeçalho
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # Estiliza as Linhas e Aplica as Cores em TODA a linha
    for row_idx, row in enumerate(ws.iter_rows(min_row=2, max_row=len(dados_consolidados) + 1), start=0):
        aluno = dados_consolidados[row_idx]
        tem_risco = aluno["presenca_m1"] < 75 or aluno["presenca_m2"] < 75
        
        row_fill = fill_risco if tem_risco else fill_normal
        row_font = Font(name="Calibri", size=11, bold=tem_risco)

        for col_idx, cell in enumerate(row):
            cell.fill = row_fill
            cell.font = row_font
            cell.border = thin_border

            if col_idx == 0:  # ID
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = "@"
            elif col_idx == 1:  # Nome
                cell.alignment = Alignment(horizontal="left", vertical="center")
            elif col_idx == 2:  # NIS
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = "@"
            elif col_idx in (3, 4):  # Presenças %
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = "0"
            elif col_idx in (5, 6):  # Faltas
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = "0"

    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

    wb.save(output)
    output.seek(0)
    return output.getvalue()

def gerador_pdf_bytes(dados_consolidados, mes1_nome, mes2_nome):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=landscape(letter),
        rightMargin=15, leftMargin=15, topMargin=20, bottomMargin=20
    )
    elements = []
    styles = getSampleStyleSheet()

    titulo_style = ParagraphStyle('TituloPDF', parent=styles['Heading1'], fontSize=14, textColor=colors.HexColor("#1F497D"), alignment=1, spaceAfter=8)
    cell_style = ParagraphStyle('CellText', parent=styles['Normal'], fontSize=7, leading=9)
    cell_bold = ParagraphStyle('CellBold', parent=styles['Normal'], fontSize=7, leading=9, fontName='Helvetica-Bold')
    cell_header = ParagraphStyle('CellHeader', parent=styles['Normal'], fontSize=8, leading=10, textColor=colors.whitesmoke, fontName='Helvetica-Bold')

    elements.append(Paragraph(f"SmartMajor - Relatório de Frequência Bolsa Família ({mes1_nome} e {mes2_nome})", titulo_style))
    elements.append(Paragraph(f"Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}", styles['Normal']))
    elements.append(Spacer(1, 10))

    data = [[
        Paragraph("ID", cell_header),
        Paragraph("Nome do Estudante", cell_header),
        Paragraph("NIS", cell_header),
        Paragraph(f"Presença % ({mes1_nome})", cell_header),
        Paragraph(f"Presença % ({mes2_nome})", cell_header),
        Paragraph(f"Faltas ({mes1_nome})", cell_header),
        Paragraph(f"Faltas ({mes2_nome})", cell_header)
    ]]

    table_styles = [
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F497D")),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
    ]

    for r_idx, al in enumerate(dados_consolidados, start=1):
        tem_risco = al["presenca_m1"] < 75 or al["presenca_m2"] < 75
        bg_color = colors.HexColor("#F8CECC") if tem_risco else colors.HexColor("#C6EFCE")

        row_cells = [
            Paragraph(al["id_aluno"], cell_style),
            Paragraph(al["nome"], cell_bold if tem_risco else cell_style),
            Paragraph(al["nis"], cell_style),
            Paragraph(f"{al['presenca_m1']}%", cell_bold if al["presenca_m1"] < 75 else cell_style),
            Paragraph(f"{al['presenca_m2']}%", cell_bold if al["presenca_m2"] < 75 else cell_style),
            Paragraph(str(al["faltas_m1"]), cell_style),
            Paragraph(str(al["faltas_m2"]), cell_style)
        ]
        data.append(row_cells)
        table_styles.append(('BACKGROUND', (0, r_idx), (-1, r_idx), bg_color))

    t_freq = Table(data, colWidths=[60, 220, 100, 95, 95, 90, 90], hAlign='LEFT', repeatRows=1)
    t_freq.setStyle(TableStyle(table_styles))
    elements.append(t_freq)

    doc.build(elements)
    buffer.seek(0)
    return buffer

def executar_porcentagem_bolsa_familia(usuario_sde, senha_sde, mes1_nome="Agosto", total_aulas_m1=140, mes2_nome="Setembro", total_aulas_m2=140, status_callback=None, **kwargs):
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 30)

    try:
        if status_callback:
            status_callback("Realizando login no SDE...", 0.05, 0)

        driver.get(URL_LOGIN_SDE)

        try:
            campo_cpf = wait.until(EC.presence_of_element_located((By.ID, "cpf")))
            campo_cpf.clear()
            campo_cpf.send_keys(usuario_sde)

            campo_senha = driver.find_element(By.XPATH, "//input[@type='password']")
            campo_senha.clear()
            campo_senha.send_keys(senha_sde)
            campo_senha.send_keys(Keys.RETURN)

            time.sleep(3)
        except Exception as e:
            raise SDEForaDoArError(f"Falha na autenticação SDE: {e}")

        mes1_numero = MAPA_MESES.get(mes1_nome, "08")
        mes2_numero = MAPA_MESES.get(mes2_nome, "09")

        if status_callback:
            status_callback(f"Extraindo dados do Mês 1: {mes1_nome} ({total_aulas_m1} aulas)...", 0.25, 0)
        dados_m1 = extrair_dados_mes_sde(driver, wait, mes1_numero, mes1_nome, total_aulas_m1)

        if status_callback:
            status_callback(f"Extraindo dados do Mês 2: {mes2_nome} ({total_aulas_m2} aulas)...", 0.60, 0)
        dados_m2 = extrair_dados_mes_sde(driver, wait, mes2_numero, mes2_nome, total_aulas_m2)

        if status_callback:
            status_callback("Consolidando dados dos dois meses...", 0.85, 0)
        dados_consolidados = consolidar_dados_dois_meses(dados_m1, dados_m2)

        if status_callback:
            status_callback("Gerando relatórios Excel e PDF em memória...", 0.95, 2)

        excel_bytes = gerador_excel_bytes(dados_consolidados, mes1_nome, mes2_nome)
        pdf_bytes = gerador_pdf_bytes(dados_consolidados, mes1_nome, mes2_nome)

        df_relatorio = pd.DataFrame(dados_consolidados)
        df_relatorio.rename(columns={
            "id_aluno": "ID Aluno",
            "nome": "Nome do Estudante",
            "nis": "NIS",
            "presenca_m1": f"Presença % ({mes1_nome})",
            "presenca_m2": f"Presença % ({mes2_nome})",
            "faltas_m1": f"Faltas ({mes1_nome})",
            "faltas_m2": f"Faltas ({mes2_nome})"
        }, inplace=True)

        # Adiciona uma coluna identificando visualmente se o aluno está em risco
        df_relatorio["Status"] = df_relatorio.apply(
            lambda r: "Abaixo da Média (<75%)" if (r[f"Presença % ({mes1_nome})"] < 75 or r[f"Presença % ({mes2_nome})"] < 75) else "Normal",
            axis=1
        )

        nome_base = f"Porcentagem_Bolsa_Familia_{mes1_nome}_{mes2_nome}"

        return {
            "excel_bytes": excel_bytes,
            "pdf_bytes": pdf_bytes,
            "nome_arquivo_excel": f"{nome_base}.xlsx",
            "nome_arquivo_pdf": f"{nome_base}.pdf",
            "df_relatorio": df_relatorio
        }

    finally:
        driver.quit()