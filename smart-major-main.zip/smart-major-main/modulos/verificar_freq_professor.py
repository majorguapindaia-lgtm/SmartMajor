import time
import re
import io
from datetime import datetime
import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


class SDEForaDoArError(Exception):
    """Exceção lançada quando o SDE está indisponível ou fora do ar."""
    pass


URL_LOGIN = "https://sde.seduc.ro.gov.br/login.php"
URL_SUPERVISAO_PROFESSOR = "https://sde.seduc.ro.gov.br/escola/supervisao/professor_turma.php"
URL_PESQUISA_PROF_FREQ = "https://sde.seduc.ro.gov.br/escola/calendario/form_pesquisa_professor_frequencia.php"
URL_RELATORIO_FREQ = "https://sde.seduc.ro.gov.br/relatorios/frequencia.php"


def normalizar_texto(texto):
    if not texto:
        return ""
    texto_limpo = str(texto).replace('\xa0', ' ').replace('&nbsp;', ' ')
    return re.sub(r'\s+', ' ', texto_limpo).strip().upper()


def extrair_professores_unicos(driver_inst):
    """
    Acessa a página principal de supervisor/professor_turma.php e extrai
    diretamente todos os professores únicos (CPF e Nome) da tabela de listagem.
    """
    professores_unicos = {}  # {cpf: nome_professor}

    try:
        driver_inst.get(URL_SUPERVISAO_PROFESSOR)
        time.sleep(1.5)
        soup = BeautifulSoup(driver_inst.page_source, "html.parser")

        for tr in soup.find_all("tr"):
            tds = tr.find_all("td")
            if len(tds) >= 3:
                cpf = tds[1].text.strip()
                nome_prof = normalizar_texto(tds[2].text)

                if re.match(r'^\d{11}$', cpf) and cpf not in professores_unicos:
                    professores_unicos[cpf] = nome_prof
    except Exception as e:
        print(f"Erro ao extrair professores diretos da tabela: {e}")

    return professores_unicos


def obter_lista_professores_sde(usuario_sde, senha_sde):
    """
    Realiza o login e extrai unicamente a lista/mapa de professores no SDE.
    """
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 20)

    try:
        driver.get(URL_LOGIN)
        try:
            campo_cpf = wait.until(EC.presence_of_element_located((By.ID, "cpf")))
            campo_cpf.clear()
            campo_cpf.send_keys(usuario_sde)

            campo_senha = driver.find_element(By.XPATH, "//input[@type='password']")
            campo_senha.clear()
            campo_senha.send_keys(senha_sde)
            campo_senha.send_keys(Keys.RETURN)
            time.sleep(2)
        except Exception as e:
            raise SDEForaDoArError(f"Não foi possível autenticar no SDE: {e}")

        return extrair_professores_unicos(driver)
    finally:
        try:
            driver.quit()
        except Exception:
            pass


def buscar_diarios_do_professor(driver_inst, cpf_prof):
    driver_inst.get(f"{URL_PESQUISA_PROF_FREQ}?q={cpf_prof}")
    time.sleep(1.5)
    soup = BeautifulSoup(driver_inst.page_source, "html.parser")

    diarios = []
    for tr in soup.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) >= 5:
            turma_texto = normalizar_texto(tds[3].text)
            disc_texto = normalizar_texto(tds[4].text)

            link = tds[0].find("a")
            if link and "href" in link.attrs:
                href = link["href"]
                match = re.search(r'codigo=(\d+)', href)
                if match:
                    id_turmaprofessor = match.group(1)
                    diarios.append({
                        "id_turmaprofessor": id_turmaprofessor,
                        "turma": turma_texto,
                        "disciplina": disc_texto
                    })
    return diarios


def analisar_chamada_diario(driver_inst, cpf_prof, id_turmaprofessor, id_etapa="", mes=""):
    """
    Analisa verticalmente cada coluna de data do relatório do diário.
    Identifica lançamento de frequência por presença ('.', 'P') ou falta ('F').
    Retorna as datas que não possuem nenhum tipo de lançamento.
    """
    url_completa = (
        f"{URL_RELATORIO_FREQ}?"
        f"professor_cpf={cpf_prof}&"
        f"id_turmaprofessor={id_turmaprofessor}&"
        f"id_etapa={id_etapa}&"
        f"mes={mes}"
    )

    driver_inst.get(url_completa)
    time.sleep(1.5)

    soup = BeautifulSoup(driver_inst.page_source, "html.parser")

    # 1. Extração das datas no cabeçalho (<thead> -> <th> -> <small> ou texto direto)
    datas_aulas = []
    header_tr = soup.find("thead")
    if header_tr:
        ths = header_tr.find_all("th")
        for th in ths:
            small_tag = th.find("small")
            texto_th = small_tag.text if small_tag else th.text
            texto_limpo = normalizar_texto(texto_th)
            
            match_data = re.search(r'\d{2}/\d{2}', texto_limpo)
            if match_data:
                datas_aulas.append(match_data.group(0))

    if not datas_aulas:
        return [], 0

    # 2. Rastreador booleano para cada coluna/data encontrada
    colunas_com_lancamento = [False] * len(datas_aulas)

    # 3. Análise vertical (coluna por coluna em todas as linhas de alunos)
    tbody = soup.find("tbody")
    if tbody:
        for tr in tbody.find_all("tr"):
            tds = tr.find_all("td")
            
            # As primeiras 3 colunas correspondem a Nº, Estudante e Situação.
            # O índice 3 em diante guarda as marcas de frequência das datas.
            if len(tds) >= 3 + len(datas_aulas):
                colunas_frequencia = tds[3 : 3 + len(datas_aulas)]

                for idx, td in enumerate(colunas_frequencia):
                    if idx < len(colunas_com_lancamento):
                        # Limpa espaços invisíveis e normaliza
                        txt = normalizar_texto(td.text)
                        
                        # Se contiver sinais de presença ('.', 'P') ou falta ('F', 'FALTA', 'PRESENÇA')
                        if any(sinal in txt for sinal in ["F", "P", "."]) or "FALTA" in txt or "PRESENCA" in txt:
                            colunas_com_lancamento[idx] = True

    # 4. Identifica as datas que permaneceram sem nenhum lançamento de chamada
    datas_sem_chamada = [
        datas_aulas[idx]
        for idx, teve_chamada in enumerate(colunas_com_lancamento)
        if not teve_chamada
    ]

    return datas_sem_chamada, len(datas_aulas)


def gerador_pdf_bytes(df_relatorio, resumo_estatistico):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(letter),
        rightMargin=15,
        leftMargin=15,
        topMargin=20,
        bottomMargin=20
    )
    elements = []
    styles = getSampleStyleSheet()

    titulo_style = ParagraphStyle(
        'TituloPDF',
        parent=styles['Heading1'],
        fontSize=12,
        textColor=colors.HexColor("#1F497D"),
        alignment=1,
        spaceAfter=6
    )

    cell_style = ParagraphStyle('CellText', parent=styles['Normal'], fontSize=7, leading=9)
    cell_header = ParagraphStyle('CellHeader', parent=styles['Normal'], fontSize=7.5, leading=10, textColor=colors.whitesmoke, fontName='Helvetica-Bold')

    elements.append(Paragraph("Relatório de Pendências de Chamada / Frequência de Professores", titulo_style))
    elements.append(Paragraph(f"Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}", styles['Normal']))
    elements.append(Spacer(1, 8))

    resumo_p = Paragraph(
        f"<b>Total de Dias sem Chamada:</b> {resumo_estatistico['total_dias_sem_chamada']} | "
        f"<b>Turma(s) com Menos Chamadas Realizadas:</b> {', '.join(resumo_estatistico['turmas_menos_chamadas'])}",
        styles['Normal']
    )
    elements.append(resumo_p)
    elements.append(Spacer(1, 10))

    if not df_relatorio.empty:
        colunas = ["CPF", "Professor", "Turma", "Disciplina", "Total Dias Sem Chamada", "Datas Sem Chamada"]
        df_sub = df_relatorio[colunas].copy()

        col_widths = [75, 130, 130, 100, 80, 230]
        header_row = [Paragraph(c, cell_header) for c in colunas]
        data_tabela = [header_row]

        table_styles = [
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F497D")),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC"))
        ]

        for row_data in df_sub.values:
            row_cells = [Paragraph(str(val or ""), cell_style) for val in row_data]
            data_tabela.append(row_cells)

        t_relatorio = Table(data_tabela, colWidths=col_widths, hAlign='LEFT', repeatRows=1)
        t_relatorio.setStyle(TableStyle(table_styles))
        elements.append(t_relatorio)
    else:
        elements.append(Paragraph("Nenhuma pendência encontrada. Todas as chamadas foram realizadas corretamente!", styles['Normal']))

    doc.build(elements)
    buffer.seek(0)
    return buffer


def executar_verificacao_frequencia_professor(
    usuario_sde, 
    senha_sde, 
    id_etapa="", 
    mes="", 
    cpf_selecionado="TODOS",
    professores_pre_carregados=None,
    status_callback=None
):
    logs_execucao = []
    def log(msg):
        logs_execucao.append(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

    log("Iniciando Verificação de Frequência dos Professores...")

    options = webdriver.ChromeOptions()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 20)

    try:
        if status_callback:
            status_callback("Realizando login no SDE...", 0.05, 0)

        driver.get(URL_LOGIN)
        try:
            campo_cpf = wait.until(EC.presence_of_element_located((By.ID, "cpf")))
            campo_cpf.clear()
            campo_cpf.send_keys(usuario_sde)

            campo_senha = driver.find_element(By.XPATH, "//input[@type='password']")
            campo_senha.clear()
            campo_senha.send_keys(senha_sde)
            campo_senha.send_keys(Keys.RETURN)
            time.sleep(2)
        except Exception as e:
            raise SDEForaDoArError(f"Não foi possível autenticar no SDE: {e}")

        if professores_pre_carregados:
            professores_unicos = professores_pre_carregados
        else:
            if status_callback:
                status_callback("Extraindo lista de professores...", 0.10, 0)

            professores_unicos = extrair_professores_unicos(driver)

        if cpf_selecionado != "TODOS" and cpf_selecionado in professores_unicos:
            professores_para_processar = {cpf_selecionado: professores_unicos[cpf_selecionado]}
        else:
            professores_para_processar = professores_unicos

        log(f"Processando {len(professores_para_processar)} professor(es).")

        relatorio_pendencias = []
        estatisticas_turma = {}

        total_profs = len(professores_para_processar)
        for idx_p, (cpf_p, nome_p) in enumerate(professores_para_processar.items(), 1):
            if status_callback:
                progresso = 0.15 + (idx_p / max(total_profs, 1)) * 0.75
                status_callback(f"Analisando diários do prof.: {nome_p}", progresso, 0)

            diarios = buscar_diarios_do_professor(driver, cpf_p)

            for diario in diarios:
                id_turmaprof = diario["id_turmaprofessor"]
                turma_nome = diario["turma"]
                disc_nome = diario["disciplina"]

                datas_sem_chamada, total_dias = analisar_chamada_diario(
                    driver, cpf_p, id_turmaprof, id_etapa=id_etapa, mes=mes
                )

                if turma_nome not in estatisticas_turma:
                    estatisticas_turma[turma_nome] = {"dias_sem_chamada": 0, "total_dias": 0}

                estatisticas_turma[turma_nome]["dias_sem_chamada"] += len(datas_sem_chamada)
                estatisticas_turma[turma_nome]["total_dias"] += total_dias

                if datas_sem_chamada:
                    relatorio_pendencias.append({
                        "CPF": cpf_p,
                        "Professor": nome_p,
                        "Turma": turma_nome,
                        "Disciplina": disc_nome,
                        "Total Dias Sem Chamada": len(datas_sem_chamada),
                        "Datas Sem Chamada": ", ".join(datas_sem_chamada)
                    })

        total_dias_sem_chamada_geral = sum(r["Total Dias Sem Chamada"] for r in relatorio_pendencias)

        turmas_menos_chamadas = []
        if estatisticas_turma:
            maior_pendencia = max(info["dias_sem_chamada"] for info in estatisticas_turma.values())
            if maior_pendencia > 0:
                turmas_menos_chamadas = [
                    f"{t} ({info['dias_sem_chamada']} dias sem chamada)"
                    for t, info in estatisticas_turma.items()
                    if info["dias_sem_chamada"] == maior_pendencia
                ]
            else:
                turmas_menos_chamadas = ["Nenhuma (Todas as turmas estão com a frequência em dia)"]
        else:
            turmas_menos_chamadas = ["Nenhum registro analisado"]

        resumo_estatistico = {
            "total_dias_sem_chamada": total_dias_sem_chamada_geral,
            "turmas_menos_chamadas": turmas_menos_chamadas
        }

        df_relatorio = pd.DataFrame(relatorio_pendencias)

        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            if not df_relatorio.empty:
                df_relatorio.to_excel(writer, sheet_name="Pendencias_Chamada", index=False)
            else:
                pd.DataFrame([{"Mensagem": "Todas as chamadas foram realizadas."}]).to_excel(writer, sheet_name="Pendencias_Chamada", index=False)

            wb = writer.book
            ws = wb["Pendencias_Chamada"]
            ws.views.sheetView[0].showGridLines = True

            header_fill = PatternFill(start_color="1F497D", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True)

            for cell in ws[1]:
                cell.fill, cell.font = header_fill, header_font
                cell.alignment = Alignment(horizontal="center", vertical="center")

            for col in ws.columns:
                max_len = max(len(str(cell.value or '')) for cell in col)
                col_letter = get_column_letter(col[0].column)
                ws.column_dimensions[col_letter].width = max(max_len + 3, 15)

        excel_buffer.seek(0)
        pdf_buffer = gerador_pdf_bytes(df_relatorio, resumo_estatistico)

        log("Relatório de pendências gerado com sucesso.")
        if status_callback:
            status_callback("Concluído!", 1.0, 0)

        carimbo = datetime.now().strftime("%Y%m%d_%H%M%S")
        return {
            "excel_bytes": excel_buffer.getvalue(),
            "pdf_bytes": pdf_buffer.getvalue(),
            "nome_arquivo_excel": f"Relatorio_Pendencias_Chamada_{carimbo}.xlsx",
            "nome_arquivo_pdf": f"Relatorio_Pendencias_Chamada_{carimbo}.pdf",
            "df_relatorio": df_relatorio,
            "resumo_estatistico": resumo_estatistico,
            "logs_execucao": logs_execucao
        }

    finally:
        try:
            driver.quit()
        except Exception:
            pass