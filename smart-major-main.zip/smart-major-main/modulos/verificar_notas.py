import time
import re
import io
import keyboard
import pandas as pd
from pathlib import Path
from datetime import datetime
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

# Módulos para geração do PDF via ReportLab
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

# --- EXCEÇÃO CUSTOMIZADA PARA CAPTURA NO APP.PY ---
class SDEForaDoArError(Exception):
    """Exceção lançada quando o SDE está indisponível ou fora do ar."""
    pass

URL_LOGIN = "https://sde.seduc.ro.gov.br/login.php"
URL_QUADRO = "https://sde.seduc.ro.gov.br/escola/nota/form_quadrodemonstrativo.php"
URL_TODAS_TURMAS = "https://sde.seduc.ro.gov.br/escola/turma/form_inclusao_turma.php"
URL_ESPELHO_BASE = "https://sde.seduc.ro.gov.br/escola/turmamanutencao/form_imprimi_turma_aluno.php"
URL_PESQUISA_ALUNO_BASE = "https://sde.seduc.ro.gov.br/escola/aluno/form_pesquisa_aluno_turma.php"

TURMAS_ALVO = [
    "REGULAR - 1EM - M - A", "REGULAR - 1EM - M - B", "REGULAR - 1EM - M - C", "REGULAR - 1EM - M - D", "REGULAR - 1EM - M - E",
    "REGULAR - 1EM - T - F", "REGULAR - 1EM - T - G", "REGULAR - 1EM - T - H", "REGULAR - 1EM - T - I", "REGULAR - 1EM - T - J",
    "REGULAR - 2EM - M - A", "REGULAR - 2EM - M - B", "REGULAR - 2EM - M - C", "REGULAR - 2EM - M - D", "REGULAR - 2EM - M - E",
    "REGULAR - 2EM - T - F", "REGULAR - 2EM - T - G", "REGULAR - 2EM - T - H", "REGULAR - 2EM - T - I", "REGULAR - 2EM - T - J",
    "REGULAR - 3EM - M - A", "REGULAR - 3EM - M - B", "REGULAR - 3EM - M - C", "REGULAR - 3EM - M - D", "REGULAR - 3EM - M - E", "REGULAR - 3EM - M - F",
    "REGULAR - 3EM - T - G", "REGULAR - 3EM - T - H", "REGULAR - 3EM - T - I", "REGULAR - 3EM - T - J", "REGULAR - 3EM - T - K", "REGULAR - 3EM - T - L"
]

def normalizar_texto(texto):
    if not texto:
        return ""
    return re.sub(r'\s+', ' ', str(texto)).strip().upper()

def classificar_nota(val_str):
    if val_str == "-":
        return "Sem Lançamento"
    try:
        nota = float(val_str)
        if 0.0 <= nota <= 5.9:
            return "Abaixo da Média"
        elif 6.0 <= nota <= 10.0:
            return "Acima da Média"
    except ValueError:
        pass
    return "Indefinido"

def carregar_mapa_todas_turmas(driver_inst):
    try:
        driver_inst.get(URL_TODAS_TURMAS)
        time.sleep(2)
        soup = BeautifulSoup(driver_inst.page_source, "html.parser")
        rows = soup.find_all("tr", class_="turma-row")
        mapa_turmas = {}
        for row in rows:
            id_cell = row.find("td", class_="id-cell")
            mod_cell = row.find("td", class_="modalidade-cell")
            ano_cell = row.find("td", class_="ano-cell")
            turno_cell = row.find("td", class_="turno-cell")
            sala_cell = row.find("td", class_="sala-cell")
            if id_cell and mod_cell and ano_cell and turno_cell and sala_cell:
                codigo = id_cell.text.strip()
                mod = normalizar_texto(mod_cell.text)
                ano_t = normalizar_texto(ano_cell.text)
                turno_t = normalizar_texto(turno_cell.text)
                sala_t = normalizar_texto(sala_cell.text)
                chave = f"{mod} - {ano_t} - {turno_t} - {sala_t}"
                mapa_turmas[chave] = codigo
        return mapa_turmas
    except Exception as e:
        raise SDEForaDoArError(f"Erro ao acessar listagem de turmas no SDE: {e}")

def carregar_mapa_id_alunos_por_turma(driver_inst, codigo_turma):
    driver_inst.get(f"{URL_ESPELHO_BASE}?turma={codigo_turma}")
    time.sleep(1.5)
    soup = BeautifulSoup(driver_inst.page_source, "html.parser")
    mapa_alunos = {}
    for row in soup.find_all("tr"):
        texto_tr = str(row)
        match_id = re.search(r'Estadual</b>:\s*(?:&nbsp;)?\s*(\d+)', texto_tr, re.IGNORECASE)
        tds = row.find_all("td")
        if match_id and len(tds) >= 2:
            id_estadual = match_id.group(1).strip()
            nome_aluno = tds[2].text.strip().upper() if len(tds) > 2 else tds[1].text.strip().upper()
            nome_aluno = normalizar_texto(nome_aluno)
            if nome_aluno and "NOME DO ESTUDANTE" not in nome_aluno:
                mapa_alunos[nome_aluno] = id_estadual
    return mapa_alunos

def verificar_situacao_cadastral(driver_inst, wait_inst, id_aluno, turma_origem):
    try:
        url_pesquisa = f"{URL_PESQUISA_ALUNO_BASE}?q={id_aluno}"
        driver_inst.get(url_pesquisa)
        wait_inst.until(EC.presence_of_element_located((By.ID, "studentTable")))

        soup = BeautifulSoup(driver_inst.page_source, "html.parser")
        tabela = soup.find("table", id="studentTable")

        if not tabela or not tabela.find("tbody"):
            return "Situação Desconhecida", "Não Encontrado", "-"

        turma_atual = None
        situacao_atual = None
        turmas_anteriores = []

        for tr in tabela.find("tbody").find_all("tr", recursive=False):
            tds = tr.find_all("td", recursive=False)
            if len(tds) >= 8:
                nome_turma = normalizar_texto(tds[5].text)
                situacao = normalizar_texto(tds[7].text)

                is_regular = ("REGULAR" in nome_turma) and not any(
                    kw in nome_turma for kw in ["ELETIVAS", "TRILHAS", "LINGUA ESPANHOLA", "ESPANHOL"]
                )

                if is_regular:
                    if "MATRICULADO" in situacao or "TRANSFERIDO" in situacao:
                        turma_atual = nome_turma
                        situacao_atual = situacao
                    elif "REMANEJADO" in situacao:
                        turmas_anteriores.append(f"{nome_turma} (REMANEJADO)")

        turma_anterior_str = ", ".join(turmas_anteriores) if turmas_anteriores else "-"

        if situacao_atual and "TRANSFERIDO" in situacao_atual:
            diagnostico = "Transferido de Escola"
        elif turma_atual and turma_atual != turma_origem:
            diagnostico = f"Remanejado para {turma_atual}"
        elif turmas_anteriores:
            diagnostico = f"Remanejado (Turma Anterior: {turma_anterior_str})"
        else:
            diagnostico = "Pendente de Lançamento pelo Professor"

        return diagnostico, (turma_atual or turma_origem), turma_anterior_str

    except Exception:
        return "Erro na Consulta de Situação", turma_origem, "-"

def gerador_pdf_bytes(df_resumo, df_sem_nota, rotulo_etapa):
    """
    Gera um relatório sintetizado em formato PDF em memória (BytesIO)
    com quebra automática de texto e destaque visual de diagnósticos.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(letter),
        rightMargin=15,
        leftMargin=15,
        topMargin=20,
        bottomMargin=20
    )
    elements = []
    styles = getSampleStyleSheet()

    titulo_style = ParagraphStyle(
        'TituloPDF',
        parent=styles['Heading1'],
        fontSize=14,
        textColor=colors.HexColor("#1F497D"),
        alignment=1,
        spaceAfter=10
    )

    subtitulo_style = ParagraphStyle(
        'SubTituloPDF',
        parent=styles['Heading2'],
        fontSize=10,
        textColor=colors.HexColor("#333333"),
        spaceBefore=8,
        spaceAfter=8
    )

    cell_style = ParagraphStyle(
        'CellText',
        parent=styles['Normal'],
        fontSize=6.5,
        leading=8
    )

    cell_header_style = ParagraphStyle(
        'CellHeader',
        parent=styles['Normal'],
        fontSize=7,
        leading=9,
        textColor=colors.whitesmoke,
        fontName='Helvetica-Bold'
    )

    cell_black_bold = ParagraphStyle(
        'CellBlackBold',
        parent=styles['Normal'],
        fontSize=6.5,
        leading=8,
        textColor=colors.HexColor("#333333"),
        fontName='Helvetica-Bold'
    )

    elements.append(Paragraph(f"SmartMajor - Relatório de Notas no SDE ({rotulo_etapa.replace('_', ' ')})", titulo_style))
    elements.append(Paragraph(f"Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}", styles['Normal']))
    elements.append(Spacer(1, 10))

    # Tabela 1: Resumo Executivo
    elements.append(Paragraph("1. Resumo Numérico por Ano Escolar", subtitulo_style))
    
    header_resumo = [Paragraph(c, cell_header_style) for c in df_resumo.columns.tolist()]
    data_resumo = [header_resumo]
    for row in df_resumo.values:
        data_resumo.append([Paragraph(str(v), cell_style) for v in row])

    col_w_resumo = [80, 110, 110, 95, 110, 110, 95]
    t_resumo = Table(data_resumo, colWidths=col_w_resumo, hAlign='LEFT')
    t_resumo.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F497D")),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC"))
    ]))
    elements.append(t_resumo)
    elements.append(Spacer(1, 15))

    # Tabela 2: Alunos sem Nota (Sintético)
    elements.append(Paragraph("2. Alunos com Lançamentos Pendentes (Sem Nota)", subtitulo_style))
    if not df_sem_nota.empty:
        colunas_pdf = ["Nome do Aluno", "Turma", "Ano Escolar", "Disciplina", "Etapa Pendente", "Diagnóstico / Causa Provável"]
        cols_presentes = [c for c in colunas_pdf if c in df_sem_nota.columns]
        df_sem_nota_sub = df_sem_nota[cols_presentes].copy()

        larguras_mapa = {
            "Nome do Aluno": 160,
            "Turma": 110,
            "Ano Escolar": 60,
            "Disciplina": 130,
            "Etapa Pendente": 70,
            "Diagnóstico / Causa Provável": 230
        }
        col_w_sem_nota = [larguras_mapa.get(c, 80) for c in cols_presentes]

        header_sem_nota = [Paragraph(c, cell_header_style) for c in cols_presentes]
        data_sem_nota = [header_sem_nota]

        table_styles_sn = [
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1F497D")),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC"))
        ]

        idx_diag = cols_presentes.index("Diagnóstico / Causa Provável") if "Diagnóstico / Causa Provável" in cols_presentes else -1

        for row_idx, row_data in enumerate(df_sem_nota_sub.values, start=1):
            row_cells = []
            val_diag = str(row_data[idx_diag]) if idx_diag != -1 else ""

            if any(kw in val_diag for kw in ["Transferido", "Remanejado"]):
                bg_color = colors.HexColor("#FFEB9C")
            else:
                bg_color = colors.HexColor("#FFC7CE")

            for col_idx, val in enumerate(row_data):
                val_str = str(val or "")
                if col_idx == idx_diag:
                    row_cells.append(Paragraph(val_str, cell_black_bold))
                    table_styles_sn.append(('BACKGROUND', (col_idx, row_idx), (col_idx, row_idx), bg_color))
                else:
                    row_cells.append(Paragraph(val_str, cell_style))

            data_sem_nota.append(row_cells)

        t_sem_nota = Table(data_sem_nota, colWidths=col_w_sem_nota, hAlign='LEFT', repeatRows=1)
        t_sem_nota.setStyle(TableStyle(table_styles_sn))
        elements.append(t_sem_nota)
    else:
        elements.append(Paragraph("Nenhum aluno com nota pendente para as etapas selecionadas.", styles['Normal']))

    doc.build(elements)
    buffer.seek(0)
    return buffer

def executar_verificacao_notas(usuario_sde, senha_sde, opcao_etapa_str, opcao_turma_str="TODAS AS TURMAS", status_callback=None, **kwargs):
    # Lógica de seleção de Etapas
    if opcao_etapa_str == "Todas as 4 Etapas":
        etapas_selecionadas = [1, 2, 3, 4]
        rotulo_etapa = "Todas_Etapas"
    else:
        num_etapa = int(opcao_etapa_str[0])
        etapas_selecionadas = [num_etapa]
        rotulo_etapa = f"{num_etapa}a_Etapa"

    # Lógica de seleção de Turmas
    if opcao_turma_str == "TODAS AS TURMAS":
        turmas_processar = TURMAS_ALVO
    else:
        turmas_processar = [opcao_turma_str]

    options = webdriver.ChromeOptions()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 30)

    dados_alunos = {}
    sem_nota_lista = []

    contadores = {
        "1º Ano": {"LPL_abaixo": 0, "LPL_acima": 0, "LPL_sem_nota": 0, "MAT_abaixo": 0, "MAT_acima": 0, "MAT_sem_nota": 0},
        "2º Ano": {"LPL_abaixo": 0, "LPL_acima": 0, "LPL_sem_nota": 0, "MAT_abaixo": 0, "MAT_acima": 0, "MAT_sem_nota": 0},
        "3º Ano": {"LPL_abaixo": 0, "LPL_acima": 0, "LPL_sem_nota": 0, "MAT_abaixo": 0, "MAT_acima": 0, "MAT_sem_nota": 0}
    }

    try:
        if status_callback:
            status_callback("Acessando a página de login do SDE...", 0.02, 0)
        driver.get(URL_LOGIN)

        try:
            campo_cpf = wait.until(EC.presence_of_element_located((By.ID, "cpf")))
            campo_cpf.clear()
            campo_cpf.send_keys(usuario_sde)

            campo_senha = driver.find_element(By.XPATH, "//input[@type='password']")
            campo_senha.clear()
            campo_senha.send_keys(senha_sde)
            campo_senha.send_keys(Keys.RETURN)

            time.sleep(3)
        except Exception as e:
            raise SDEForaDoArError(f"Não foi possível autenticar no SDE: {e}")

        if status_callback:
            status_callback("Mapeando turmas e alunos...", 0.05, 0)
        mapa_codigos_turmas = carregar_mapa_todas_turmas(driver)

        mapa_alunos_global = {}
        for turma_nome in turmas_processar:
            cod_t = mapa_codigos_turmas.get(turma_nome)
            if cod_t:
                mapa_alunos_global[turma_nome] = carregar_mapa_id_alunos_por_turma(driver, cod_t)

        if status_callback:
            status_callback("Acessando Quadro Demonstrativo de Notas...", 0.10, 0)
        driver.get(URL_QUADRO)
        wait.until(EC.presence_of_element_located((By.XPATH, "//table//tbody/tr")))

        linhas_tabela = driver.find_elements(By.XPATH, "//table//tbody/tr")
        links_para_processar = []

        for linha in linhas_tabela:
            tds = linha.find_elements(By.TAG_NAME, "td")
            if len(tds) >= 5:
                nome_turma = tds[4].text.strip()
                if nome_turma in turmas_processar:
                    ano_escolar = "1º Ano" if "1EM" in nome_turma else ("2º Ano" if "2EM" in nome_turma else "3º Ano")
                    for etapa_idx in etapas_selecionadas:
                        try:
                            link_etapa = linha.find_element(
                                By.XPATH, f".//a[contains(@href, 'id_etapa={etapa_idx}')]"
                            )
                            href = link_etapa.get_attribute("href")
                            if href:
                                links_para_processar.append({
                                    "ano": ano_escolar, "turma": nome_turma,
                                    "etapa": etapa_idx, "url": href
                                })
                        except Exception:
                            pass

        total_links = len(links_para_processar)
        inicio_coleta = time.time()

        for idx, item in enumerate(links_para_processar, 1):
            if keyboard.is_pressed("esc"):
                break

            tempo_decorrido = time.time() - inicio_coleta
            tempo_medio = tempo_decorrido / max(idx, 1)
            links_restantes = total_links - idx
            tempo_restante_seg = int(tempo_medio * links_restantes)
            progresso_pct = 0.10 + (idx / max(total_links, 1)) * 0.60

            if status_callback:
                status_callback(
                    f"Extraindo Notas ({idx}/{total_links}): {item['turma']} | {item['etapa']}ª Etapa",
                    progresso_pct, tempo_restante_seg
                )

            driver.get(item["url"])
            try:
                wait.until(EC.presence_of_element_located((By.XPATH, "//tr[@data-aluno-id]")))
                soup = BeautifulSoup(driver.page_source, "html.parser")
                linhas_alunos = soup.find_all("tr", attrs={"data-aluno-id": True})

                for row in linhas_alunos:
                    tds = row.find_all("td")
                    if len(tds) < 15:
                        continue
                    nome_aluno = tds[1].text.strip()
                    if not nome_aluno:
                        continue

                    chave_aluno = (nome_aluno, item["turma"], item["ano"])

                    if chave_aluno not in dados_alunos:
                        dados_alunos[chave_aluno] = {
                            "LPL": {1: "-", 2: "-", 3: "-", 4: "-"},
                            "MAT": {1: "-", 2: "-", 3: "-", 4: "-"}
                        }

                    val_lpl = tds[2].text.strip().replace(",", ".")
                    dados_alunos[chave_aluno]["LPL"][item["etapa"]] = val_lpl

                    if val_lpl == "-":
                        contadores[item["ano"]]["LPL_sem_nota"] += 1
                        sem_nota_lista.append({
                            "Nome do Aluno": nome_aluno, "Turma": item["turma"],
                            "Ano Escolar": item["ano"], "Disciplina": "Língua Portuguesa (LPL)",
                            "Etapa Pendente": f"{item['etapa']}ª Etapa"
                        })
                    else:
                        try:
                            nota = float(val_lpl)
                            if 0.0 <= nota <= 5.9:
                                contadores[item["ano"]]["LPL_abaixo"] += 1
                            elif 6.0 <= nota <= 10.0:
                                contadores[item["ano"]]["LPL_acima"] += 1
                        except ValueError:
                            pass

                    val_mat = tds[14].text.strip().replace(",", ".")
                    dados_alunos[chave_aluno]["MAT"][item["etapa"]] = val_mat

                    if val_mat == "-":
                        contadores[item["ano"]]["MAT_sem_nota"] += 1
                        sem_nota_lista.append({
                            "Nome do Aluno": nome_aluno, "Turma": item["turma"],
                            "Ano Escolar": item["ano"], "Disciplina": "Matemática (MAT)",
                            "Etapa Pendente": f"{item['etapa']}ª Etapa"
                        })
                    else:
                        try:
                            nota = float(val_mat)
                            if 0.0 <= nota <= 5.9:
                                contadores[item["ano"]]["MAT_abaixo"] += 1
                            elif 6.0 <= nota <= 10.0:
                                contadores[item["ano"]]["MAT_acima"] += 1
                        except ValueError:
                            pass
            except Exception:
                pass

        total_pendentes = len(sem_nota_lista)
        if total_pendentes > 0:
            inicio_auditoria = time.time()
            for idx_p, registro in enumerate(sem_nota_lista, 1):
                nome = registro["Nome do Aluno"]
                turma = registro["Turma"]

                tempo_decorrido = time.time() - inicio_auditoria
                tempo_medio = tempo_decorrido / max(idx_p, 1)
                pendentes_restantes = total_pendentes - idx_p
                tempo_restante_seg = int(tempo_medio * pendentes_restantes)
                progresso_pct = 0.70 + (idx_p / total_pendentes) * 0.25

                if status_callback:
                    status_callback(
                        f"Auditando Sem Nota [{idx_p}/{total_pendentes}]: {nome}",
                        progresso_pct, tempo_restante_seg
                    )

                nome_norm = normalizar_texto(nome)
                id_aluno = mapa_alunos_global.get(turma, {}).get(nome_norm)

                if id_aluno:
                    diagnostico, turma_atual, turma_anterior = verificar_situacao_cadastral(driver, wait, id_aluno, turma)
                    registro["ID Estadual"] = id_aluno
                    registro["Diagnóstico / Causa Provável"] = diagnostico
                    registro["Turma Atual no SDE"] = turma_atual
                    registro["Turma Anterior"] = turma_anterior
                    registro["Link Ficha SDE"] = f"{URL_PESQUISA_ALUNO_BASE}?q={id_aluno}"
                else:
                    registro["ID Estadual"] = "Não Localizado"
                    registro["Diagnóstico / Causa Provável"] = "Aluno não encontrado no espelho da turma"
                    registro["Turma Atual no SDE"] = turma
                    registro["Turma Anterior"] = "-"
                    registro["Link Ficha SDE"] = ""

        if status_callback:
            status_callback("Gerando e formatando planilhas e relatórios...", 0.98, 2)

        etapa_ref = etapas_selecionadas[0]
        dfs_por_ano = {}
        for ano in ["1º Ano", "2º Ano", "3º Ano"]:
            linhas_ano = []
            for (nome, turma, ano_aluno), disciplinas in dados_alunos.items():
                if ano_aluno == ano:
                    nota_lpl_ref = disciplinas["LPL"][etapa_ref]
                    nota_mat_ref = disciplinas["MAT"][etapa_ref]
                    nome_norm = normalizar_texto(nome)
                    id_aluno = mapa_alunos_global.get(turma, {}).get(nome_norm, "")

                    link_aluno = f"{URL_PESQUISA_ALUNO_BASE}?q={id_aluno}" if id_aluno else ""

                    linhas_ano.append({
                        "Nome do Aluno": nome,
                        "Turma": turma,
                        "ID Estadual": id_aluno if id_aluno else "N/A",
                        "LPL - Etapa 1": disciplinas["LPL"][1],
                        "LPL - Etapa 2": disciplinas["LPL"][2],
                        "LPL - Etapa 3": disciplinas["LPL"][3],
                        "LPL - Etapa 4": disciplinas["LPL"][4],
                        f"Situação LPL ({etapa_ref}ª Etapa)": classificar_nota(nota_lpl_ref),
                        "MAT - Etapa 1": disciplinas["MAT"][1],
                        "MAT - Etapa 2": disciplinas["MAT"][2],
                        "MAT - Etapa 3": disciplinas["MAT"][3],
                        "MAT - Etapa 4": disciplinas["MAT"][4],
                        f"Situação MAT ({etapa_ref}ª Etapa)": classificar_nota(nota_mat_ref),
                        "Link Ficha SDE": link_aluno
                    })
            dfs_por_ano[ano] = pd.DataFrame(linhas_ano)

        df_sem_nota = pd.DataFrame(sem_nota_lista)

        resumo_data = [
            {
                "Ano Escolar": ano,
                "LPL - Abaixo da Média (0.0 - 5.9)": sub["LPL_abaixo"],
                "LPL - Acima da Média (6.0 - 10.0)": sub["LPL_acima"],
                "LPL - Sem Nota (-)": sub["LPL_sem_nota"],
                "MAT - Abaixo da Média (0.0 - 5.9)": sub["MAT_abaixo"],
                "MAT - Acima da Média (6.0 - 10.0)": sub["MAT_acima"],
                "MAT - Sem Nota (-)": sub["MAT_sem_nota"]
            } for ano, sub in contadores.items()
        ]
        df_resumo = pd.DataFrame(resumo_data)

        # 1. GERAR EXCEL EM MEMÓRIA (BytesIO)
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
            df_resumo.to_excel(writer, sheet_name="Painel_Executivo", index=False)
            for ano, df_ano in dfs_por_ano.items():
                df_ano.to_excel(writer, sheet_name=ano, index=False)
            df_sem_nota.to_excel(writer, sheet_name="Alunos_Sem_Nota", index=False)

            wb = writer.book

            red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
            green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
            orange_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")

            red_font = Font(color="9C0006", bold=True)
            green_font = Font(color="006100", bold=True)
            orange_font = Font(color="9C6500", bold=True)

            header_fill = PatternFill(start_color="1F497D", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True)

            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                ws.views.sheetView[0].showGridLines = True
                for cell in ws[1]:
                    cell.fill, cell.font = header_fill, header_font
                    cell.alignment = Alignment(horizontal="center", vertical="center")

                if sheet_name in ["1º Ano", "2º Ano", "3º Ano"]:
                    for row in ws.iter_rows(min_row=2):
                        for cell in row:
                            val = str(cell.value).strip()
                            try:
                                nota = float(val)
                                if 0.0 <= nota <= 5.9:
                                    cell.fill, cell.font = red_fill, red_font
                                elif 6.0 <= nota <= 10.0:
                                    cell.fill, cell.font = green_fill, green_font
                            except ValueError:
                                if val in ["-", "Sem Lançamento"]:
                                    cell.fill, cell.font = orange_fill, orange_font
                                elif val == "Abaixo da Média":
                                    cell.fill, cell.font = red_fill, red_font
                                elif val == "Acima da Média":
                                    cell.fill, cell.font = green_fill, green_font

                elif sheet_name == "Alunos_Sem_Nota":
                    for row in ws.iter_rows(min_row=2):
                        for cell in row:
                            val = str(cell.value).strip()
                            if any(kw in val for kw in ["Transferido", "Remanejado"]):
                                cell.fill, cell.font = orange_fill, orange_font
                            elif any(kw in val for kw in ["Pendente", "Não Encontrado", "Erro"]):
                                cell.fill, cell.font = red_fill, red_font

                for col in ws.columns:
                    max_len = max(len(str(cell.value or '')) for cell in col)
                    col_letter = get_column_letter(col[0].column)
                    ws.column_dimensions[col_letter].width = max(max_len + 3, 14)

        excel_buffer.seek(0)

        # 2. GERAR PDF EM MEMÓRIA (BytesIO)
        pdf_buffer = gerador_pdf_bytes(df_resumo, df_sem_nota, rotulo_etapa)

        if status_callback:
            status_callback("Concluído!", 1.0, 0)

        sufixo_turma = opcao_turma_str.replace(' ', '_') if opcao_turma_str != "TODAS AS TURMAS" else "TODAS_TURMAS"
        timestamp = datetime.now().strftime("%d%m%y_%H%M%S")
        nome_arquivo_base = f"Relatorio_Notas_{sufixo_turma}_{rotulo_etapa}_{timestamp}"

        return {
            "excel_bytes": excel_buffer.getvalue(),
            "pdf_bytes": pdf_buffer.getvalue(),
            "nome_arquivo_excel": f"{nome_arquivo_base}.xlsx",
            "nome_arquivo_pdf": f"{nome_arquivo_base}.pdf",
            "df_resumo": df_resumo,
            "dfs_por_ano": dfs_por_ano,
            "df_sem_nota": df_sem_nota
        }

    finally:
        try:
            driver.quit()
        except Exception:
            pass