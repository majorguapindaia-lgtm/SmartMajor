"""Smart Major — Relatórios do Diário Eletrônico (robôs do SDE).

Tela do módulo "Relatórios do Diário Eletrônico" (permissão relatorios.consultar),
aberta por app.py depois do login.

Regras desta tela:
- Todo robô roda por `_executar_robo`, que revalida a permissão no momento da
  ação. Relatório novo deve chamar o robô por ali, nunca direto.
- O último resultado de cada relatório fica em st.session_state (chaves
  "sde_resultado_*"), para que clicar em download ou mexer num filtro não apague
  a tela. São dados de alunos: o logout em app.py apaga a sessão inteira.
"""
from __future__ import annotations

import html
import importlib
from contextlib import contextmanager

import pandas as pd
import streamlit as st

from administracao.permissoes import possui_permissao

PERMISSAO_RELATORIOS = "relatorios.consultar"

MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
MIME_PDF = "application/pdf"

CHAVE_USUARIO_SDE = "sde_usuario"
CHAVE_SENHA_SDE = "sde_senha"
CHAVE_RELATORIO = "sde_relatorio_escolhido"
CHAVE_CACHE_PROFESSORES = "sde_lista_professores"
PREFIXO_RESULTADO = "sde_resultado_"

OPCAO_NENHUM_RELATORIO = "Selecione um relatório..."

ETAPAS = [("1", "1º BIMESTRE"), ("2", "2º BIMESTRE"), ("3", "3º BIMESTRE"), ("4", "4º BIMESTRE")]
MESES_LETIVOS = [
    ("02", "Fevereiro"), ("03", "Março"), ("04", "Abril"), ("05", "Maio"), ("06", "Junho"),
    ("08", "Agosto"), ("09", "Setembro"), ("10", "Outubro"), ("11", "Novembro"),
]
MESES_BOLSA_FAMILIA = [
    "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho",
    "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
]
SITUACOES_NOTA = ["Acima da Média", "Abaixo da Média", "Sem Lançamento"]
ANOS_ESCOLARES = ["1º Ano", "2º Ano", "3º Ano"]
MEDALHAS = [("🥇 1º Lugar", "gold"), ("🥈 2º Lugar", "silver"), ("🥉 3º Lugar", "bronze")]


# ----------------------------------------------------
# IMPORTAÇÃO DOS ROBÔS
# Um robô ausente não derruba o sistema: só o relatório dele fica indisponível.
# ----------------------------------------------------
ERROS_IMPORTACAO: list[str] = []


def _importar(candidatos: list[str], nomes: list[str]) -> list:
    """Importa `nomes` do primeiro módulo de `candidatos` que carregar.

    Se nenhum carregar, registra o motivo e devolve None para cada nome.
    """
    ultimo_erro: Exception | None = None
    for caminho in candidatos:
        try:
            modulo = importlib.import_module(caminho)
            return [getattr(modulo, nome) for nome in nomes]
        except (ImportError, AttributeError) as erro:
            ultimo_erro = erro
    ERROS_IMPORTACAO.append(f"{' ou '.join(candidatos)}: {ultimo_erro}")
    return [None] * len(nomes)


executar_verificacao_notas, TURMAS_ALVO = _importar(
    ["modulos.verificar_notas"],
    ["executar_verificacao_notas", "TURMAS_ALVO"],
)
executar_auditoria_matriculas, TURMAS_REGULARES = _importar(
    ["modulos.auditoria_matriculas"],
    ["executar_auditoria_matriculas", "TURMAS_REGULARES"],
)
executar_analise_abandono, _SDEForaDoArDoRobo, TURMAS_ABANDONO = _importar(
    ["modulo_abandono", "modulos.modulo_abandono"],
    ["executar_analise_abandono", "SDEForaDoArError", "TURMAS_REGULARES"],
)
(executar_aluno_nota_10,) = _importar(
    ["modulos.aluno_nota_10"],
    ["executar_aluno_nota_10"],
)
(executar_porcentagem_bolsa_familia,) = _importar(
    ["modulos.porcentagem_bolsa_familia", "porcentagem_bolsa_familia"],
    ["executar_porcentagem_bolsa_familia"],
)
executar_verificacao_frequencia_professor, obter_lista_professores_sde = _importar(
    ["modulos.verificar_freq_professor", "verificar_freq_professor"],
    ["executar_verificacao_frequencia_professor", "obter_lista_professores_sde"],
)

TURMAS_ALVO = TURMAS_ALVO or []
TURMAS_REGULARES = TURMAS_REGULARES or []
TURMAS_ABANDONO = TURMAS_ABANDONO or TURMAS_REGULARES


class _SDEForaDoArReserva(Exception):
    """Usada só se modulo_abandono não carregar.

    Antes o fallback era `Exception`, o que fazia qualquer erro aparecer como
    "SDE fora do ar".
    """


SDEForaDoArError = _SDEForaDoArDoRobo or _SDEForaDoArReserva


class PermissaoNegada(Exception):
    """A conta não tem a permissão no momento em que tenta executar o robô."""


# ----------------------------------------------------
# ESTILO
# ----------------------------------------------------
CSS_RELATORIOS = """
<style>
.main-header {
    font-size: 26px;
    font-weight: bold;
    color: #1F497D;
    margin-bottom: 15px;
}
.stButton>button {
    width: 100%;
    border-radius: 6px;
    height: 45px;
    font-weight: bold;
}
.podium-card {
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 10px;
    color: #111111;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}
.gold { background-color: #FFF2CC; border: 2px solid #D6B656; }
.silver { background-color: #E6E6E6; border: 2px solid #B0B0B0; }
.bronze { background-color: #F8CECC; border: 2px solid #C55A11; }
</style>
"""

CONFIG_LINK_SDE = {
    "Link Ficha SDE": st.column_config.LinkColumn(
        "Link Ficha SDE",
        help="Clique para abrir a ficha do estudante no SDE",
        validate="^https://.*",
        display_text="🔗 Abrir SDE",
    )
}

_VERMELHO = "background-color: #FFC7CE; color: #9C0006; font-weight: bold;"
_AMARELO = "background-color: #FFEB9C; color: #9C6500; font-weight: bold;"
_VERDE = "background-color: #C6EFCE; color: #006100; font-weight: bold;"


def estilar_notas_web(val):
    val_str = str(val).strip()
    try:
        nota = float(val_str)
        if 0.0 <= nota <= 5.9:
            return _VERMELHO
        elif 6.0 <= nota <= 10.0:
            return _VERDE
    except ValueError:
        if val_str in ["-", "Sem Lançamento"]:
            return _AMARELO
        elif val_str == "Abaixo da Média":
            return _VERMELHO
        elif val_str == "Acima da Média":
            return _VERDE
    return ""


def estilar_sem_nota_web(val):
    val_str = str(val).strip()
    if any(kw in val_str for kw in ["Transferido", "Remanejado"]):
        return _AMARELO
    elif any(kw in val_str for kw in ["Pendente", "Não Encontrado", "Erro"]):
        return _VERMELHO
    return ""


def estilar_auditoria_web(val):
    val_str = str(val).strip()
    if "Regularizado" in val_str:
        return _VERDE
    elif "Transferido" in val_str:
        return _AMARELO
    elif "Pendente" in val_str or "Erro" in val_str:
        return _VERMELHO
    return ""


def estilar_abandono_web(val):
    val_str = str(val).strip()
    if "🔴" in val_str or "RISCO" in val_str:
        return _VERMELHO
    elif "🟡" in val_str or "ALERTA" in val_str:
        return _AMARELO
    elif "🟢" in val_str or "JUSTIFICADO" in val_str:
        return _VERDE
    return ""


def estilar_presenca_pct_web(val):
    try:
        pct = float(val)
    except (ValueError, TypeError):
        return ""
    if pct < 75.0:
        return _VERMELHO
    elif pct < 85.0:
        return _AMARELO
    return _VERDE


def formatar_tempo(segundos) -> str:
    segundos = int(segundos)
    if segundos <= 0:
        return "Calculando..."
    minutos, seg_resto = divmod(segundos, 60)
    if minutos > 0:
        return f"~{minutos} min e {seg_resto} seg restantes"
    return f"~{seg_resto} seg restantes"


def _cabecalho(titulo: str, descricao: str) -> None:
    st.markdown(f'<div class="main-header">{titulo}</div>', unsafe_allow_html=True)
    st.write(descricao)


# ----------------------------------------------------
# SESSÃO: CREDENCIAIS DO SDE E RESULTADOS
# ----------------------------------------------------
def _chave_widget(chave: str) -> str:
    return f"_widget_{chave}"


def _widget_persistente(criar_widget, rotulo: str, chave: str, padrao, **kwargs):
    """Cria um widget cujo valor sobrevive à troca de módulo no menu.

    O Streamlit apaga o estado de widgets que não foram desenhados numa execução
    (ao ir para o Almoxarifado, por exemplo). O valor é copiado para `chave`, que
    não pertence a widget, e devolvido ao widget quando ele volta a aparecer.
    """
    chave_widget = _chave_widget(chave)
    if chave_widget not in st.session_state:
        valor = st.session_state.get(chave, padrao)
        opcoes = kwargs.get("options")
        if opcoes is not None and valor not in opcoes:
            valor = padrao
        st.session_state[chave_widget] = valor
    valor = criar_widget(rotulo, key=chave_widget, **kwargs)
    st.session_state[chave] = valor
    return valor


def _limpar_credenciais_sde() -> None:
    # Callback (on_click): roda antes do rerun, quando ainda é permitido alterar
    # chaves de widgets. Chamado depois do widget desenhado, como no código
    # antigo, o Streamlit levanta StreamlitAPIException.
    for chave in (CHAVE_USUARIO_SDE, CHAVE_SENHA_SDE):
        st.session_state[_chave_widget(chave)] = ""
        st.session_state[chave] = ""
    st.session_state.pop(CHAVE_CACHE_PROFESSORES, None)


def _credenciais_preenchidas(usuario_sde: str, senha_sde: str) -> bool:
    if usuario_sde and senha_sde:
        return True
    st.warning("⚠️ Informe o CPF/Usuário e a Senha do SDE na barra lateral antes de iniciar.")
    return False


def _guardar_resultado(chave: str, res: dict, legenda: str, **extras) -> None:
    st.session_state[PREFIXO_RESULTADO + chave] = {"res": res, "legenda": legenda, "extras": extras}


def _exibir_ultimo_resultado(chave: str, exibir) -> None:
    """Desenha o último resultado guardado, sobrevivendo a downloads e filtros."""
    guardado = st.session_state.get(PREFIXO_RESULTADO + chave)
    if not guardado:
        return
    st.markdown("---")
    st.caption(f"📌 Último resultado gerado nesta sessão — {guardado['legenda']}")
    try:
        exibir(guardado["res"], **guardado["extras"])
    except Exception as erro:  # noqa: BLE001 — resultado fora do formato esperado não derruba a tela
        st.error(f"❌ **Não foi possível exibir o resultado:** {erro}")


# ----------------------------------------------------
# EXECUÇÃO DOS ROBÔS
# ----------------------------------------------------
def _robo_disponivel(robo, arquivo: str) -> bool:
    if robo is not None:
        return True
    st.error(f"Erro: o robô '{arquivo}' não foi carregado. Veja o aviso de importação no topo da página.")
    return False


def _executar_robo(contexto, robo, *args, **kwargs):
    """Ponto único de execução dos robôs do SDE.

    Revalida a permissão no momento da ação, não só no menu. Toda tela de
    relatório chama os robôs por aqui.
    """
    if robo is None:
        raise RuntimeError("robô não carregado (veja o aviso de importação no topo da página).")
    if not possui_permissao(contexto.conta_id, PERMISSAO_RELATORIOS):
        raise PermissaoNegada("Sua conta não tem permissão para executar relatórios do Diário Eletrônico.")
    return robo(*args, **kwargs)


class PainelProgresso:
    """Mensagem de status, barra e tempo estimado.

    `atualizar` tem a assinatura de status_callback que os robôs esperam.
    """

    def __init__(self, mostrar_tempo: bool = True):
        self._status = st.empty()
        self._barra = st.progress(0.0)
        self._tempo = st.empty()
        self._mostrar_tempo = mostrar_tempo

    def atualizar(self, msg, progresso, tempo_restante_seg) -> None:
        self._status.info(f"⏳ **Progresso [{int(progresso * 100)}%]:** {msg}")
        self._barra.progress(min(max(progresso, 0.0), 1.0))
        if self._mostrar_tempo and tempo_restante_seg and tempo_restante_seg > 0:
            self._tempo.caption(f"⏱️ **Tempo Estimado Restante:** {formatar_tempo(tempo_restante_seg)}")
        else:
            self._tempo.empty()

    def concluir(self, mensagem: str) -> None:
        self._status.success(mensagem)
        self._barra.progress(1.0)
        self._tempo.empty()

    def limpar(self) -> None:
        self._status.empty()
        self._barra.empty()
        self._tempo.empty()


@contextmanager
def _tratar_erros_robo(painel: PainelProgresso | None, quando: str = "durante o processamento"):
    """Mostra o erro na tela em vez de derrubar a página.

    Não colocar st.rerun() aqui dentro: ele funciona levantando uma exceção.
    """
    try:
        yield
    except PermissaoNegada as erro:
        if painel:
            painel.limpar()
        st.error(f"🔒 {erro}")
    except SDEForaDoArError as erro:
        if painel:
            painel.limpar()
        st.error(f"⚠️ **SDE INDISPONÍVEL / FORA DO AR:**\n\n{erro}\n\nTente novamente dentro de alguns minutos.")
    except Exception as erro:  # noqa: BLE001 — falha do robô não pode derrubar a tela
        if painel:
            painel.limpar()
        st.error(f"❌ **Ocorreu um erro {quando}:** {erro}")


def _botoes_download(
    res: dict,
    rotulo_excel: str = "📥 Baixar Excel (.XLSX)",
    rotulo_pdf: str = "📄 Baixar Relatório PDF (.PDF)",
) -> None:
    col_btn1, col_btn2 = st.columns(2)
    with col_btn1:
        st.download_button(
            label=rotulo_excel,
            data=res["excel_bytes"],
            file_name=res["nome_arquivo_excel"],
            mime=MIME_XLSX,
            type="primary",
        )
    with col_btn2:
        st.download_button(
            label=rotulo_pdf,
            data=res["pdf_bytes"],
            file_name=res["nome_arquivo_pdf"],
            mime=MIME_PDF,
            type="secondary",
        )


# ----------------------------------------------------
# RELATÓRIO: VERIFICAÇÃO DE CHAMADA (PROFESSORES)
# ----------------------------------------------------
def _tela_chamada_professores(contexto, usuario_sde: str, senha_sde: str) -> None:
    _cabecalho(
        "👨‍🏫 SmartMajor: Verificação de Lançamento de Chamada",
        "Mapeia a lista de professores do SDE e permite auditá-los individualmente ou de forma global.",
    )
    if not _robo_disponivel(executar_verificacao_frequencia_professor, "verificar_freq_professor.py"):
        return

    st.markdown("##### 1. Mapeamento de Professores")
    col_carr1, col_carr2 = st.columns([2, 1])
    with col_carr1:
        if CHAVE_CACHE_PROFESSORES in st.session_state:
            total = len(st.session_state[CHAVE_CACHE_PROFESSORES])
            st.success(f"✅ **{total} professores** mapeados em memória.")
        else:
            st.info("💡 A lista de professores ainda não foi carregada nesta sessão.")
    with col_carr2:
        if st.button("🔄 Carregar/Atualizar Lista de Professores") and _credenciais_preenchidas(usuario_sde, senha_sde):
            carregou = False
            with st.spinner("Conectando ao SDE e extraindo professores..."), \
                    _tratar_erros_robo(None, "ao carregar a lista de professores"):
                st.session_state[CHAVE_CACHE_PROFESSORES] = _executar_robo(
                    contexto, obter_lista_professores_sde, usuario_sde, senha_sde
                )
                carregou = True
            if carregou:
                st.rerun()  # fora do bloco de erros, senão o rerun seria capturado como erro

    st.markdown("---")
    st.markdown("##### 2. Seleção de Parâmetros e Filtros")
    profs_cache = st.session_state.get(CHAVE_CACHE_PROFESSORES, {})

    col_filtro1, col_filtro2, col_filtro3 = st.columns(3)
    with col_filtro1:
        cpf_alvo = st.selectbox(
            "Selecione o Professor:",
            ["TODOS", *profs_cache.keys()],
            format_func=lambda cpf: "TODOS OS PROFESSORES" if cpf == "TODOS" else f"{profs_cache[cpf]} ({cpf})",
            help="Escolha 'TODOS OS PROFESSORES' ou selecione apenas um docente específico.",
        )
    with col_filtro2:
        tipo_filtro = st.radio("Filtrar Busca por:", ["Etapa (Bimestre)", "Mês"], horizontal=True, key="rad_prof")
    with col_filtro3:
        if tipo_filtro == "Etapa (Bimestre)":
            id_etapa, rotulo_periodo = st.selectbox("Selecione a Etapa:", ETAPAS, format_func=lambda x: x[1])
            mes = ""
        else:
            mes, rotulo_periodo = st.selectbox("Selecione o Mês:", MESES_LETIVOS, format_func=lambda x: x[1])
            id_etapa = ""

    st.markdown("---")
    if st.button("🚀 Auditagem de Chamadas dos Professores", type="primary") and _credenciais_preenchidas(usuario_sde, senha_sde):
        painel = PainelProgresso(mostrar_tempo=False)
        with _tratar_erros_robo(painel, "durante a verificação"):
            res = _executar_robo(
                contexto,
                executar_verificacao_frequencia_professor,
                usuario_sde=usuario_sde,
                senha_sde=senha_sde,
                id_etapa=id_etapa,
                mes=mes,
                cpf_selecionado=cpf_alvo,
                professores_pre_carregados=profs_cache or None,
                status_callback=painel.atualizar,
            )
            rotulo_prof = "Todos os professores" if cpf_alvo == "TODOS" else profs_cache.get(cpf_alvo, cpf_alvo)
            _guardar_resultado("chamada", res, f"{rotulo_prof} | {rotulo_periodo}")
            painel.concluir("✅ **Auditoria de Chamadas Concluída com Sucesso!**")

    _exibir_ultimo_resultado("chamada", _exibir_chamada_professores)


def _exibir_chamada_professores(res: dict) -> None:
    resumo = res["resumo_estatistico"]
    st.subheader("📊 Métrica Geral do Período")
    col_m1, col_m2 = st.columns(2)
    with col_m1:
        st.metric("Total de Dias Sem Chamada (Geral)", resumo["total_dias_sem_chamada"])
    with col_m2:
        st.metric("Turma(s) com Menos Chamadas Realizadas", " | ".join(resumo["turmas_menos_chamadas"]))

    st.markdown("---")
    st.subheader("📋 Relatórios Gerados para Download")
    _botoes_download(res)

    st.markdown("---")
    st.subheader("📌 Detalhamento por Professor e Turma")
    df_relatorio = res["df_relatorio"]
    if df_relatorio.empty:
        st.info("🎉 Ótimas notícias! Nenhuma pendência encontrada. Todas as chamadas do período foram realizadas regularmente.")
    else:
        st.dataframe(df_relatorio, use_container_width=True)

    with st.expander("🔍 **Clique para visualizar o histórico de execução (Logs)**", expanded=False):
        for linha in res["logs_execucao"]:
            st.text(linha)


# ----------------------------------------------------
# RELATÓRIO: PORCENTAGEM BOLSA FAMÍLIA (PAR DE MESES)
# ----------------------------------------------------
def _tela_bolsa_familia(contexto, usuario_sde: str, senha_sde: str) -> None:
    _cabecalho(
        "💰 SmartMajor: Porcentagem Frequência Bolsa Família",
        "Extrai a porcentagem de presença de todos os estudantes matriculados em um **par de meses** "
        "para prestação de contas do Programa Bolsa Família.",
    )
    if not _robo_disponivel(executar_porcentagem_bolsa_familia, "porcentagem_bolsa_familia.py"):
        return

    lista_aulas = list(range(1, 141))
    col_m1, col_a1 = st.columns(2)
    with col_m1:
        mes1 = st.selectbox("Selecione o 1º Mês:", MESES_BOLSA_FAMILIA, index=6)
    with col_a1:
        aulas_m1 = st.selectbox("Carga Horária (Aulas) do 1º Mês:", lista_aulas, index=139, key="aulas_m1")
    col_m2, col_a2 = st.columns(2)
    with col_m2:
        mes2 = st.selectbox("Selecione o 2º Mês:", MESES_BOLSA_FAMILIA, index=7)
    with col_a2:
        aulas_m2 = st.selectbox("Carga Horária (Aulas) do 2º Mês:", lista_aulas, index=139, key="aulas_m2")

    st.markdown("---")
    if st.button("🚀 Processar Frequência Bolsa Família", type="primary") and _credenciais_preenchidas(usuario_sde, senha_sde):
        painel = PainelProgresso()
        with _tratar_erros_robo(painel):
            res = _executar_robo(
                contexto,
                executar_porcentagem_bolsa_familia,
                usuario_sde=usuario_sde,
                senha_sde=senha_sde,
                mes1_nome=mes1,
                total_aulas_m1=aulas_m1,
                mes2_nome=mes2,
                total_aulas_m2=aulas_m2,
                status_callback=painel.atualizar,
            )
            _guardar_resultado(
                "bolsa_familia", res,
                f"{mes1} ({aulas_m1} aulas) e {mes2} ({aulas_m2} aulas)",
                mes1=mes1, mes2=mes2,
            )
            painel.concluir(f"✅ **Relatório Bolsa Família ({mes1} e {mes2}) Gerado com Sucesso!**")

    _exibir_ultimo_resultado("bolsa_familia", _exibir_bolsa_familia)


def _exibir_bolsa_familia(res: dict, mes1: str, mes2: str) -> None:
    st.subheader("📋 Relatórios Gerados para Baixar")
    _botoes_download(res)

    st.markdown("---")
    st.subheader(f"📊 Consolidado de Frequência ({mes1} e {mes2})")
    df_rel = res["df_relatorio"]
    if not df_rel.empty:
        cols_pct = [c for c in df_rel.columns if "Presença %" in str(c)]
        st.dataframe(df_rel.style.map(estilar_presenca_pct_web, subset=cols_pct), use_container_width=True)


# ----------------------------------------------------
# RELATÓRIO: PRÊMIO ALUNO NOTA 10
# ----------------------------------------------------
def _tela_aluno_nota_10(contexto, usuario_sde: str, senha_sde: str) -> None:
    _cabecalho(
        "🏆 SmartMajor: Prêmio Aluno Nota 10",
        "Identifica o melhor estudante de cada turma por notas. Desempata pelo maior número de "
        "notas 10,0 e mapeia os 1º, 2º e 3º colocados.",
    )
    if not _robo_disponivel(executar_aluno_nota_10, "aluno_nota_10.py"):
        return

    col1, col2 = st.columns(2)
    with col1:
        turma = st.selectbox(
            "Selecione a Turma / Agrupamento:",
            ["TODAS AS TURMAS", "1ºs Anos (Todos)", "2ºs Anos (Todos)", "3ºs Anos (Todos)", *TURMAS_ALVO],
        )
    with col2:
        bimestre = st.selectbox("Selecione o Bimestre:", ["1º Bimestre", "2º Bimestre", "3º Bimestre", "4º Bimestre"])

    st.markdown("##### ⚙️ Opções de Disciplinas de Trilha / Eletivas")
    col_chk1, col_chk2 = st.columns(2)
    with col_chk1:
        ignorar_trilha_2ano = st.checkbox("Ignorar Disciplinas de Trilha nos 2ºs Anos", value=False)
    with col_chk2:
        ignorar_trilha_3ano = st.checkbox("Ignorar Disciplinas de Trilha nos 3ºs Anos", value=False)

    st.markdown("---")
    if st.button("🚀 Processar Ranking Aluno Nota 10", type="primary") and _credenciais_preenchidas(usuario_sde, senha_sde):
        painel = PainelProgresso()
        with _tratar_erros_robo(painel):
            res = _executar_robo(
                contexto,
                executar_aluno_nota_10,
                usuario_sde=usuario_sde,
                senha_sde=senha_sde,
                opcao_turma_str=turma,
                opcao_bimestre_str=bimestre,
                ignorar_trilha_2ano=ignorar_trilha_2ano,
                ignorar_trilha_3ano=ignorar_trilha_3ano,
                status_callback=painel.atualizar,
            )
            _guardar_resultado("nota_10", res, f"{turma} | {bimestre}")
            painel.concluir("✅ **Ranking Aluno Nota 10 Gerado com Sucesso!**")

    _exibir_ultimo_resultado("nota_10", _exibir_aluno_nota_10)


def _card_podio(medalha: str, classe: str, aluno: dict) -> str:
    # Escapa os valores: o card é HTML cru (unsafe_allow_html) com dados vindos do SDE.
    def campo(chave):
        return html.escape(str(aluno[chave]))

    return (
        f'<div class="podium-card {classe}">'
        f"<h4>{medalha}</h4>"
        f"<p><strong>{campo('nome')}</strong> (ID: {campo('id_aluno')})</p>"
        f"<p><small>Menor Nota: <strong>{campo('menor_nota')}</strong> | "
        f"Notas 10.0: <strong>{campo('qtd_10')}</strong> | "
        f"Média: <strong>{campo('media')}</strong></small></p>"
        f"<p><small><em>{campo('motivo')}</em></small></p>"
        f"</div>"
    )


def _exibir_aluno_nota_10(res: dict) -> None:
    _botoes_download(res, rotulo_excel="📥 Baixar Ranking Excel (.XLSX)")
    st.markdown("---")

    for turma_nome, alunos in res["resultados_por_turma"].items():
        st.subheader(f"📍 Turma: {turma_nome}")
        qualificados = [a for a in alunos if a["status"] == "Qualificado"]

        if not qualificados:
            st.warning("⚠️ Nenhum aluno qualificado nesta turma (todos possuem notas abaixo de 6.0).")
        else:
            colunas = st.columns(min(3, len(qualificados)))
            for coluna, (medalha, classe), aluno in zip(colunas, MEDALHAS, qualificados):
                with coluna:
                    st.markdown(_card_podio(medalha, classe, aluno), unsafe_allow_html=True)

        with st.expander(f"📋 Ver ranking completo e desqualificados da turma {turma_nome}"):
            st.dataframe(pd.DataFrame(alunos), use_container_width=True)


# ----------------------------------------------------
# RELATÓRIO: VERIFICAR NOTAS (LPL E MAT)
# ----------------------------------------------------
def _tela_verificar_notas(contexto, usuario_sde: str, senha_sde: str) -> None:
    _cabecalho(
        "📊 SmartMajor: Verificação de Notas no SDE",
        "Extrai o quadro de notas de Português e Matemática, audita os alunos sem nota e exibe tudo "
        "com formatação de cores.",
    )
    if not _robo_disponivel(executar_verificacao_notas, "verificar_notas.py"):
        return

    col1, col2 = st.columns(2)
    with col1:
        turma = st.selectbox("Selecione a Turma:", ["TODAS AS TURMAS", *TURMAS_ALVO])
    with col2:
        etapa = st.selectbox(
            "Selecione a Etapa:",
            ["Todas as 4 Etapas", "1ª Etapa", "2ª Etapa", "3ª Etapa", "4ª Etapa"],
        )

    st.markdown("---")
    if st.button("🚀 Iniciar Coleta de Notas", type="primary") and _credenciais_preenchidas(usuario_sde, senha_sde):
        painel = PainelProgresso()
        with _tratar_erros_robo(painel, "durante a execução"):
            res = _executar_robo(
                contexto,
                executar_verificacao_notas,
                usuario_sde=usuario_sde,
                senha_sde=senha_sde,
                opcao_etapa_str=etapa,
                opcao_turma_str=turma,
                status_callback=painel.atualizar,
            )
            _guardar_resultado("notas", res, f"{turma} | {etapa}")
            painel.concluir("✅ **Processamento Concluído!**")

    _exibir_ultimo_resultado("notas", _exibir_verificar_notas)


def _exibir_verificar_notas(res: dict) -> None:
    st.subheader("📋 Relatórios Gerados")
    _botoes_download(res, rotulo_excel="📥 Baixar Relatório Excel (.XLSX)")

    tab_resumo, tab_sem_nota, *tabs_anos = st.tabs(
        ["📊 Resumo Executivo", "⚠️ Alunos Sem Nota (Pendências)", *ANOS_ESCOLARES]
    )

    with tab_resumo:
        st.markdown("##### Resumo Numérico por Ano Escolar")
        st.dataframe(res["df_resumo"], use_container_width=True)

    with tab_sem_nota:
        st.markdown("##### Alunos Sem Nota e Diagnóstico Cadastral")
        st.dataframe(
            res["df_sem_nota"].style.map(estilar_sem_nota_web),
            use_container_width=True,
            column_config=CONFIG_LINK_SDE,
        )

    dfs_por_ano = res["dfs_por_ano"]
    for aba, ano in zip(tabs_anos, ANOS_ESCOLARES):
        with aba:
            st.markdown(f"##### Notas Detalhadas - {ano}")
            col_f1, _ = st.columns(2)
            with col_f1:
                filtro_situacao = st.multiselect(
                    f"Filtrar por Situação em {ano}:",
                    SITUACOES_NOTA,
                    default=SITUACOES_NOTA,
                    key=f"filtro_{ano}",
                )

            df_ano = dfs_por_ano.get(ano, pd.DataFrame())
            if df_ano.empty:
                st.info(f"Sem dados de notas para o {ano}.")
                continue

            col_sit = next((c for c in df_ano.columns if str(c).startswith("Situação LPL")), None)
            if col_sit is not None and filtro_situacao:
                df_ano = df_ano[df_ano[col_sit].isin(filtro_situacao)]

            st.dataframe(
                df_ano.style.map(estilar_notas_web),
                use_container_width=True,
                column_config=CONFIG_LINK_SDE,
            )


# ----------------------------------------------------
# RELATÓRIO: AUDITORIA DE MATRÍCULAS
# ----------------------------------------------------
def _tela_auditoria_matriculas(contexto, usuario_sde: str, senha_sde: str) -> None:
    _cabecalho(
        "📋 SmartMajor: Auditoria de Status de Matrículas",
        "Verifica se os alunos possuem pendências de matrículas em Eletivas, Trilhas e Língua Espanhola.",
    )
    if not _robo_disponivel(executar_auditoria_matriculas, "auditoria_matriculas.py"):
        return

    turma = st.selectbox("Selecione a Turma para Auditagem:", ["TODAS AS TURMAS", *TURMAS_REGULARES])

    st.markdown("---")
    if st.button("🔍 Iniciar Auditoria de Matrículas", type="primary") and _credenciais_preenchidas(usuario_sde, senha_sde):
        painel = PainelProgresso()
        with _tratar_erros_robo(painel, "durante a auditoria"):
            res = _executar_robo(
                contexto,
                executar_auditoria_matriculas,
                usuario_sde=usuario_sde,
                senha_sde=senha_sde,
                opcao_turma_str=turma,
                status_callback=painel.atualizar,
            )
            _guardar_resultado("auditoria", res, turma)
            painel.concluir("✅ **Auditoria Concluída com sucesso!**")

    _exibir_ultimo_resultado("auditoria", _exibir_auditoria_matriculas)


def _exibir_auditoria_matriculas(res: dict) -> None:
    st.subheader("📋 Resultado da Auditoria de Matrículas")
    _botoes_download(
        res,
        rotulo_excel="📥 Baixar Auditoria em Excel (.XLSX)",
        rotulo_pdf="📄 Baixar Auditoria em PDF (.PDF)",
    )

    df_auditoria = res["df_auditoria"]
    if df_auditoria.empty or "Situação Geral" not in df_auditoria.columns:
        st.info("Nenhum registro retornado pela auditoria.")
        return

    situacoes = list(df_auditoria["Situação Geral"].unique())
    col_a1, _ = st.columns(2)
    with col_a1:
        filtro_status = st.multiselect("Filtrar por Situação Geral:", options=situacoes, default=situacoes)

    df_filtrado = df_auditoria[df_auditoria["Situação Geral"].isin(filtro_status)]
    st.dataframe(
        df_filtrado.style.map(estilar_auditoria_web),
        use_container_width=True,
        column_config=CONFIG_LINK_SDE,
    )


# ----------------------------------------------------
# RELATÓRIO: FALTAS E RISCO DE ABANDONO
# ----------------------------------------------------
def _tela_abandono(contexto, usuario_sde: str, senha_sde: str) -> None:
    _cabecalho(
        "🚨 SmartMajor: Monitoramento de Faltas e Risco de Abandono",
        "Análise cruzada de presenças diárias entre todas as disciplinas e professores para "
        "identificação de evasão escolar.",
    )
    if not _robo_disponivel(executar_analise_abandono, "modulo_abandono.py"):
        return

    col1, col2, col3 = st.columns(3)
    with col1:
        turma = st.selectbox("Selecione a Turma", ["TODAS", *TURMAS_ABANDONO])
    with col2:
        tipo_filtro = st.radio("Filtrar por", ["Mês", "Etapa"], horizontal=True)
    with col3:
        if tipo_filtro == "Mês":
            mes, rotulo_periodo = st.selectbox("Selecione o Mês", MESES_LETIVOS, format_func=lambda x: x[1])
            id_etapa = ""
        else:
            id_etapa, rotulo_periodo = st.selectbox("Selecione a Etapa", ETAPAS, format_func=lambda x: x[1])
            mes = ""

    if st.button("🔍 Analisar Faltas e Abandono", type="primary") and _credenciais_preenchidas(usuario_sde, senha_sde):
        painel = PainelProgresso(mostrar_tempo=False)
        with _tratar_erros_robo(painel, "durante a análise"):
            res = _executar_robo(
                contexto,
                executar_analise_abandono,
                usuario_sde=usuario_sde,
                senha_sde=senha_sde,
                turma_sel=turma,
                tipo_filtro=tipo_filtro,
                id_etapa=id_etapa,
                mes=mes,
                status_callback=painel.atualizar,
            )
            _guardar_resultado("abandono", res, f"{turma} | {rotulo_periodo}")
            painel.limpar()

    _exibir_ultimo_resultado("abandono", _exibir_abandono)


def _exibir_abandono(res: dict) -> None:
    with st.expander("🔍 **Clique para abrir o Diagnóstico Técnico (Logs da Varredura)**", expanded=False):
        for linha in res["logs_execucao"]:
            st.text(linha)

    df_relatorio = res["df_relatorio"]
    if df_relatorio.empty:
        st.info("Nenhum dado encontrado para a turma selecionada.")
        return

    st.subheader(f"📋 Diagnóstico Completo da Turma ({len(df_relatorio)} estudantes)")
    st.dataframe(
        df_relatorio.style.map(estilar_abandono_web, subset=["Diagnóstico"]),
        column_config=CONFIG_LINK_SDE,
        use_container_width=True,
    )
    _botoes_download(res, rotulo_excel="📊 Baixar Excel (.XLSX)", rotulo_pdf="📄 Baixar PDF (.PDF)")


# ----------------------------------------------------
# ENTRADA DO MÓDULO
# ----------------------------------------------------
TELAS_RELATORIOS = {
    "👨‍🏫 Verificação de Chamada (Professores)": _tela_chamada_professores,
    "💰 Porcentagem Bolsa Família": _tela_bolsa_familia,
    "🏆 Prêmio Aluno Nota 10": _tela_aluno_nota_10,
    "📊 Verificar Notas (LPL e MAT)": _tela_verificar_notas,
    "📋 Auditoria de Matrículas": _tela_auditoria_matriculas,
    "🚨 Faltas e Risco de Abandono": _tela_abandono,
}


def renderizar_relatorios_sde(contexto) -> None:
    """Tela do módulo "Relatórios do Diário Eletrônico" (permissão relatorios.consultar)."""
    st.markdown(CSS_RELATORIOS, unsafe_allow_html=True)

    st.sidebar.markdown("---")
    escolha = _widget_persistente(
        st.sidebar.selectbox,
        "📊 Relatórios:",
        CHAVE_RELATORIO,
        OPCAO_NENHUM_RELATORIO,
        options=[OPCAO_NENHUM_RELATORIO, *TELAS_RELATORIOS],
    )
    st.sidebar.info("💡 **Relatórios:** Escolha o relatório desejado e baixe em formato **Excel** ou **PDF**.")

    st.sidebar.subheader("🔑 Credenciais SDE")
    usuario_sde = _widget_persistente(st.sidebar.text_input, "CPF / Usuário", CHAVE_USUARIO_SDE, "")
    senha_sde = _widget_persistente(st.sidebar.text_input, "Senha", CHAVE_SENHA_SDE, "", type="password")
    st.sidebar.button("🧹 Limpar Credenciais", on_click=_limpar_credenciais_sde)

    if ERROS_IMPORTACAO:
        with st.expander(f"⚠️ {len(ERROS_IMPORTACAO)} robô(s) não carregado(s) — clique para ver o motivo"):
            for erro in ERROS_IMPORTACAO:
                st.code(erro, language=None)

    tela = TELAS_RELATORIOS.get(escolha)
    if tela is None:
        _cabecalho("🏫 Bem-vindo aos Relatórios do Diário Eletrônico", "")
        st.info("👈 Selecione um relatório no menu lateral para iniciar.")
        return
    tela(contexto, usuario_sde, senha_sde)
