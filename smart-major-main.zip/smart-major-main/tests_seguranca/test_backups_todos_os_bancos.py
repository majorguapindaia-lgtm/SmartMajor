"""Correção Fase 2: comprova que core.db, folha_ponto.db e almoxarifado.db agora
têm backup/restauração reais e testados, preservando o mecanismo original do
Arquivo Passivo (sqlite3.Connection.backup())."""
import sqlite3

import pytest

from administracao.contexto import ContextoAutorizacao
from administracao.permissoes import ErroPermissao, conceder_permissao
from administracao.database import inicializar as inicializar_admin
from administracao.registro_modulos import semear_catalogo_inicial
from autenticacao.database import inicializar as inicializar_core
from autenticacao.bootstrap_master import bootstrap_primeiro_master
from autenticacao.usuarios_cadastro import DadosPessoa, DadosVinculo, cadastrar_pessoa
from autenticacao.recuperacao import criar_conta, gerar_token_reset, consumir_token_e_redefinir

from almoxarifado.database import inicializar as inicializar_almox
from almoxarifado import services as almox_services
from almoxarifado import backup as almox_backup

from folha_ponto.database import inicializar as inicializar_fp
from folha_ponto.versoes_calendario import publicar_calendario
from folha_ponto import backup as fp_backup

from administracao import backup as core_backup


@pytest.fixture
def contexto_master() -> ContextoAutorizacao:
    inicializar_core()
    inicializar_admin()
    semear_catalogo_inicial()
    pessoa_id = bootstrap_primeiro_master("Master Backup", "master.backup.teste", "SenhaMasterForte1")
    from autenticacao.database import conectar as conectar_core
    conn = conectar_core()
    conta_id = conn.execute("SELECT id FROM contas WHERE pessoa_id = ?", (pessoa_id,)).fetchone()["id"]
    conn.close()
    return ContextoAutorizacao(conta_id=conta_id)


def _conta_comum(login: str, contexto_master: ContextoAutorizacao) -> ContextoAutorizacao:
    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome=f"Pessoa {login}"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    conta_id = criar_conta(pessoa_id, login, autor_id=None)
    token = gerar_token_reset(conta_id)
    consumir_token_e_redefinir(token, "SenhaComum123")
    return ContextoAutorizacao(conta_id=conta_id)


def test_backup_core_db_cria_e_restaura(contexto_master, tmp_path):
    caminho_backup = core_backup.criar_backup(contexto_master)
    assert caminho_backup.exists()
    assert core_backup.verificar_integridade(caminho_backup)

    destino = tmp_path / "core_restaurado.db"
    core_backup.restaurar_em_caminho_separado(caminho_backup, destino, contexto_master)
    conn = sqlite3.connect(destino)
    conta = conn.execute("SELECT login_unico FROM contas WHERE login_unico = ?",
                          ("master.backup.teste",)).fetchone()
    conn.close()
    assert conta is not None


def test_backup_core_db_exige_master(contexto_master):
    conta_comum = _conta_comum("comum.backup.core", contexto_master)
    with pytest.raises(ErroPermissao):
        core_backup.criar_backup(conta_comum)


def test_backup_almoxarifado_db_cria_e_restaura(contexto_master, tmp_path):
    inicializar_almox()
    conceder_permissao(contexto_master.conta_id, "almoxarifado.cadastrar", concedida_por=contexto_master)
    item_id = almox_services.cadastrar_item("Item para Backup", 3, contexto_master)

    caminho_backup = almox_backup.criar_backup(contexto_master)
    assert caminho_backup.exists()
    assert almox_backup.verificar_integridade(caminho_backup)

    destino = tmp_path / "almox_restaurado.db"
    almox_backup.restaurar_em_caminho_separado(caminho_backup, destino, contexto_master)
    conn = sqlite3.connect(destino)
    item = conn.execute("SELECT nome_descricao FROM itens WHERE id = ?", (item_id,)).fetchone()
    conn.close()
    assert item is not None and item[0] == "Item para Backup"


def test_backup_almoxarifado_db_exige_master(contexto_master):
    inicializar_almox()
    conta_comum = _conta_comum("comum.backup.almox", contexto_master)
    with pytest.raises(ErroPermissao):
        almox_backup.criar_backup(conta_comum)


def test_backup_folha_ponto_db_cria_e_restaura(contexto_master, tmp_path):
    inicializar_fp()
    publicar_calendario(2026, 11, [], contexto_master)

    caminho_backup = fp_backup.criar_backup(contexto_master)
    assert caminho_backup.exists()
    assert fp_backup.verificar_integridade(caminho_backup)

    destino = tmp_path / "fp_restaurado.db"
    fp_backup.restaurar_em_caminho_separado(caminho_backup, destino, contexto_master)
    conn = sqlite3.connect(destino)
    calendario = conn.execute("SELECT ano, mes FROM calendarios WHERE ano = 2026 AND mes = 11").fetchone()
    conn.close()
    assert calendario is not None


def test_backup_folha_ponto_db_exige_master(contexto_master):
    inicializar_fp()
    conta_comum = _conta_comum("comum.backup.fp", contexto_master)
    with pytest.raises(ErroPermissao):
        fp_backup.criar_backup(conta_comum)
