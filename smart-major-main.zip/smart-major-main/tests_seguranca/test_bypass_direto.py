"""Testes transversais exigidos na 2ª etapa de diagnóstico (item 14 da autorização):
comprovar que uma conta SEM autorização não consegue executar operações
diretamente nos serviços de nenhum módulo, mesmo contornando completamente a
interface Streamlit — e que a ausência de sessão/contexto bloqueia por padrão.
"""
import pytest

from administracao.contexto import ContextoAutorizacao, obter_contexto, ErroContextoInvalido
from administracao.permissoes import ErroPermissao, conceder_permissao
from administracao.database import inicializar as inicializar_admin
from administracao.registro_modulos import semear_catalogo_inicial
from autenticacao.database import inicializar as inicializar_core
from autenticacao.bootstrap_master import bootstrap_primeiro_master
from autenticacao.usuarios_cadastro import DadosPessoa, DadosVinculo, cadastrar_pessoa
from autenticacao.recuperacao import criar_conta, gerar_token_reset, consumir_token_e_redefinir
from autenticacao.login import autenticar

from arquivo_passivo.database import inicializar as inicializar_ap
from arquivo_passivo import services as ap_services

from folha_ponto.database import inicializar as inicializar_fp
from folha_ponto.versoes_calendario import publicar_calendario
from folha_ponto.emissao import emitir_folha

from almoxarifado.database import inicializar as inicializar_almox
from almoxarifado import services as almox_services


@pytest.fixture
def ambiente():
    """Prepara os quatro bancos e retorna (contexto_master, contexto_sem_permissao)
    com contas REAIS criadas via login real — não apenas inteiros soltos."""
    inicializar_core()
    inicializar_admin()
    semear_catalogo_inicial()
    inicializar_ap()
    inicializar_fp()
    inicializar_almox()

    pessoa_master_id = bootstrap_primeiro_master("Master Bypass", "master.bypass", "SenhaMasterForte1")
    from autenticacao.database import conectar as conectar_core
    conn = conectar_core()
    conta_master_id = conn.execute(
        "SELECT id FROM contas WHERE pessoa_id = ?", (pessoa_master_id,)
    ).fetchone()["id"]
    conn.close()
    contexto_master = ContextoAutorizacao(conta_id=conta_master_id)

    pessoa_id = cadastrar_pessoa(
        DadosPessoa(nome="Invasor Teste"),
        [DadosVinculo(tipo="adm", categoria="administrativo", data_inicio="2026-01-01")],
        autor_id=None,
    )
    conta_sem_permissao_id = criar_conta(pessoa_id, "invasor.teste", autor_id=None)
    token = gerar_token_reset(conta_sem_permissao_id)
    consumir_token_e_redefinir(token, "SenhaInvasor123")
    resultado_login = autenticar("invasor.teste", "SenhaInvasor123")
    assert resultado_login.sucesso
    contexto_sem_permissao = obter_contexto(resultado_login.token_sessao)

    return contexto_master, contexto_sem_permissao


def test_sem_sessao_nenhuma_operacao_e_permitida():
    """Bloqueio por padrão: sem token de sessão válido, nem o contexto é obtido."""
    inicializar_core()
    with pytest.raises(ErroContextoInvalido):
        obter_contexto(None)
    with pytest.raises(ErroContextoInvalido):
        obter_contexto("token-inventado-que-nao-existe")


def test_arquivo_passivo_bloqueia_cadastro_direto_sem_permissao(ambiente):
    _, contexto_sem_permissao = ambiente
    with pytest.raises(ErroPermissao):
        ap_services.cadastrar_caixa("Z", 1, contexto_sem_permissao)
    conn = ap_services.conectar()
    total_caixas = conn.execute("SELECT COUNT(*) AS n FROM caixas").fetchone()["n"]
    conn.close()
    assert total_caixas == 0  # nenhuma caixa foi persistida pela tentativa negada


def test_arquivo_passivo_bloqueia_movimentacao_e_ocorrencia_diretas(ambiente, ):
    contexto_master, contexto_sem_permissao = ambiente
    caixa_id = ap_services.cadastrar_caixa("A", 1, contexto_master)
    pasta_id = ap_services.cadastrar_pasta(
        "Pessoa Protegida", "convencional", 2026, "Sim", 1, "Disponivel", contexto_master,
        caixa_id=caixa_id,
    )
    with pytest.raises(ErroPermissao):
        ap_services.mover_pasta(pasta_id, caixa_id, 2, "Tentativa indevida", contexto_sem_permissao)
    with pytest.raises(ErroPermissao):
        ap_services.registrar_ocorrencia(pasta_id, None, "Desaparecida", contexto_sem_permissao)


def test_almoxarifado_bloqueia_cadastro_direto_sem_permissao(ambiente):
    _, contexto_sem_permissao = ambiente
    with pytest.raises(ErroPermissao):
        almox_services.cadastrar_item("Item Invasor", 5, contexto_sem_permissao)
    conn = almox_services.conectar()
    total_itens = conn.execute("SELECT COUNT(*) AS n FROM itens").fetchone()["n"]
    conn.close()
    assert total_itens == 0


def test_folha_ponto_bloqueia_publicacao_calendario_e_emissao_diretas(ambiente):
    contexto_master, contexto_sem_permissao = ambiente
    with pytest.raises(ErroPermissao):
        publicar_calendario(2026, 12, [], contexto_sem_permissao)
    with pytest.raises(ErroPermissao):
        emitir_folha(1, 1, "Pessoa Invasora", "administrativo", 6, 2026, 12, contexto_sem_permissao)

    # Confirma que nada foi persistido pelas tentativas negadas.
    conn = ap_services.conectar
    from folha_ponto.database import conectar as conectar_fp
    conn_fp = conectar_fp()
    total_calendarios = conn_fp.execute("SELECT COUNT(*) AS n FROM calendarios").fetchone()["n"]
    total_folhas = conn_fp.execute("SELECT COUNT(*) AS n FROM folhas").fetchone()["n"]
    conn_fp.close()
    assert total_calendarios == 0
    assert total_folhas == 0


def test_cada_permissao_e_verificada_de_forma_independente(ambiente):
    """Conceder UMA permissão não libera as demais ações do mesmo módulo."""
    contexto_master, contexto_sem_permissao = ambiente
    conceder_permissao(contexto_sem_permissao.conta_id, "arquivo_passivo.consultar",
                        concedida_por=contexto_master)

    # Agora consegue consultar...
    caixas = ap_services.listar_caixas(contexto_sem_permissao)
    assert caixas == []

    # ...mas continua bloqueado para cadastrar, editar, movimentar e registrar ocorrência.
    with pytest.raises(ErroPermissao):
        ap_services.cadastrar_caixa("B", 1, contexto_sem_permissao)


def test_administracao_bloqueia_listagem_de_contas_e_auditoria_sem_master(ambiente):
    contexto_master, contexto_sem_permissao = ambiente
    from administracao.gerenciamento_acessos import listar_contas
    from administracao.auditoria_consulta import buscar_eventos

    with pytest.raises(ErroPermissao):
        listar_contas(contexto_sem_permissao)
    with pytest.raises(ErroPermissao):
        buscar_eventos(contexto_sem_permissao)

    assert listar_contas(contexto_master)  # Master consegue
